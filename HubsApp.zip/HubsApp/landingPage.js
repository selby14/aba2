var hubs =[];
var hubsList = $("#hubs");
var hubToBeRemoved = {};
var userAgent = navigator.userAgent.toLowerCase();


function displayHubs() {

    //clear existing hubs first
    hubsList.html('');
    var template = $('#hub-template').html();
    var addHubtemplate = $('#add-hub-template').html();
    var btn;

    $.each(hubs, function (idx, hub) {
        var item = $(template).clone();
        item.data("hub", hub);
        var hubNameDiv = $(item).find('.hubName');
        hubNameDiv.html(hub.hubName);
        hubsList.append(item);
    });
    // if there are hubs, add button to hubsList
    if (hubs.length > 0) {
        btn = $(addHubtemplate).clone();
        hubsList.append(btn);
    }
    //if not, add to center
    if (hubs.length === 0) {
        btn = $(addHubtemplate).clone();
        $(btn).addClass('addHubDivPosCenter');
        hubsList.append(btn);
    }
}


// clear the form fields whenever the modal is closed
$('#addEditHub').on('hidden.bs.modal', function (e) {
    clearFormFields();
})


function addHub() {
    $("#addEditHubTitle").html("Add Hub");
    $('#addEditHub').modal('show')
}

function clearFormFields() {
    $('#hubsForm input').val('');
};

function confirmRemoveHub(elem) {
    var hub = $(elem).parent().parent().data("hub");
    Object.assign(hubToBeRemoved, hub);
    $('#removeConfirmationTitle').html("Remove " + hubToBeRemoved.hubName);
    $('#removeConfirmation').modal('show');
}

function editHub(elem) {
    var hub = $(elem).parent().parent().data("hub");

    $("#addEditHubTitle").html("Edit Hub");
    $('#hubName').val(hub.hubName);
    $('#hubKey').val(hub.hubKey);
    $('#manifestUrl').val(hub.manifestUrl);
    $('#addEditHub').modal('show');
    $('#addEditHub').on('shown.bs.modal', function () {
        $('#hubName').focus();
    });
};

function insertLoader(divId) {
    var loader = $('#loader-template').html();
    var div = $('#' + divId);
    div.append(loader);
}

function removeHub() {
    //ipcRenderer.send('hubs:remove', hubToBeRemoved);
    // update the hubs and send to electron

    _.remove(hubs, function(h) {
        return h.hubKey === hubToBeRemoved.hubKey;
    });

    if (userAgent.indexOf(' electron/') > -1) {
        electronService.saveToLocalStore('hubs_list', hubs);
    }

    Object.assign(hubToBeRemoved, {});
    $('#removeConfirmation').modal('hide');
}

function removeLoader(divId) {
    var div = $('#' + divId);
    div.html('');
}

function selectHub(elem) {
    var hub = $(elem).parent().parent().data("hub");
    var options = {};
    // call to get home screen data
    if (userAgent.indexOf(' electron/') > -1) {
        electronService.loadApp(hub.manifestUrl, options);
    }
};

function submitAddHub() {
    // create hub and validate
    var hubName = $('#hubName').val();
    var hubKey = $('#hubKey').val();
    var manifestUrl = $('#manifestUrl').val();
    if (validateAddEditHub()) {

        $('#hubsForm input').focusout(function () {
            validateAddEditHub();
        });

        return;
    }

    var _hub = {
        'hubName': hubName,
        'hubKey': hubKey,
        'manifestUrl': manifestUrl
    }
    if (userAgent.indexOf(' electron/') > -1) {
        electronService.saveToLocalStore('hubs_list', createHubList(_hub));
    }
}

function createHubList(hub) {
    var _index = _.findIndex(hubs, function (h) { return h.hubKey === hub.hubKey; });
    if (_index > -1 ) {
        _.remove(hubs, function (h) {
            return h.hubKey === hub.hubKey;
        });
    } 
    hubs.push(hub);
    return hubs;
}

function validateAddEditHub() {
    var hasError = false;
    if ($('#hubName').val().length === 0) {
        $('#hubNameDiv').addClass("has-error");
        $("#hubName").attr('placeholder', 'Hub Name is required');
        hasError = true;
    } else {
        $('#hubNameDiv').removeClass("has-error");
    }
    if ($('#manifestUrl').val().length === 0) {
        $('#manifestUrlDiv').addClass("has-error");
        $("#manifestUrl").attr('placeholder', 'Mainifest Url is required');
        hasError = true;
    } else {
        $('#manifestUrlDiv').removeClass("has-error");
    }
    if ($('#hubKey').val().length === 0) {
        $('#hubKeyDiv').addClass("has-error");
        $("#hubKey").attr('placeholder', 'Hub Key is required');
        hasError = true;
    } else {
        $('#hubKeyDiv').removeClass("has-error");
    }
    return hasError;
}

function callLoadUrl() {
    if (userAgent.indexOf(' electron/') > -1) {
        electronService.getFromLocalStore('hubs');
    }
}



// Electron responses to calls

// override electronService functions here
if (userAgent.indexOf(' electron/') > -1) {
    electronService.getFromLocalStore_Response = function (event, data) {
        switch (data.key) {
            case 'hubs_list':
                Object.assign(hubs, data.value);
                displayHubs();
                break;
            default:

        }
    }

    electronService.saveToLocalStore_Response = function (event, data) {
        switch (data.key) {
            case 'hubs_list':
                $('#addEditHub').modal('hide');
                displayHubs();
                break;
            default:

        }
    }



    // call to local store
    electronService.getFromLocalStore('hubs_list');
}