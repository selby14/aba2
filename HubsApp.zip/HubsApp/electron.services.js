
var userAgent = navigator.userAgent.toLowerCase();
if (userAgent.indexOf(' electron/') > -1) {
    var electronService = {};

    // These messages can be called by external apps to communicate with the game browser

    electronService.getFromLocalStore = function (event) {
        window.Bridge.getFromLocalStore(event);
    };

    electronService.saveToLocalStore = function (event, data) {
        window.Bridge.saveToLocalStore(event, data);
    };

    electronService.getFromTempStore = function (event) {
        window.Bridge.getFromTempStore(event);
    };

    electronService.saveToTempStore = function (event, data) {
        window.Bridge.saveToTempStore(event, data);
    };

    electronService.loadApp = function (url, options) {
        window.Bridge.loadApp(url, options);
    };

    electronService.printToPDF = function (options) {
        window.Bridge.printToPDF(options);
    };


    electronService.logError = function (msg) {
        window.Bridge.logError(msg);
    };

    electronService.logWarning = function (msg) {
        window.Bridge.logWarning(msg);
    };

    electronService.logInfo = function (msg) {
        window.Bridge.logInfo(msg);
    };

    // dummy functions placed on the gamebrowser window so we can access the game browser API and listen for call backs

    electronService.getFromLocalStore_Response = function (event, data) {
        // override this function if needed
    };

    electronService.saveToLocalStore_Response = function (event, data) {
        // override this function if needed
    };

    electronService.getFromTempStore_Response = function (event, data) {
        // override this function if needed
    };

    electronService.saveToTempStore_Response = function (event, data) {
        // override this function if needed
    };

    electronService.download_progress = function (event, progress) {
        // override this function if needed
    };

    electronService.download_complete = function (event, value) {
        // override this function if needed
    };

    electronService.launch_complete = function (event, value) {
        // override this function if needed
    };

    electronService.pdf_success = function (event, value) {
        // override this function if needed
    };

    electronService.launch_started = function (event, value) {
        // override this function if needed
    };


    // **** Set bridge functions for the preload.js

    window.Bridge.getFromLocalStore_Response = (event, key, value) => electronService.getFromLocalStore_Response(event, key, value);

    window.Bridge.saveToLocalStore_Response = (event, key, value) => electronService.saveToLocalStore_Response(event, key, value);

    window.Bridge.getFromTempStore_Response = (event, key, value) => electronService.getFromTempStore_Response(event, key, value);

    window.Bridge.saveToTempStore_Response = (event, key, value) => electronService.saveToTempStore_Response(event, key, value);

    window.Bridge.download_progress = (event, progress) => electronService.download_progress(event, progress);

    window.Bridge.download_complete = (event, value) => electronService.download_complete(event, value);

    window.Bridge.launch_complete = (event, value) => electronService.launch_complete(event, value);

    window.Bridge.pdf_success = (event, value) => electronService.pdf_success(event, value);

    window.Bridge.launch_started = (event, value) => electronService.launch_started(event, value);
}