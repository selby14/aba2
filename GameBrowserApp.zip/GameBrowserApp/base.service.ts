import { app, ipcMain } from "electron";
import * as pathHelper from "path";
import * as urlHelper from "url";
import * as request from "request";
import * as fs from "fs";
import * as gfs from "graceful-fs";
import * as _ from "lodash";
import * as write from "write";
import * as electronLog from "electron-log";
import { IAuthResponse } from './common';

export class BaseService {
    public log: typeof electronLog;    
    public debugMode: boolean;    
    public rootDataPath: string;
    public platform: string;
    public platformLowerCase: string;
    public isWindow: boolean;

    constructor() {        
        this.debugMode = process.env.NODE_ENV !== 'production';
        this.platform = "Win";
        this.isWindow = true;
        if (process.platform === "darwin") {
            this.platform = "Mac";
            this.isWindow = false;
        }
        this.platformLowerCase = this.platform.toLowerCase();
        this.rootDataPath = this.getAppDataFolder();
        const userData = app.getPath('userData');
        const logPath = userData + "/logs/logs.txt";

        // make sure logs folder exists
        this.ensureDirectoryExistence(logPath);

        this.log = electronLog;
        this.log.transports.file.level = "silly";
        this.log.transports.file.format = "{y}-{m}-{d} {h}:{i}:{s}:{ms} {text}";
        this.log.transports.file.maxSize = 5 * 1024 * 1024;
        this.log.transports.file.file = logPath;        
        this.log.transports.file["stream"] = fs.createWriteStream(logPath, { flags: 'a' });
        this.log.transports.file.appName = "gamebrowser";        
    }

     /**
     * returns bolean if app has network connection
     */
    isOnline() {
        return navigator.onLine;
    }

    /**
     * Logs to console in debug mode
     * @param info
     */
    consoleLog(info: string, ...data: any[]) {
        if (this.debugMode) {
            if (data && data.length > 0) {
                console.log(info, data);
            } else {
                console.log(info);
            }
        }
    }

   /**
    * Creates options for request
    * @param url        The url
    * @param username   The username
    * @param password   The password
    */
    createRequestOptions(url: string, username: string, password: string): any {
        const options = {
            url: url,
            json: true,
            headers: {
                "u": username,
                "p": password
            }
        };

        return options;
    }

    /**
    * Creates directory recursively
    * @param filePath  The file path
    */
    ensureDirectoryExistence(filePath: string) {
        var dirname = pathHelper.dirname(filePath);
        if (fs.existsSync(dirname)) {
            return;
        }
        this.ensureDirectoryExistence(dirname);
        fs.mkdirSync(dirname);
    }

    /**
    * Gets app data folder
    */
    getAppDataFolder(): string {
        let folder: string = `${process.env.LOCALAPPDATA}\\GameBrowser\\`;
        if (!this.isWindow) {
            folder = `${process.env.HOME}/Library/Preferences/GameBrowser`;
        }
        return folder;
    }

    /**
    * Gets auth token
    */
    getAuthToken(url:string, u: string, p: string): string {
        let token;
        let options = this.createRequestOptions(url, u, p);
        request.post(options, (error: any, response: any, body: any) => {
            if (error || response.statusCode != 200) {
                console.log(`refreshToken: ${error || body.message}`);
                token = null;
            }
            else {
                let authResponse = body.data as IAuthResponse;
                token = authResponse;
            }
            return token;
        });
    }

    /**
    * Gets currently selected hub
    */
    //getConfig(): any {
    //    let promise = new Promise((resolve, reject) => {
    //        const hubs = this.getHubsFromFile();
    //        resolve(hubs);
    //    });

    //    return promise;
    //}

    /**
    * Refreshes token
    * @param token   The IAuthResponse object
    */
    //refreshToken(token: IAuthResponse): Promise<IAuthResponse> {
    //    let promise = new Promise<IAuthResponse>((resolve, reject) => {
    //        let hub = this.getCurrentHub();
    //        if (!hub) {
    //            reject({ success: false, error: "No hub selected." });
    //            return;
    //        }

    //        let url = `${hub.apiUrl}/api/client/auth/RefreshToken?refreshToken=${token.refreshToken}`;
    //        let options = this.createRequestOptions(url, hub.clientKey);
    //        request.post(options, (error: any, response: any, body: any) => {
    //            if (error || response.statusCode != 200) {
    //                log.error(`refreshToken: ${error || body.message}`);
    //                reject({ success: false, error: error || body.message });
    //            }
    //            else {
    //                let authResponse = body.data as IAuthResponse;
    //                if (authResponse && authResponse.success) {
    //                    this.setCache(this.authTokenCacheKey, authResponse);
    //                }
    //                resolve(authResponse);
    //            }
    //        });
    //    });
    //    return promise;
    //}   
}
