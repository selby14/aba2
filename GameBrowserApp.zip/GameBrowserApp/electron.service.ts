import { BaseService } from './base.service';
import { StoreService } from './store.service';
import { IPackage } from './common';
import * as pathHelper from "path";
import * as urlHelper from "url";
import * as request from "request";
import * as progressRequest from "request-progress";
import * as fs from "fs";
import * as gfs from "graceful-fs";
import * as unzip from "unzip";
import * as _ from "lodash";
import * as write from "write";


export class ElectronService extends BaseService {
    public defaultsConfigFilePath: string = __dirname + "/defaultsConfig.json";

    constructor() {        
        super();  
    }
    
     
    /**
     * Returns json object that contains defaults
     */
    setDefaultAppUrls(): Promise<any> {
        let promise = new Promise((resolve, reject) => {
            let storeSvc = new StoreService(); 
            try {
                const content = gfs.readFileSync(this.defaultsConfigFilePath).toString();
                if (content) {
                    let _defaultsJson = JSON.parse(content);
                    if (_defaultsJson) {
                        storeSvc.setLocalStore("landingPageAppUrl", _defaultsJson.landingPageAppDefaultUrl);
                        resolve(_defaultsJson.landingPageAppDefaultUrl);
                    }
                } else {
                    this.log.error("setDefaultAppUrls: content error - no default config");
                    reject("setDefaultAppUrls: content error - ");
                }
            } catch (err) {
                this.log.error("setDefaultAppUrls: error - " + err.message);
                reject(err.message);
            }
        });
        return promise;
    }

    /**
     * Downloads config json and loads the resulting app
     * @param configUrl       The url to app config file
     */
    getAppConfig(configUrl: string): Promise<any> {
      
        let promise = new Promise((resolve, reject) => {
            this.log.info('configUrl, configUrl');
            request.get(configUrl, (error: any, response: any, body: any) => {
                if (error || response.statusCode != 200) {
                    var error_msg = "url: " + configUrl + "    :  error: " + error || body.message;
                    this.log.error("getConfig: ", error || body.message);
                    //this.hanldeError(error || body.message)
                    reject(error || body.message);
                } else {
                    resolve(body);
                }
            });
        });
        return promise;
    } 


    /**
   * Downloads packages
   * @param sender     The BrowserWindow that sent the message
   * @param packages   The list of packages
   */
    private downloadPackages(sender: any, packages: Array<IPackage>, landingPageAppKey: string, basePath: string): Promise<any> {
        let promise = new Promise((resolve, reject) => {                        
            let totalFileCount = 0;
            let completedCount = 0;
            let progress = 0;
            

            if (!packages) {
                this.log.error("downloadPackages: error: argument 'packages' is null");
                reject();
            }

            if (!packages.length) {
                if (this.reportDownloadProgress(sender, 1, 1)) {
                    resolve({});
                    return;
                }
            }

            totalFileCount = packages.length;                       

            // Download each package
            _.forEach(packages, (_package: IPackage) => {
                
                // Ignore invalid package and OnDemand packaes
                if (!_package.url || !_package.packageKey || _package.onDemand) {
                    completedCount += 1;        
                    if (this.reportDownloadProgress(sender, completedCount, totalFileCount)) {
                        resolve({});
                        return false;  // break out of forEach
                    }
                    return;  // continue forEach
                }
                
                const destPath = this.getPackageLocalPath(_package, landingPageAppKey);

                // Check if package exists
                if (fs.existsSync(destPath)) {
                    completedCount += 1;
                    if (this.reportDownloadProgress(sender, completedCount, totalFileCount)) {
                        resolve({});
                        return false;  // break out of forEach
                    }
                    return;  // continue forEach
                }

                this.ensureDirectoryExistence(destPath);
                const fileStream = fs.createWriteStream(destPath);

                var _path = (basePath && basePath.length > 0) ? basePath + _package.url : _package.url;
                this.log.info("request path:" + _path);
                var req = request({
                    method: 'GET',
                    uri: (basePath && basePath.length > 0) ? basePath + _package.url : _package.url
                });

                var progreq = progressRequest(req, {});

                progreq.on("progress", (state) => {
                    // The state is an object that looks like this: 
                    // { 
                    //     percent: 0.5,               // Overall percent (between 0 to 1) 
                    //     speed: 554732,              // The download speed in bytes/sec 
                    //     size: { 
                    //         total: 90044871,        // The total payload size in bytes 
                    //         transferred: 27610959   // The transferred payload size in bytes 
                    //     }, 
                    //     time: { 
                    //         elapsed: 36.235,        // The total elapsed seconds since the start (3 decimals) 
                    //         remaining: 81.403       // The remaining seconds to finish (3 decimals) 
                    //     } 
                    // } 
                    this.reportDownloadProgress(sender, completedCount, totalFileCount, state.percent);
                })

                progreq.on("error", (error) => {
                    this.log.error(`downloadPackages: package ${_package.packageKey} download error:`, error);
                });

                progreq.pipe(fileStream);

                progreq.on("end", () => {
                    completedCount += 1;
                    // Unzip if zip file
                    if (pathHelper.extname(destPath).toLowerCase() === ".zip") {
                        this.unzipFile(destPath).then((result) => {
                            if (this.reportDownloadProgress(sender, completedCount, totalFileCount)) {
                                resolve({});
                                return false;  // break out of forEach
                            }
                        })
                            .catch((error) => {
                                this.log.error("downloadPackages - unzipped error: " + error);
                                sender.webContents.send("app:showError", error);
                            });
                    } else {
                        if (this.reportDownloadProgress(sender, completedCount, totalFileCount)) {
                            resolve({});
                            return false;  // break out of forEach
                        }
                    }
                });
            });
        });

        return promise;
    }
    
     /**
     * Validate that all packages have been downloaded, and if not, download
     * @param sender    The electron window making the original request
     * @param packages  The list of packages needed
     * @param landingPageAppkey    The current hubkey
     */
    validatePackagesAreDownloaded(sender: any, packages: Array<IPackage>, landingPageAppKey: string): Promise<any> {
        let promise = new Promise((resolve, reject) => {
            var upToDate = true;
            _.forEach(packages, (_package: IPackage) => {
                // Ignore invalid package and OnDemand packaes
                if (!_package.url || !_package.packageKey || !_package.onDemand) {
                    return;  // continue forEach
                }
                
                const destPath = this.getPackageLocalPath(_package, landingPageAppKey);

                // Check if package exists
                if (fs.existsSync(destPath)) {
                    return;  // continue forEach
                } else {
                    upToDate = false
                    resolve(false);
                    return false;  // break out of forEach
                }
            });
            resolve(true);
        });
        return promise;
    }

    /**
     * Download the url content to a file
     * @param url       The url to download
     * @param destPath  The destination path
     * @param unzip     The flag to unzip if zip file
     */
    downloadUrl(url: string, destPath: string, unzip: boolean = false): Promise<any> {
        let promise = new Promise((resolve, reject) => {
            if (!url) { reject("invalid argument: 'url'"); }
            if (!destPath) { reject("invalid argument: 'destPath'"); }

            this.ensureDirectoryExistence(destPath);
            const fileStream = fs.createWriteStream(destPath);
            var req = request({
                method: 'GET',
                uri: url
            });

            req.on("error", (error) => {
                this.log.error(`downloadUrl: ${url} download error:`, error);
                reject(error);
            });

            req.pipe(fileStream);

            req.on("end", () => {
                // Unzip if applicable
                if (unzip === true && pathHelper.extname(destPath).toLowerCase() === ".zip") {
                    this.unzipFile(destPath).then(() => { resolve({}); }).catch((e) => { reject(e);});
                }
                else {
                    resolve({});
                }
            });
        });
        return promise;
    }

    /**
    * Unzips a given zip file
    * @param zipFilePath    The zip file path
    * @param destPath       The destination path. Optional
    */
    unzipFile(zipFilePath: string, destPath?: string): Promise<any> {
        let promise = new Promise((resolve, reject) => {
            try {
                // ignore invalid or non-existing input
                if (!zipFilePath || !fs.existsSync(zipFilePath)) {
                    console.log("unzip ignore");
                    resolve(zipFilePath);
                    return;
                }
                const finalDestPath = destPath ? pathHelper.dirname(destPath) : pathHelper.dirname(zipFilePath);
                this.log.info('zipFilePath: ' + zipFilePath);
                fs.createReadStream(zipFilePath)
                    .pipe(unzip.Extract({ path: finalDestPath }))
                    .on("close", () => {
                        console.log('file unzipped');
                        resolve(finalDestPath);
                    });                
            }
            catch (e) {   
                this.log.error('file unzipped error: ' + e);
                reject(e);
            }
        });

        return promise;
    }

    /**
    * Gets package's local destination path
    * @param _package   The package object
    */
    getPackageLocalPath(_package: any, landingPageAppKey: string =""): string {
        const parsed = urlHelper.parse(_package.url);
        const filename = pathHelper.basename(parsed.pathname);
        this.log.info("getPackageLocalPath: " + filename);
        return pathHelper.join(this.rootDataPath, landingPageAppKey, "packages", _package.packageKey, _package.version, filename);
    }

    /**
    * Reports download progress and returns true if completed otherwise false
    */
    private reportDownloadProgress(sender, completedCount, packagesCount, fileProgress: number = 0.0): boolean {
        const progress = 100 * (completedCount / packagesCount);
        let overallProgress = 0;
        let packageProgress = 0;

        if (fileProgress > 0) {
            // package share multiply by file progress
            // sample: package 1 out of 10 pacakges share is 10%, multiply by file progress value (0.0 to 1.0)
            packageProgress = (1 / packagesCount) * 100 * fileProgress;
        }

        overallProgress = progress + packageProgress;        
        try {
            if (sender) {
                sender.webContents.send("package:download_progress", overallProgress);
            }
        }
        catch (e) {
            this.log.error("reportDownloadProgress error: " + e);
            //swallow error 
        }
        return completedCount >= packagesCount;
    } 
}

