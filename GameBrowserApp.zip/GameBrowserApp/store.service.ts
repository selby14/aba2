import { BaseService } from './base.service';
import { app } from 'electron';
import { IPackage } from './common'
import * as pathHelper from "path";
import * as urlHelper from "url";
import * as _ from "lodash";
import * as Datastore from "nedb";

export class StoreService extends BaseService {    
    private tempStore: typeof Datastore;
    private localStore: typeof Datastore;
    private packagesKey: string = "gb_packages";
    private gamesKey: string = "gb_games";
    private userIdKey: string = "gb_userId";
    private packages: Array<IPackage>;

    constructor() {        
        super();  
        
        //initialize temp and persistent store
        const userData = app.getPath('userData');
        const storePath = userData + "/nedb/gbstore.db";

        this.localStore = new Datastore({ filename: storePath, autoload: true });
        this.tempStore = new Datastore();
        this.localStore.findOne({ _id: this.packagesKey }, (err, doc) => {
            if (doc && doc.packages) {
                this.packages = doc.packages as Array<IPackage>;
            }
            else {
                this.packages = [];
            }
        });        
    }  

    /**
    * Sets cache item
    * @param key   The cache key
    * @param value The cache value
    */
    setCache(key: string, value?: any) {        
        this.tempStore.update({ _id: key }, { _id: key, value: value }, { upsert: true });
    }

    /**
    * Gets item from cache
    * @param key The cache key
    */
    getCache(key: string): Promise<any> {
        let promise = new Promise<any>((resolve, reject) => {
            this.tempStore.findOne({ _id: key }, function (err, doc) {
                resolve(doc ? doc.value : null);
            });
        });
        return promise;
    }

    /**
    * Check if cache key exists
    * @param key The cache key
    */
    hasCacheKey(key: string): Promise<any> {    
        let promise = new Promise<any>((resolve, reject) => {
            this.tempStore.findOne({ _id: key }, function (err, doc) {
                resolve(doc ? true : false);            
            });
        });
        return promise;
    }
    
    /**
    * Removes item from cache
    * @param key The cache key
    */
    removeCache(key: string) {
        this.tempStore.remove({ _id: key });    
    }    

    /**
    * Adds/updates data to persistent store
    * @param key   The data key
    * @param value The data value
    */
    setLocalStore(key: string, value?: any) {
        this.localStore.findOne({ _id: key }, (err, doc) =>  {
            if (doc) {
                this.localStore.update({ _id: key }, { $set: { value: value } });
            } else {
                this.localStore.insert({ _id: key, value: value });
            }
        });
    }

    /**
    * Gets data from persistent store
    * @param key The data key
    */
    getLocalStore(key: string): Promise<any> {    
        let promise = new Promise<any>((resolve, reject) => {
            this.localStore.findOne({ _id: key }, function (err, doc) {
                resolve(doc ? doc.value : null);            
            });
        });
        return promise;
    }

    /**
    * Gets data from persistent store
    * @param key The data key
    */
    getLocalStoreNoPromise(key: string): any {
        this.localStore.findOne({ _id: key }, function (err, doc) {
            return (doc ? doc.value : null);
        });
    }

    /**
    * Check if local store key exists
    * @param key The store key
    */
    hasLocalStore(key: string): Promise<any> {    
        let promise = new Promise<any>((resolve, reject) => {
            this.localStore.findOne({ _id: key }, function (err, doc) {                
                resolve(doc ? true : false);            
            });
        });
        return promise;
    }

    /**
    * Removes item from local store
    * @param key The item key
    */
    removeLocalStore(key: string) {
        this.localStore.remove({ _id: key });    
    }

    /**
    * Adds/Updates the given package to packages store
    * @param pckg      The IPackage object
    */
    addPackage(pckg: IPackage) {        
        if (!pckg) { return; }
        if (!this.packages) {
            this.packages = [];                   
        }
        let idx = _.findIndex(this.packages, (p) => { return p.packageKey === pckg.packageKey && p.version === pckg.version; });
        if (idx > -1) {
            // update package
            this.packages[idx] = pckg;            
        } else {
            // add package
            this.packages.push(pckg);
        }
        this.localStore.update({ _id: this.packagesKey }, { _id: this.packagesKey, packages: this.packages }, { upsert: true });                        
    }

    /**
     * Adds/Updates the given array of packages to packages store
     * @param packages  The list of IPackage objects
     */
    addPackages(packages: Array<IPackage>) {     
        // if current packages is null or empty, just save given packages
        if (!this.packages || this.packages.length == 0) {
            this.packages = packages;
            this.localStore.update({ _id: this.packagesKey }, { _id: this.packagesKey, packages: packages }, { upsert: true });                
            return;
        }
        //Upsert each package
        _.forEach(packages, (pckg) => {
            let idx = _.findIndex(this.packages, (p) => { return p.packageKey === pckg.packageKey && p.version === pckg.version; });
            if (idx > -1) {
                // replace package
                this.packages[idx] = pckg;
            } else {
                // add package
                this.packages.push(pckg);
            }               
        });              
        this.localStore.update({ _id: this.packagesKey }, { _id: this.packagesKey, packages: this.packages }, { upsert: true });                
    }

    /**
     * Gets all packages in the packages store
     */
    getPackages(): Promise<Array<IPackage>> {
        let promise = new Promise<Array<IPackage>>((resolve, reject) => {
            if (this.packages) {
                resolve(this.packages);
                return;
            }
            this.localStore.findOne({ _id: this.packagesKey }, (err, doc) => {
                resolve(doc ? doc.packages as Array<IPackage> : null);
            });
        });
        return promise;
    }

    /**
    * Gets a package
    * @param packageKey    The package key
    * @param version       The package version
    */
    getPackage(packageKey: string, version: string): Promise<IPackage> {
        let promise = new Promise<IPackage>((resolve, reject) => {
            if (!this.packages) {
                resolve(null);
                return;
            }
            let idx = _.findIndex(this.packages, (p) => { return p.packageKey === packageKey && p.version === version; });
            if (idx > -1) {
                resolve(this.packages[idx] as IPackage);
            } else {
                resolve(null);
            }
        });
        return promise;
    }

    /**
    * Deletes package from packages store
    * @param packageKey      The package key
    * @param version      The package version
    */
    deletePackage(packageKey: string, version: string) {        
        if (!packageKey || !version || !this.packages) { return; }
        let idx = _.findIndex(this.packages, (p) => { return p.packageKey === packageKey && p.version === version; });            
        if (idx > -1) {                
            // delete only if found
            this.packages.splice(idx, 1);                
            this.localStore.update({ _id: this.packagesKey }, { _id: this.packagesKey, packages: this.packages }, { upsert: true });                
        }         
    }

    /**
    * Gets all games in the games store
    */
    getGames(): Promise<any> {
        let promise = new Promise<any>((resolve, reject) => {
            this.localStore.findOne({ _id: this.gamesKey }, function (err, doc) {
                resolve(doc ? doc.games : null);
            });
        });
        return promise;
    }
}

