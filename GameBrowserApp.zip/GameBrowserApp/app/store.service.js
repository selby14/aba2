"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var base_service_1 = require("./base.service");
var electron_1 = require("electron");
var _ = require("lodash");
var Datastore = require("nedb");
var StoreService = (function (_super) {
    __extends(StoreService, _super);
    function StoreService() {
        var _this = _super.call(this) || this;
        _this.packagesKey = "gb_packages";
        _this.gamesKey = "gb_games";
        _this.userIdKey = "gb_userId";
        //initialize temp and persistent store
        var userData = electron_1.app.getPath('userData');
        var storePath = userData + "/nedb/gbstore.db";
        _this.localStore = new Datastore({ filename: storePath, autoload: true });
        _this.tempStore = new Datastore();
        _this.localStore.findOne({ _id: _this.packagesKey }, function (err, doc) {
            if (doc && doc.packages) {
                _this.packages = doc.packages;
            }
            else {
                _this.packages = [];
            }
        });
        return _this;
    }
    /**
    * Sets cache item
    * @param key   The cache key
    * @param value The cache value
    */
    StoreService.prototype.setCache = function (key, value) {
        this.tempStore.update({ _id: key }, { _id: key, value: value }, { upsert: true });
    };
    /**
    * Gets item from cache
    * @param key The cache key
    */
    StoreService.prototype.getCache = function (key) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            _this.tempStore.findOne({ _id: key }, function (err, doc) {
                resolve(doc ? doc.value : null);
            });
        });
        return promise;
    };
    /**
    * Check if cache key exists
    * @param key The cache key
    */
    StoreService.prototype.hasCacheKey = function (key) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            _this.tempStore.findOne({ _id: key }, function (err, doc) {
                resolve(doc ? true : false);
            });
        });
        return promise;
    };
    /**
    * Removes item from cache
    * @param key The cache key
    */
    StoreService.prototype.removeCache = function (key) {
        this.tempStore.remove({ _id: key });
    };
    /**
    * Adds/updates data to persistent store
    * @param key   The data key
    * @param value The data value
    */
    StoreService.prototype.setLocalStore = function (key, value) {
        var _this = this;
        this.localStore.findOne({ _id: key }, function (err, doc) {
            if (doc) {
                _this.localStore.update({ _id: key }, { $set: { value: value } });
            }
            else {
                _this.localStore.insert({ _id: key, value: value });
            }
        });
    };
    /**
    * Gets data from persistent store
    * @param key The data key
    */
    StoreService.prototype.getLocalStore = function (key) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            _this.localStore.findOne({ _id: key }, function (err, doc) {
                resolve(doc ? doc.value : null);
            });
        });
        return promise;
    };
    /**
    * Gets data from persistent store
    * @param key The data key
    */
    StoreService.prototype.getLocalStoreNoPromise = function (key) {
        this.localStore.findOne({ _id: key }, function (err, doc) {
            return (doc ? doc.value : null);
        });
    };
    /**
    * Check if local store key exists
    * @param key The store key
    */
    StoreService.prototype.hasLocalStore = function (key) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            _this.localStore.findOne({ _id: key }, function (err, doc) {
                resolve(doc ? true : false);
            });
        });
        return promise;
    };
    /**
    * Removes item from local store
    * @param key The item key
    */
    StoreService.prototype.removeLocalStore = function (key) {
        this.localStore.remove({ _id: key });
    };
    /**
    * Adds/Updates the given package to packages store
    * @param pckg      The IPackage object
    */
    StoreService.prototype.addPackage = function (pckg) {
        if (!pckg) {
            return;
        }
        if (!this.packages) {
            this.packages = [];
        }
        var idx = _.findIndex(this.packages, function (p) { return p.packageKey === pckg.packageKey && p.version === pckg.version; });
        if (idx > -1) {
            // update package
            this.packages[idx] = pckg;
        }
        else {
            // add package
            this.packages.push(pckg);
        }
        this.localStore.update({ _id: this.packagesKey }, { _id: this.packagesKey, packages: this.packages }, { upsert: true });
    };
    /**
     * Adds/Updates the given array of packages to packages store
     * @param packages  The list of IPackage objects
     */
    StoreService.prototype.addPackages = function (packages) {
        var _this = this;
        // if current packages is null or empty, just save given packages
        if (!this.packages || this.packages.length == 0) {
            this.packages = packages;
            this.localStore.update({ _id: this.packagesKey }, { _id: this.packagesKey, packages: packages }, { upsert: true });
            return;
        }
        //Upsert each package
        _.forEach(packages, function (pckg) {
            var idx = _.findIndex(_this.packages, function (p) { return p.packageKey === pckg.packageKey && p.version === pckg.version; });
            if (idx > -1) {
                // replace package
                _this.packages[idx] = pckg;
            }
            else {
                // add package
                _this.packages.push(pckg);
            }
        });
        this.localStore.update({ _id: this.packagesKey }, { _id: this.packagesKey, packages: this.packages }, { upsert: true });
    };
    /**
     * Gets all packages in the packages store
     */
    StoreService.prototype.getPackages = function () {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            if (_this.packages) {
                resolve(_this.packages);
                return;
            }
            _this.localStore.findOne({ _id: _this.packagesKey }, function (err, doc) {
                resolve(doc ? doc.packages : null);
            });
        });
        return promise;
    };
    /**
    * Gets a package
    * @param packageKey    The package key
    * @param version       The package version
    */
    StoreService.prototype.getPackage = function (packageKey, version) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            if (!_this.packages) {
                resolve(null);
                return;
            }
            var idx = _.findIndex(_this.packages, function (p) { return p.packageKey === packageKey && p.version === version; });
            if (idx > -1) {
                resolve(_this.packages[idx]);
            }
            else {
                resolve(null);
            }
        });
        return promise;
    };
    /**
    * Deletes package from packages store
    * @param packageKey      The package key
    * @param version      The package version
    */
    StoreService.prototype.deletePackage = function (packageKey, version) {
        if (!packageKey || !version || !this.packages) {
            return;
        }
        var idx = _.findIndex(this.packages, function (p) { return p.packageKey === packageKey && p.version === version; });
        if (idx > -1) {
            // delete only if found
            this.packages.splice(idx, 1);
            this.localStore.update({ _id: this.packagesKey }, { _id: this.packagesKey, packages: this.packages }, { upsert: true });
        }
    };
    /**
    * Gets all games in the games store
    */
    StoreService.prototype.getGames = function () {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            _this.localStore.findOne({ _id: _this.gamesKey }, function (err, doc) {
                resolve(doc ? doc.games : null);
            });
        });
        return promise;
    };
    return StoreService;
}(base_service_1.BaseService));
exports.StoreService = StoreService;
//# sourceMappingURL=store.service.js.map