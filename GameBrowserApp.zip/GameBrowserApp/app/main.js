"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var electron_1 = require("electron");
var store_service_1 = require("./store.service");
var electron_service_1 = require("./electron.service");
var electron_updater_1 = require("electron-updater");
var isOnline = require("is-online");
var pathHelper = require("path");
var fs = require("fs");
var child_process = require("child_process");
var isDev = require("electron-is-dev");
var _ = require("lodash");
/**
    * Set variables needed
*/
var mainWindow, newWindow, modalWindow, windowTracker, storeSvc, electronSvc, errorMsg, errorBg, errorModalUrl, landingPageAppKey;
var args = process.argv.slice(1);
var serve = args.some(function (val) { return val === '--serve'; });
var isMac = process.platform === 'darwin';
var isUpdating = false;
var hasError = false;
/**
    * Set window variables
*/
var size = { height: 720, width: 1280 };
var initialUrl = __dirname + "/index.html";
var modalUrl = __dirname + "/modal.html";
var loadingModalUrl = __dirname + "/loading.html";
var landingPagePromptUrl = __dirname + "/landingPagePrompt.html";
if (serve) {
    require('electron-reload')(__dirname, {});
}
function init() {
    storeSvc = new store_service_1.StoreService();
    electronSvc = new electron_service_1.ElectronService();
    createMenu();
    createWindow();
}
/**
    * Creates the electron menu

*/
function createMenu() {
    var template = [
        {
            label: 'Game Browser',
            submenu: [
                {
                    label: 'Exit',
                    accelerator: process.platform === 'darwin' ? 'Command+Q' : 'Ctrl+Q',
                    click: function () {
                        electron_1.app.quit();
                    }
                }
            ]
        }
    ];
    // add blank menu for mac os
    //if (process.platform === 'darwin') {
    //    template.unshift({});
    //}   
    // add View menu if not production
    if (process.env.NODE_ENV !== 'production') {
        template.push({
            label: 'View',
            submenu: [
                { role: 'reload' },
                {
                    label: 'Toggle Developer Tools',
                    accelerator: process.platform === 'darwin' ? 'Command+Alt+I' : 'Ctrl+Shift+I',
                    click: function (item, focusedWindow) {
                        focusedWindow.toggleDevTools();
                    }
                }
            ]
        });
    }
    var mainMenu = electron_1.Menu.buildFromTemplate(template);
    electron_1.Menu.setApplicationMenu(mainMenu);
}
/**
    * Creates the main browser window.
*/
function createWindow() {
    mainWindow = new electron_1.BrowserWindow({
        center: true,
        width: size.width,
        height: size.height,
        minHeight: size.height,
        minWidth: size.width,
        show: false,
        title: "Game Browser",
        icon: pathHelper.join(__dirname, 'assets/icons/png/FlashPoint-Icon_64x64.png')
    });
    // load index.html
    // index.html includes a webView tag that brings in external websites.
    // the initially loaded external site is the loading.html in the app folder.
    // also loads the renderer.js script which sets a listener for currentUrl to load.
    // the webview includes the preload.js file, which securely bridges the communication from the external app to electron 
    loadMainWindow(initialUrl);
    // Open the DevTools.
    if (serve) {
        mainWindow.webContents.openDevTools();
    }
    // Emitted when the window is closed.
    mainWindow.on('closed', function () {
        mainWindow = null;
    });
    // In production, the auto-updater will run and when finished call the getLandingPage function
    if (!isDev) {
        electron_updater_1.autoUpdater.checkForUpdates();
    }
    else {
        getLandingPage();
    }
}
/**
    * Loads given url into the main window
    * @param url        url to load

*/
function loadMainWindow(url) {
    mainWindow.loadURL(url);
    mainWindow.once('ready-to-show', function () {
        mainWindow.show();
    });
}
/**
    * Get the initial landing page (hubs) configUrl. Checks the local storage first, then the defaultConfig. If none found, calls for landing page prompt
*/
function getLandingPage() {
    // check local store for landingPageConfigUrl
    var configUrl = storeSvc.getLocalStore('landingPageAppUrl').then(function (url) {
        if (url) {
            console.log("got config url from store: ", url);
            loadApp(url, {}, mainWindow);
        }
        else {
            electronSvc.setDefaultAppUrls().then(function (url) {
                closeModal();
                configUrl = url;
                electronSvc.log.info("configUrl: " + configUrl);
                loadApp(configUrl, {}, mainWindow);
            })
                .catch(function (error) {
                createErrorModal("", "", landingPagePromptUrl);
                electronSvc.log.error("getLandingPage: " + error);
            });
        }
    });
}
/**
    * Downloads config json and loads the resulting app
    * @param configUrl       The url to app config file
    * @param sender    The electron window making the original request
*/
function loadApp(configUrl, options, sender) {
    if (options === void 0) { options = {}; }
    if (sender === void 0) { sender = mainWindow; }
    var config;
    // check if connected to network
    isOnline().then(function (online) {
        if (online) {
            electronSvc.getAppConfig(configUrl).then(function (result) {
                config = typeof result === "string" ? JSON.parse(result) : result;
                electronSvc.log.info("loadApp: configUrl" + configUrl);
                if (config) {
                    var appType = config.appType;
                    if (appType === 'LandingPageApp') {
                        landingPageAppKey = config.appKey;
                    }
                    var _packages = config.gameBrowser.packages;
                    var launchConfig = (isMac) ? _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'darwin'; }) : _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'win32'; });
                    // store in local storage
                    storeSvc.setLocalStore(configUrl, config);
                    // if appType = Remote, load url
                    if (launchConfig.launchType === "Remote") {
                        launchApp(config, options, sender);
                    }
                    // if appType = Package
                    if (launchConfig.launchType === "Package") {
                        console.log("loadApp landingPageAppKey: ", landingPageAppKey);
                        // get package list and download                 
                        electronSvc.downloadPackages(sender, _packages, landingPageAppKey, config.gameBrowser.basePath).then(function (result) {
                            electronSvc.log.info("loadApp - download_complete" + result);
                            sender.webContents.send("package:download_complete", true);
                            launchApp(config, options, sender);
                        })
                            .catch(function (error) {
                            electronSvc.log.error("loadApp: error: " + error);
                            sender.webContents.send("app:showError", error);
                        });
                    }
                }
                else {
                    //handle no config
                    electronSvc.log.error("loadApp: error: The config file was not found.");
                    //sender.webContents.send("app:showError", "The config file was not found.");
                    createErrorModal("", "", landingPagePromptUrl);
                }
            })
                .catch(function (error) {
                electronSvc.log.error("loadApp: error: " + error);
                createErrorModal("", "", landingPagePromptUrl);
            });
        }
        else {
            // if not connected
            // is it in local storage
            electronSvc.log.error('loadApp: offline');
            if (storeSvc.hasLocalStore(configUrl)) {
                storeSvc.getLocalStore(configUrl)
                    .then(function (value) {
                    config = value;
                    var launchConfig = (isMac) ? _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'darwin'; }) : _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'win32'; });
                    electronSvc.log.error("loadApp: offline: " + config);
                    // yes, remote
                    if (launchConfig.launchType === "Remote") {
                        networkConnectionPrompt();
                    }
                    // Package, validate that files have been downloaded
                    if (launchConfig.launchType === "Package") {
                        var landingPageAppKey_1 = (config.appType === 'landingPageApp') ? config.appKey : storeSvc.getLocalStore("LandingPageApp")['appKey'];
                        var _packages = config.gameBrowser.packages;
                        electronSvc.validatePackagesAreDownloaded(sender, _packages, landingPageAppKey_1).then(function (result) {
                            if (result) {
                                launchApp(config, options, sender);
                            }
                            else {
                                networkConnectionPrompt();
                            }
                        });
                    }
                })
                    .catch(function (error) {
                    electronSvc.log.error("loadApp: offline: " + error);
                    mainWindow.webContents.send('store:get_response', null);
                });
            }
            else {
                // no, prompt for network connection
                electronSvc.log.error("Calling no network connection prompt.");
                networkConnectionPrompt();
            }
        }
    });
}
/**
    * launching the app
    * @param configUrl       The url to app config file
    * @param sender    The electron window making the original request
*/
function launchApp(config, options, sender) {
    if (options === void 0) { options = {}; }
    var launchConfig = (isMac) ? _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'darwin'; }) : _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'win32'; });
    electronSvc.log.info("launchApp - options: " + options);
    electronSvc.log.info('launchConfig.appParams: ' + launchConfig.appParams);
    var args = {};
    if (launchConfig.appParams) {
        args = _.merge(launchConfig.appParams, options);
    }
    // remote 
    if (launchConfig.launchType === "Remote") {
        var searchParams = getSearchStringFromArgs(args);
        var path = require('url').format({
            search: searchParams,
            pathname: launchConfig.remoteUrl
        });
        electronSvc.log.info('path: ' + path);
        createOrLoadWindow(config, path);
    }
    // package
    if (launchConfig.launchType === "Package") {
        var appKey = (config.appType === 'LandingPageApp') ? config.appKey : storeSvc.getLocalStore("LandingPage")['appKey'];
        var _args = convertDictionaryToArray(args);
        // launch app
        // check if initial file is opening in an electron window or is a process
        var initialFile = pathHelper.join(electronSvc.rootDataPath, landingPageAppKey, "packages", launchConfig.package.packageKey, launchConfig.package.version, launchConfig.package.initialFile);
        electronSvc.log.info("initialFile: " + initialFile);
        var target = launchConfig.launchTarget;
        if (target === "Process") {
            sender.webContents.send("game:launch_started", true);
            child_process.execFile(initialFile, _args, null, function (error, stdout, stderr) {
                if (error) {
                    electronSvc.log.error("game:launch: " + error);
                    mainWindow.webContents.send("app:showError", error);
                    sender.webContents.send("game:launch_complete", false);
                }
                else {
                    electronSvc.log.info("game:launch_complete");
                    sender.webContents.send("game:launch_complete", true);
                }
            });
        }
        else {
            // get local path and load
            var searchParams = getSearchStringFromArgs(launchConfig.appParams);
            var localPath = require('url').format({
                protocol: 'file',
                slashes: true,
                search: searchParams,
                pathname: require('path').join(electronSvc.rootDataPath, appKey, "packages", launchConfig.package.packageKey, launchConfig.package.version, initialFile)
            });
            electronSvc.log.info("local path: " + localPath);
            createOrLoadWindow(config, localPath);
        }
    }
}
/**
    * Determines if a new electron window is required and loads the given url
    * @param configUrl       The url to app config file
    * @param url             The url to load into window
*/
function createOrLoadWindow(config, url) {
    var params, wHeight, wWidth;
    var launchConfig = (isMac) ? _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'darwin'; }) : _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'win32'; });
    var newWindow = (launchConfig.launchTarget === "newWindow");
    // if launchTarget is newWindow, check parameters for window parameters
    if (newWindow) {
        // if launchTarget is newWindow, check parameters for window parameters
        params = launchConfig.launchParams;
        for (var _i = 0, params_1 = params; _i < params_1.length; _i++) {
            var param = params_1[_i];
            if (param['windowHeight']) {
                wHeight = param['windowHeight'];
            }
            if (param['windowWidth']) {
                wWidth = param['windowWidth'];
            }
        }
        loadNewWindow(url, { height: wHeight, width: wWidth });
    }
    else {
        // set currentPage in temp store to be requested by the renderer to load into webview
        storeSvc.setCache('currentUrl', url);
        electronSvc.log.info('setCache: currentUrl ' + url);
        mainWindow.webContents.send('app:loadUrl', url);
    }
}
/**
    * Creates a "modal" window that is placed directly over the main window
    * @param msg        The message that is placed in the modal div
    * @param bgColor    Sets the background of the modal div. defaults to black
    * @param url        Sets the url to load into the window. defaults to modal.html
*/
function createErrorModal(msg, bgColor, url, flagAsError) {
    if (msg === void 0) { msg = ''; }
    if (bgColor === void 0) { bgColor = 'black'; }
    if (url === void 0) { url = modalUrl; }
    if (flagAsError === void 0) { flagAsError = true; }
    hasError = flagAsError;
    errorMsg = msg;
    errorBg = bgColor;
    errorModalUrl = url;
    var mainWindowPosition = mainWindow.getPosition();
    var defaultOptions = {
        parent: mainWindow,
        modal: false,
        show: false,
        transparent: true,
        frame: false,
        backgroundColor: 'red'
    };
    // check if there is an existing window
    if (modalWindow && !modalWindow.isDestroyed()) {
        modalWindow.loadURL(errorModalUrl);
    }
    else {
        modalWindow = new electron_1.BrowserWindow(defaultOptions);
        console.log('modal window url: ', errorModalUrl);
        modalWindow.loadURL(errorModalUrl);
    }
    modalWindow.once('ready-to-show', function () {
        modalWindow.setContentBounds(mainWindow.getContentBounds());
        sendStatusToWindow(errorMsg, errorBg);
        modalWindow.show();
        // open dev tools
        if (serve) {
            // modalWindow.webContents.openDevTools();
        }
        mainWindow.webContents.send('overlayWindow:opened', null);
    });
    // set a watch for the mainWindow on 'move', so we can keep the child windows in sync (just for Windows)
    if (process.platform === 'win32') {
        trackMainWindow();
    }
}
/**
    * Loads given url into a new window
    * @param url        url to load
    * @param params     dictionary object that can include height and width of new window

*/
function loadNewWindow(url, params) {
    var defaultOptions = {
        parent: mainWindow,
        modal: false,
        show: false,
        height: (params && params.height) ? params.height : size.height,
        width: (params && params.width) ? params.width : size.width
    };
    // check if there is an existing window
    if (newWindow && !newWindow.isDestroyed()) {
        storeSvc.setCache('currentUrl', url);
        newWindow.webContents.send('app:loadUrl', url);
    }
    else {
        newWindow = new electron_1.BrowserWindow(defaultOptions);
    }
    newWindow.loadURL(initialUrl);
    newWindow.show();
    // open dev tools
    if (serve) {
        //  newWindow.webContents.openDevTools();
    }
    storeSvc.setCache('currentUrl', url);
    newWindow.once('ready-to-show', function () {
        newWindow.webContents.send('app:loadUrl', url);
    });
}
/**
    * Closes the modal window
*/
function closeModal() {
    if (modalWindow && !modalWindow.isDestroyed()) {
        console.log("closing modal window");
        modalWindow.close();
    }
    if (windowTracker && !(modalWindow && !modalWindow.isDestroyed())) {
        mainWindow.removeListener('move', handleWindowMove);
    }
}
/**
    * Tracks the main window movement to keep the modal in place
*/
function trackMainWindow() {
    // remove potential listener first
    mainWindow.removeListener('move', handleWindowMove);
    windowTracker = mainWindow.on('move', handleWindowMove);
}
/**
    * Keeps the modal window in place
*/
function handleWindowMove() {
    if (modalWindow && !modalWindow.isDestroyed()) {
        modalWindow.setContentBounds(mainWindow.getContentBounds());
    }
    if (modalWindow && !modalWindow.isDestroyed()) {
        var bounds = mainWindow.getContentBounds();
        var _x = calculateX(bounds.width);
        var _y = calculateY(bounds.height);
    }
}
/**
    * Used by handleWindowMove to calculate the position for the modal.
    * Takes into account the size difference between a window with a frame and the modal that does not have a frame.
*/
function calculateX(width) {
    var mainWindowPosition = mainWindow.getPosition();
    var dif = Math.round((size.width - width) / 2);
    return mainWindowPosition[0] + dif;
}
/**
    * Used by handleWindowMove to calculate the position for the modal.
    * Takes into account the size difference between a window with a frame and the modal that does not have a frame.
*/
function calculateY(height) {
    var mainWindowPosition = mainWindow.getPosition();
    var dif = Math.round((size.height - height) / 2);
    return mainWindowPosition[1] + dif;
}
/**
    * Gets the current url from the cache and emits back to the index page.
    * This function handles the event call from the index page for the currentUrl.
    * This will be called when the index page first loads and if the user forces a refresh of the page.
    * Checks if there is an error first and if so, pushes the saved error data.
*/
function getCurrentUrl() {
    if (!hasError) {
        var url = storeSvc.getCache("currentUrl").then(function (url) {
            mainWindow.webContents.send('app:loadUrl', url);
        });
    }
    else {
        createErrorModal(errorMsg, errorBg, errorModalUrl);
    }
}
/**
    * generic method to send messages to the modal window. Allows for changing the background color of the message div.
    * @param text       text of the message to send to the modal window to display
    * @param bgColor    sets the background color of the message div of the modal window, default is black
*/
function sendStatusToWindow(text, bgColor) {
    if (bgColor === void 0) { bgColor = 'black'; }
    modalWindow.webContents.send('app:message', text, bgColor);
}
/**
    * Displays an error modal with the message of needing an internet connection to run.
*/
function networkConnectionPrompt() {
    createErrorModal('You need to be connected to the internet.', 'red');
}
/**
    * url encodes dictionary objects
    * @param args             Dictionary object of parameters
*/
function getSearchStringFromArgs(args) {
    var params = [];
    var key;
    _.forIn(args, function (value, key) {
        params.push(key + "=" + value);
    });
    return encodeURI("?" + params.join("&"));
}
/**
    * converts dictionary objects to a stringified array
    * @param obj             Dictionary object of parameters
*/
function convertDictionaryToArray(obj) {
    var output = Object.keys(obj).map(function (key) {
        return JSON.stringify({ 'key': key, 'value': (typeof obj[key] === 'string') ? obj[key] : JSON.stringify(obj[key]) });
    });
    return output;
}
function formatStoreDataForIPC(key, value) {
    return { key: key, value: value };
}
try {
    // This method will be called when Electron has finished
    // initialization and is ready to create browser windows.
    // Some APIs can only be used after this event occurs.
    electron_1.app.on('ready', function () {
        init();
    });
    // Quit when all windows are closed.
    electron_1.app.on('window-all-closed', function () {
        // On OS X it is common for applications and their menu bar
        // to stay active until the user quits explicitly with Cmd + Q
        if (process.platform !== 'darwin') {
            electron_1.app.quit();
        }
    });
    electron_1.app.on('activate', function () {
        // On OS X it's common to re-create a window in the app when the
        // dock icon is clicked and there are no other windows open.
        if (mainWindow === null) {
            init();
        }
    });
    /// AUTO UPDATER EVENTS
    electron_updater_1.autoUpdater.on('checking-for-update', function () {
        isUpdating = true;
        createErrorModal('Checking for update...', '', modalUrl, false);
        electronSvc.log.warn("Checking for update...");
    });
    electron_updater_1.autoUpdater.on('update-available', function (info) {
        sendStatusToWindow('Update available.');
        electronSvc.log.warn("Update Available");
    });
    electron_updater_1.autoUpdater.on('update-not-available', function (info) {
        isUpdating = false;
        electronSvc.log.warn("update-not-available");
        closeModal();
        getLandingPage();
    });
    electron_updater_1.autoUpdater.on('error', function (err) {
        isUpdating = false;
        electronSvc.log.error("auto-updater: " + err);
        sendStatusToWindow('There was an error checking for updates. ', 'red');
        getLandingPage();
    });
    electron_updater_1.autoUpdater.on('download-progress', function (progressObj) {
        var log_message = 'Downloading files: ' + Math.round(progressObj.percent) + '%';
        sendStatusToWindow(log_message);
    });
    electron_updater_1.autoUpdater.on('update-downloaded', function (info) {
        electronSvc.log.info("autoUpdater: update - downloaded");
        sendStatusToWindow('Update downloaded; will install in 5 seconds');
        setTimeout(function () {
            electron_updater_1.autoUpdater.quitAndInstall();
        }, 5000);
    });
    ///END AUTO UPDATER EVENTS
    /// STORE EVENTS
    /// Event: cache:set
    electron_1.ipcMain.on('cache:set', function (event, key, value) {
        console.log("Saving to cache: key ", key);
        storeSvc.setCache(key, value);
    });
    /// Event: cache:get
    electron_1.ipcMain.on('cache:get', function (event, key) {
        storeSvc.getCache(key)
            .then(function (value) {
            console.log("cache:get", key, value);
            event.sender.webContents.send('cache:get_response', formatStoreDataForIPC(key, value));
        })
            .catch(function (error) {
            electronSvc.log.error("cache:get: error: " + error);
            event.sender.webContents.send('cache:get_response', null);
        });
    });
    /// Event: cache:remove
    electron_1.ipcMain.on('cache:remove', function (event, key) {
        storeSvc.removeCache(key);
    });
    /// Event: store:set
    electron_1.ipcMain.on('store:set', function (event, key, value) {
        storeSvc.setLocalStore(key, value);
        event.sender.webContents.send('store:set_response', formatStoreDataForIPC(key, value));
    });
    /// Event: store:get
    electron_1.ipcMain.on('store:get', function (event, key) {
        storeSvc.getLocalStore(key)
            .then(function (value) {
            console.log("store:get", key, value);
            event.sender.webContents.send('store:get_response', formatStoreDataForIPC(key, value));
        })
            .catch(function (error) {
            electronSvc.log.error("store:get: error: " + error);
            event.sender.webContents.send('store:get_response', null);
        });
    });
    /// Event: store:remove
    electron_1.ipcMain.on('store:remove', function (event, key) {
        storeSvc.removeLocalStore(key);
    });
    ///END STORE EVENTS
    /// LOG EVENTS
    /// Event: log:error
    electron_1.ipcMain.on("log:error", function (event, error) {
        electronSvc.log.error(error);
    });
    /// Event: log:info
    electron_1.ipcMain.on("log:info", function (event, info) {
        electronSvc.log.info(info);
    });
    /// Event: log:warn
    electron_1.ipcMain.on("log:warn", function (event, warning) {
        electronSvc.log.warn(warning);
    });
    /// END LOG EVENTS
    /// APP EVENTS
    /// Event: app:load
    electron_1.ipcMain.on("app:load", function (event, configUrl, options) {
        if (options === void 0) { options = {}; }
        electronSvc.log.info("app:load: " + configUrl);
        loadApp(configUrl, options, event.sender);
    });
    electron_1.ipcMain.on("app:getCurrentUrl", function (event) {
        getCurrentUrl();
    });
    electron_1.ipcMain.on('app:closeModal', function (event) {
        closeModal();
    });
    electron_1.ipcMain.on('app:refresh', function (event) {
        closeModal();
        getLandingPage();
    });
    electron_1.ipcMain.on('webView:dom-ready', function (event) {
        // check to see if updating app, if not, close the modal window
        if (!isUpdating && !hasError) {
            closeModal();
        }
    });
    electron_1.ipcMain.on("app:submitLandingPageUrl", function (event, url) {
        storeSvc.setLocalStore("landingPageAppUrl", url);
        hasError = false;
        loadApp(url, {}, mainWindow);
        closeModal();
    });
    /// Event: app:isInstalled
    electron_1.ipcMain.on("app:isInstalled", function (event, appKey, version, hub) {
        if (version === void 0) { version = ""; }
        if (hub === void 0) { hub = ""; }
    });
    /// Event: app:isPackageInstalled
    electron_1.ipcMain.on("app:isPackageInstalled", function (event, packageKey, version, hub) {
        if (version === void 0) { version = ""; }
        if (hub === void 0) { hub = ""; }
    });
    /// Event: app:getLatestPackageVersion
    electron_1.ipcMain.on("app:getLatestPackageVersion", function (event, packageKey, hub) {
        if (hub === void 0) { hub = ""; }
    });
    /// Event: app:getLatestAppVersion
    electron_1.ipcMain.on("app:getLatestAppVersion", function (event, appKey, hub) {
        if (hub === void 0) { hub = ""; }
    });
    /// Event: app:downLoadPackage
    electron_1.ipcMain.on("app:downLoadPackage", function (event, appKey, version, url, hub) {
        if (hub === void 0) { hub = ""; }
    });
    /// Event: app:getHubPath
    electron_1.ipcMain.on("app:getHubPath", function (event, hub) {
        if (hub === void 0) { hub = ""; }
    });
    /// Event: app:getPackagePaths
    electron_1.ipcMain.on("app:getPackagePath", function (event, packageKey, version, hub) {
        if (version === void 0) { version = ""; }
        if (hub === void 0) { hub = ""; }
    });
    electron_1.ipcMain.on("app:printToPDF", function (event) {
        event.sender.webContents.send('webview:showSaveDialog');
        mainWindow.webContents.send('webview:showSaveDialog');
    });
    electron_1.ipcMain.on("app:showSaveDialog_response", function (event, filename, data) {
        electronSvc.log.info("app:showSaveDialog_response: " + filename);
        fs.writeFile(filename, data, function (error) {
            if (error)
                throw error;
            mainWindow.send('app:pdf_success', true);
        });
        mainWindow.send('app:pdf_success', true);
    });
    /// END APP EVENTS
}
catch (e) {
    electronSvc.log.error("main try/catch error: " + e);
}
//# sourceMappingURL=main.js.map