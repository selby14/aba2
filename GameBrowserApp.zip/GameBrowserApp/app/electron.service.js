"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
var base_service_1 = require("./base.service");
var store_service_1 = require("./store.service");
var pathHelper = require("path");
var urlHelper = require("url");
var request = require("request");
var progressRequest = require("request-progress");
var fs = require("fs");
var gfs = require("graceful-fs");
var unzip = require("unzip");
var _ = require("lodash");
var ElectronService = (function (_super) {
    __extends(ElectronService, _super);
    function ElectronService() {
        var _this = _super.call(this) || this;
        _this.defaultsConfigFilePath = __dirname + "/defaultsConfig.json";
        return _this;
    }
    /**
     * Returns json object that contains defaults
     */
    ElectronService.prototype.setDefaultAppUrls = function () {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            var storeSvc = new store_service_1.StoreService();
            try {
                var content = gfs.readFileSync(_this.defaultsConfigFilePath).toString();
                if (content) {
                    var _defaultsJson = JSON.parse(content);
                    if (_defaultsJson) {
                        storeSvc.setLocalStore("landingPageAppUrl", _defaultsJson.landingPageAppDefaultUrl);
                        resolve(_defaultsJson.landingPageAppDefaultUrl);
                    }
                }
                else {
                    _this.log.error("setDefaultAppUrls: content error - no default config");
                    reject("setDefaultAppUrls: content error - ");
                }
            }
            catch (err) {
                _this.log.error("setDefaultAppUrls: error - " + err.message);
                reject(err.message);
            }
        });
        return promise;
    };
    /**
     * Downloads config json and loads the resulting app
     * @param configUrl       The url to app config file
     */
    ElectronService.prototype.getAppConfig = function (configUrl) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            _this.log.info('configUrl, configUrl');
            request.get(configUrl, function (error, response, body) {
                if (error || response.statusCode != 200) {
                    var error_msg = "url: " + configUrl + "    :  error: " + error || body.message;
                    _this.log.error("getConfig: ", error || body.message);
                    //this.hanldeError(error || body.message)
                    reject(error || body.message);
                }
                else {
                    resolve(body);
                }
            });
        });
        return promise;
    };
    /**
   * Downloads packages
   * @param sender     The BrowserWindow that sent the message
   * @param packages   The list of packages
   */
    ElectronService.prototype.downloadPackages = function (sender, packages, landingPageAppKey, basePath) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            var totalFileCount = 0;
            var completedCount = 0;
            var progress = 0;
            if (!packages) {
                _this.log.error("downloadPackages: error: argument 'packages' is null");
                reject();
            }
            if (!packages.length) {
                if (_this.reportDownloadProgress(sender, 1, 1)) {
                    resolve({});
                    return;
                }
            }
            totalFileCount = packages.length;
            // Download each package
            _.forEach(packages, function (_package) {
                // Ignore invalid package and OnDemand packaes
                if (!_package.url || !_package.packageKey || _package.onDemand) {
                    completedCount += 1;
                    if (_this.reportDownloadProgress(sender, completedCount, totalFileCount)) {
                        resolve({});
                        return false; // break out of forEach
                    }
                    return; // continue forEach
                }
                var destPath = _this.getPackageLocalPath(_package, landingPageAppKey);
                // Check if package exists
                if (fs.existsSync(destPath)) {
                    completedCount += 1;
                    if (_this.reportDownloadProgress(sender, completedCount, totalFileCount)) {
                        resolve({});
                        return false; // break out of forEach
                    }
                    return; // continue forEach
                }
                _this.ensureDirectoryExistence(destPath);
                var fileStream = fs.createWriteStream(destPath);
                var _path = (basePath && basePath.length > 0) ? basePath + _package.url : _package.url;
                _this.log.info("request path:" + _path);
                var req = request({
                    method: 'GET',
                    uri: (basePath && basePath.length > 0) ? basePath + _package.url : _package.url
                });
                var progreq = progressRequest(req, {});
                progreq.on("progress", function (state) {
                    // The state is an object that looks like this: 
                    // { 
                    //     percent: 0.5,               // Overall percent (between 0 to 1) 
                    //     speed: 554732,              // The download speed in bytes/sec 
                    //     size: { 
                    //         total: 90044871,        // The total payload size in bytes 
                    //         transferred: 27610959   // The transferred payload size in bytes 
                    //     }, 
                    //     time: { 
                    //         elapsed: 36.235,        // The total elapsed seconds since the start (3 decimals) 
                    //         remaining: 81.403       // The remaining seconds to finish (3 decimals) 
                    //     } 
                    // } 
                    _this.reportDownloadProgress(sender, completedCount, totalFileCount, state.percent);
                });
                progreq.on("error", function (error) {
                    _this.log.error("downloadPackages: package " + _package.packageKey + " download error:", error);
                });
                progreq.pipe(fileStream);
                progreq.on("end", function () {
                    completedCount += 1;
                    // Unzip if zip file
                    if (pathHelper.extname(destPath).toLowerCase() === ".zip") {
                        _this.unzipFile(destPath).then(function (result) {
                            if (_this.reportDownloadProgress(sender, completedCount, totalFileCount)) {
                                resolve({});
                                return false; // break out of forEach
                            }
                        })
                            .catch(function (error) {
                            _this.log.error("downloadPackages - unzipped error: " + error);
                            sender.webContents.send("app:showError", error);
                        });
                    }
                    else {
                        if (_this.reportDownloadProgress(sender, completedCount, totalFileCount)) {
                            resolve({});
                            return false; // break out of forEach
                        }
                    }
                });
            });
        });
        return promise;
    };
    /**
    * Validate that all packages have been downloaded, and if not, download
    * @param sender    The electron window making the original request
    * @param packages  The list of packages needed
    * @param landingPageAppkey    The current hubkey
    */
    ElectronService.prototype.validatePackagesAreDownloaded = function (sender, packages, landingPageAppKey) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            var upToDate = true;
            _.forEach(packages, function (_package) {
                // Ignore invalid package and OnDemand packaes
                if (!_package.url || !_package.packageKey || !_package.onDemand) {
                    return; // continue forEach
                }
                var destPath = _this.getPackageLocalPath(_package, landingPageAppKey);
                // Check if package exists
                if (fs.existsSync(destPath)) {
                    return; // continue forEach
                }
                else {
                    upToDate = false;
                    resolve(false);
                    return false; // break out of forEach
                }
            });
            resolve(true);
        });
        return promise;
    };
    /**
     * Download the url content to a file
     * @param url       The url to download
     * @param destPath  The destination path
     * @param unzip     The flag to unzip if zip file
     */
    ElectronService.prototype.downloadUrl = function (url, destPath, unzip) {
        var _this = this;
        if (unzip === void 0) { unzip = false; }
        var promise = new Promise(function (resolve, reject) {
            if (!url) {
                reject("invalid argument: 'url'");
            }
            if (!destPath) {
                reject("invalid argument: 'destPath'");
            }
            _this.ensureDirectoryExistence(destPath);
            var fileStream = fs.createWriteStream(destPath);
            var req = request({
                method: 'GET',
                uri: url
            });
            req.on("error", function (error) {
                _this.log.error("downloadUrl: " + url + " download error:", error);
                reject(error);
            });
            req.pipe(fileStream);
            req.on("end", function () {
                // Unzip if applicable
                if (unzip === true && pathHelper.extname(destPath).toLowerCase() === ".zip") {
                    _this.unzipFile(destPath).then(function () { resolve({}); }).catch(function (e) { reject(e); });
                }
                else {
                    resolve({});
                }
            });
        });
        return promise;
    };
    /**
    * Unzips a given zip file
    * @param zipFilePath    The zip file path
    * @param destPath       The destination path. Optional
    */
    ElectronService.prototype.unzipFile = function (zipFilePath, destPath) {
        var _this = this;
        var promise = new Promise(function (resolve, reject) {
            try {
                // ignore invalid or non-existing input
                if (!zipFilePath || !fs.existsSync(zipFilePath)) {
                    console.log("unzip ignore");
                    resolve(zipFilePath);
                    return;
                }
                var finalDestPath_1 = destPath ? pathHelper.dirname(destPath) : pathHelper.dirname(zipFilePath);
                _this.log.info('zipFilePath: ' + zipFilePath);
                fs.createReadStream(zipFilePath)
                    .pipe(unzip.Extract({ path: finalDestPath_1 }))
                    .on("close", function () {
                    console.log('file unzipped');
                    resolve(finalDestPath_1);
                });
            }
            catch (e) {
                _this.log.error('file unzipped error: ' + e);
                reject(e);
            }
        });
        return promise;
    };
    /**
    * Gets package's local destination path
    * @param _package   The package object
    */
    ElectronService.prototype.getPackageLocalPath = function (_package, landingPageAppKey) {
        if (landingPageAppKey === void 0) { landingPageAppKey = ""; }
        var parsed = urlHelper.parse(_package.url);
        var filename = pathHelper.basename(parsed.pathname);
        this.log.info("getPackageLocalPath: " + filename);
        return pathHelper.join(this.rootDataPath, landingPageAppKey, "packages", _package.packageKey, _package.version, filename);
    };
    /**
    * Reports download progress and returns true if completed otherwise false
    */
    ElectronService.prototype.reportDownloadProgress = function (sender, completedCount, packagesCount, fileProgress) {
        if (fileProgress === void 0) { fileProgress = 0.0; }
        var progress = 100 * (completedCount / packagesCount);
        var overallProgress = 0;
        var packageProgress = 0;
        if (fileProgress > 0) {
            // package share multiply by file progress
            // sample: package 1 out of 10 pacakges share is 10%, multiply by file progress value (0.0 to 1.0)
            packageProgress = (1 / packagesCount) * 100 * fileProgress;
        }
        overallProgress = progress + packageProgress;
        try {
            if (sender) {
                sender.webContents.send("package:download_progress", overallProgress);
            }
        }
        catch (e) {
            this.log.error("reportDownloadProgress error: " + e);
            //swallow error 
        }
        return completedCount >= packagesCount;
    };
    return ElectronService;
}(base_service_1.BaseService));
exports.ElectronService = ElectronService;
//# sourceMappingURL=electron.service.js.map