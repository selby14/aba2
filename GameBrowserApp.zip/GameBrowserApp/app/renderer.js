const electron = require('electron');
const { ipcRenderer } = electron;
const { remote } = require("electron");

const webview = document.getElementById('mainWindowWebContents');
const $loader = document.querySelector('.loader');
const $error = document.getElementById('errorDiv');
const $errorMsg = document.getElementById('errorP');
const landingPageDiv = document.getElementById('landingPagePromptDiv');
const landingPagePrompt = document.getElementById('landingPageUrlSubmit');
const progressText = document.getElementById('progress')

let isInitialLoad = true;
let domReady = false;
let haveUrl = false;
let isLoaded = false;
let url = "";

webview.addEventListener('did-start-loading', () => {
    if (isInitialLoad && !haveUrl) {
        // call to get url for webView
        console.log("call for url");
        ipcRenderer.send("app:getCurrentUrl");
        isInitialLoad = false;
    } 
});

webview.addEventListener('dom-ready', () => {
    domReady = true;
    if (!isLoaded && url && url.length > 0) {
        loadUrl(url);
    }
});

ipcRenderer.on("app:loadUrl", (event, _url) => {
    url = _url;
    console.log("return call for url: ", url);
    if (domReady && url) {
        haveUrl = true;
        loadUrl(url);
    } 
});


ipcRenderer.on("app:progress", (event, progress) => {
    console.log("progress: ", document.getElementById('progress'));


});

ipcRenderer.on("webview:showSaveDialog", (event) => {
    console.log("showSaveDialog: ");
    //webview.print({ silent: false, printBackground: true, deviceName:'' });
    remote.dialog.showSaveDialog(remote.getCurrentWindow(), { defaultPath: 'certificate.pdf' }, (filename) => {
        if (filename) {
            console.log("filename is: " + filename);
            webview.printToPDF({ landscape: true }, (error, data) => {
                if (error) throw error
                ipcRenderer.send("app:showSaveDialog_response", filename, data);
            });
        } else {
            webview.send('app:pdf_success', false);
        }
        
    });
});

ipcRenderer.on('app:pdf_success', (event, value) => {
    console.log("app:pdf_success");
    webview.send('app:pdf_success', true);
});

function printToPDFCB() {
    console.log("printToPDFCB");
}

function loadUrl(url) {
    console.log("loadUrl: ", url, webview)
    webview.loadURL(url);
    isLoaded = true;
    webview.openDevTools();
}