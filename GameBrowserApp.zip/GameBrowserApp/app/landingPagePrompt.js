const electron = require('electron');
const { ipcRenderer } = electron;
const landingPagePrompt = document.getElementById('landingPageUrlSubmit');

// **** Electron Listeners


function closeModal() {
    ipcRenderer.send('app:closeModal');
}

landingPagePrompt.addEventListener('click', () => {
    let url = document.getElementById('landingPageUrl').value;
    ipcRenderer.send("app:submitLandingPageUrl", url);
  });