const { ipcRenderer: ipc, remote } = require('electron');

init();

function init() {
    attachIPCListeners();

    window.Bridge = {
        loadApp: loadApp,
        getFromLocalStore: getFromLocalStore,
        saveToLocalStore: saveToLocalStore,
        getFromTempStore: getFromTempStore,
        saveToTempStore: saveToTempStore,
        printToPDF: printToPDF,
        logError: logError,
        logWarning: logWarning,
        logInfo: logWarning
    };
}

// messages coming from electron
// functions are defined in electron.services.js locally

function attachIPCListeners() {
    ipc.on('store:get_response', (key, value) => {
        window.Bridge.getFromLocalStore_Response(key, value);
    });

    ipc.on('store:set_response', (key, value) => {
        window.Bridge.saveToLocalStore_Response(key, value);
    });

    ipc.on('cache:get_response', (key, value) => {
        window.Bridge.getFromTempStore_Response(key, value);
    });

    ipc.on('cache:set_response', (key, value) => {
        window.Bridge.saveToTempStore_Response(key, value);
    });

    ipc.on('package:download_progress', (event, progress) => {
        window.Bridge.download_progress(event, progress);
    });

    ipc.on('package:download_complete', (event, value) => {
        window.Bridge.download_complete(event, value);
    });

    ipc.on('game:launch_complete', (event, value) => {
        window.Bridge.launch_complete(event, value);
    });

    ipc.on('game:launch_started', (event, value) => {
        window.Bridge.launch_started(event, value);
    });

    ipc.on('app:pdf_success', (event, value) => {
        window.Bridge.pdf_success(event, value);
    });

}

// messages sent to electron from apps

function loadApp(configUrl, options) {
    ipc.send('app:load', configUrl, options);
}

function getFromLocalStore(key) {
    ipc.send('store:get', key);
}

function saveToLocalStore(key, value) {
    ipc.send('store:set', key, value);
}

function getFromTempStore(key) {
    ipc.send('cache:get', key);
}

function saveToTempStore(key, value) {
    ipc.send('cache:set', key, value);
}

function printToPDF(options) {
    ipc.send('app:printToPDF', options);
}

function logError(msg) {
    ipc.send('log:error', msg);
}

function logWarning(msg) {
    ipc.send('log:warn', msg);
}

function logInfo(msg) {
    ipc.send('log:info', msg);
}
