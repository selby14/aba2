"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var electron_1 = require("electron");
var pathHelper = require("path");
var request = require("request");
var fs = require("fs");
var electronLog = require("electron-log");
var BaseService = (function () {
    function BaseService() {
        this.debugMode = process.env.NODE_ENV !== 'production';
        this.platform = "Win";
        this.isWindow = true;
        if (process.platform === "darwin") {
            this.platform = "Mac";
            this.isWindow = false;
        }
        this.platformLowerCase = this.platform.toLowerCase();
        this.rootDataPath = this.getAppDataFolder();
        var userData = electron_1.app.getPath('userData');
        var logPath = userData + "/logs/logs.txt";
        // make sure logs folder exists
        this.ensureDirectoryExistence(logPath);
        this.log = electronLog;
        this.log.transports.file.level = "silly";
        this.log.transports.file.format = "{y}-{m}-{d} {h}:{i}:{s}:{ms} {text}";
        this.log.transports.file.maxSize = 5 * 1024 * 1024;
        this.log.transports.file.file = logPath;
        this.log.transports.file["stream"] = fs.createWriteStream(logPath, { flags: 'a' });
        this.log.transports.file.appName = "gamebrowser";
    }
    /**
    * returns bolean if app has network connection
    */
    BaseService.prototype.isOnline = function () {
        return navigator.onLine;
    };
    /**
     * Logs to console in debug mode
     * @param info
     */
    BaseService.prototype.consoleLog = function (info) {
        var data = [];
        for (var _i = 1; _i < arguments.length; _i++) {
            data[_i - 1] = arguments[_i];
        }
        if (this.debugMode) {
            if (data && data.length > 0) {
                console.log(info, data);
            }
            else {
                console.log(info);
            }
        }
    };
    /**
     * Creates options for request
     * @param url        The url
     * @param username   The username
     * @param password   The password
     */
    BaseService.prototype.createRequestOptions = function (url, username, password) {
        var options = {
            url: url,
            json: true,
            headers: {
                "u": username,
                "p": password
            }
        };
        return options;
    };
    /**
    * Creates directory recursively
    * @param filePath  The file path
    */
    BaseService.prototype.ensureDirectoryExistence = function (filePath) {
        var dirname = pathHelper.dirname(filePath);
        if (fs.existsSync(dirname)) {
            return;
        }
        this.ensureDirectoryExistence(dirname);
        fs.mkdirSync(dirname);
    };
    /**
    * Gets app data folder
    */
    BaseService.prototype.getAppDataFolder = function () {
        var folder = process.env.LOCALAPPDATA + "\\GameBrowser\\";
        if (!this.isWindow) {
            folder = process.env.HOME + "/Library/Preferences/GameBrowser";
        }
        return folder;
    };
    /**
    * Gets auth token
    */
    BaseService.prototype.getAuthToken = function (url, u, p) {
        var token;
        var options = this.createRequestOptions(url, u, p);
        request.post(options, function (error, response, body) {
            if (error || response.statusCode != 200) {
                console.log("refreshToken: " + (error || body.message));
                token = null;
            }
            else {
                var authResponse = body.data;
                token = authResponse;
            }
            return token;
        });
    };
    return BaseService;
}());
exports.BaseService = BaseService;
//# sourceMappingURL=base.service.js.map