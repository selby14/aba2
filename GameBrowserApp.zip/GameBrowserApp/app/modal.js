const electron = require('electron');
const { ipcRenderer } = electron;
const messageDiv = document.getElementById('msgDiv');

// **** Electron Listeners
ipcRenderer.on("app:message", (event, msg, bgColor) => {
    messageDiv.textContent = msg;
    messageDiv.style.backgroundColor = bgColor;
});

function refresh() {
    ipcRenderer.send('app:refresh');
}