process.env.NODE_ENV = 'test';
let store = require('../app/store.service');
let assert = require('assert');
let chai = require('chai');
let should = chai.should;
let expect = chai.expect;
let storeSvc = new store.StoreService();
const cacheKey = 'cache-key';
const cacheValue = 'cache-value';

//describe('Array', function () {
//    describe('#indexOf()', function () {
//        it('should return -1 when the value is not present', function () {
//            assert.equal(-1, [1, 2, 3].indexOf(4));
//        });
//    });
//});

describe('StoreService', function () {
    describe('#setCache()', function () {
        it('should updates cache value', function () {
            const updatedValue = 'updated-value';
            storeSvc.setCache(cacheKey, updatedValue);
            storeSvc.getCache(cacheKey).then((value) => {
                expect(value).to.equal(updatedValue);
            }).catch((error) => { assert.fail(error); });
        });
    });
});

describe('StoreService', function () {
    describe('#getCache()', function () {
        it('should returns null when key is not present', function () {
            storeSvc.getCache('not-found-key').then((value) => {                
                expect(value).to.equal(null);
            }).catch((error) => { assert.fail(error); });
        });
        it('should returns value from cache', function () {
            storeSvc.setCache(cacheKey, cacheValue);
            storeSvc.getCache(cacheKey).then((value) => {
                expect(value).to.equal(cacheValue);
            }).catch((error) => { assert.fail(error); });
        });
    });
});

describe('StoreService', function () {
    describe('#hasCacheKey()', function () {
        it('should returns true', function () {
            const key = 'test-cache-key';            
            storeSvc.setCache(key, 'test cache value');
            storeSvc.hasCacheKey(key).then((hasKey) => {
                expect(hasKey).to.equal(true);
            }).catch((error) => { assert.fail(error); });
        });
        it('should returns false', function () {
            const key = 'test-cache-key2';
            storeSvc.hasCacheKey(key).then((hasKey) => {
                expect(hasKey).to.equal(false);
            }).catch((error) => { assert.fail(error); });
        });
    });
});

describe('StoreService', function () {
    describe('#removeCache()', function () {
        it('should removes cache item', function () {
            const key = 'test-cache-key'; 
            storeSvc.setCache(key, 'test cache value');
            storeSvc.hasCacheKey(key).then((hasKey) => {
                expect(hasKey).to.equal(true);
                storeSvc.removeCache(key);
                storeSvc.hasCacheKey(key).then((hasKey) => {
                    expect(hasKey).to.equal(false);
                });
            }).catch((error) => { assert.fail(error); });
        });
    });
});

describe('StoreService', function () {
    describe('#setLocalStore()', function () {
        it('should updates local store value', function () {
            const updatedValue = 'updated-value';
            storeSvc.setLocalStore(cacheKey, updatedValue);
            storeSvc.getLocalStore(cacheKey).then((value) => {
                expect(value).to.equal(updatedValue);
            }).catch((error) => { assert.fail(error); });
        });
    });
});

describe('StoreService', function () {
    describe('#getLocalStore()', function () {
        it('should returns null', function () {
            storeSvc.getCache('not-found-store-key').then((value) => {                
                expect(value).to.equal(null);                
            }).catch((error) => { assert.fail(error); });
        });
        it('should returns value', function () {
            storeSvc.setLocalStore(cacheKey, cacheValue);
            storeSvc.getLocalStore(cacheKey).then((value) => {
                expect(value).to.equal(cacheValue);
                storeSvc.removeLocalStore(cacheKey);
            }).catch((error) => { assert.fail(error); });
        });
    });
});

describe('StoreService', function () {
    describe('#hasLocalStore()', function () {
        it('should returns true', function () {
            const key = 'test-store-key';            
            storeSvc.setLocalStore(key, 'test local store value');
            storeSvc.hasLocalStore(key).then((hasKey) => {
                expect(hasKey).to.equal(true);
                storeSvc.removeLocalStore(key);
            }).catch((error) => { assert.fail(error); });
        });
        it('should returns false', function () {
            const key = 'test-store-key2';            
            storeSvc.hasLocalStore(key).then((hasKey) => {                
                expect(hasKey).to.equal(false);
                storeSvc.removeLocalStore(key);
            }).catch((error) => { assert.fail(error); });
        });
    });
});

describe('StoreService', function () {
    describe('#removeLocalStore()', function () {
        it('should removes local store item', function () {
            const key = 'test-store-key';
            storeSvc.setLocalStore(key, 'test local store value');
            storeSvc.hasLocalStore(key).then((hasKey) => {
                expect(hasKey).to.equal(true);
                storeSvc.removeLocalStore(key);
                storeSvc.hasLocalStore(key).then((hasKey) => {
                    expect(hasKey).to.equal(false);
                });
            }).catch((error) => { assert.fail(error); });                       
        });        
    });
});

describe('StoreService', function () {
    describe('#addPackage()', function () {        
        let pckg = {
            packageKey: "testpackagekey",
            version: "1.0.0",
            url: "http://www.creativevet.com",
            onDemand: false
        };
        let pckg2 = {
            packageKey: "testpackagekey2",
            version: "2.0.0",
            url: "http://www.creativevet.com",
            onDemand: false
        };

        it('should adds single package', function () {           
            storeSvc.addPackage(pckg);   
            storeSvc.getPackage(pckg.packageKey, pckg.version).then((p) => {
                expect(p).to.be.an('object');
                expect(p.packageKey).to.be.equal(pckg.packageKey);
                expect(p.version).to.be.equal(pckg.version);
                expect(p.onDemand).to.be.equal(false);
                storeSvc.deletePackage(pckg.packageKey, pckg.version);
            }).catch((error) => { assert.fail(error); });            
        });

        it('should updates single package', function () {                        
            storeSvc.addPackage(pckg2);    
            pckg2.onDemand = true;
            storeSvc.addPackage(pckg2);                  
            storeSvc.getPackage(pckg2.packageKey, pckg2.version).then((p) => {
                expect(p).to.be.an('object');
                expect(p.packageKey).to.be.equal(pckg2.packageKey);
                expect(p.version).to.be.equal(pckg2.version);
                expect(p.onDemand).to.be.equal(true);
                storeSvc.deletePackage(pckg2.packageKey, pckg2.version);
            }).catch((error) => { assert.fail(error); });
        });
    });
});


describe('StoreService', function () {
    describe('#addPackages()', function () {
        let pckg = {
            packageKey: "testpackagekey",
            version: "1.0.0",
            url: "http://www.creativevet.com",
            onDemand: false
        };
        let pckg2 = {
            packageKey: "testpackagekey2",
            version: "2.0.0",
            url: "http://www.creativevet.com",
            onDemand: true
        };
        it('should adds two packages', function () {
            storeSvc.addPackage(pckg);
            storeSvc.addPackage(pckg2);
            storeSvc.getPackages().then((packages) => {
                expect(packages).to.be.an('array');
                expect(packages.length).to.be.equal(2);                
                storeSvc.deletePackage(pckg.packageKey, pckg.version);
                storeSvc.deletePackage(pckg2.packageKey, pckg2.version);
            }).catch((error) => { assert.fail(error); });
        });      
    });
});

describe('StoreService', function () {
    describe('#deletePackage()', function () {
        let pckg1 = {
            packageKey: "testpackagekey",
            version: "1.0.0",
            url: "http://www.creativevet.com",
            onDemand: false
        };
        let pckg2 = {
            packageKey: "testpackagekey2",
            version: "2.0.0",
            url: "http://www.creativevet.com",
            onDemand: true
        };
        it('should deletes package', function () {
            storeSvc.addPackage(pckg1);
            storeSvc.addPackage(pckg2);
            storeSvc.deletePackage(pckg1.packageKey, pckg1.version);
            storeSvc.getPackages().then((packages) => {
                expect(packages).to.be.an('array');
                expect(packages.length).to.be.equal(1);
                storeSvc.deletePackage(pckg1.packageKey, pckg1.version);
                storeSvc.deletePackage(pckg2.packageKey, pckg2.version);
            }).catch((error) => { assert.fail(error); });
        });
    });
});