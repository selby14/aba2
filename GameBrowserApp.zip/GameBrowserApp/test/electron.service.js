process.env.NODE_ENV = 'test';
let ss = require('../app/store.service');
let es = require('../app/electron.service');
let assert = require('assert');
let fs = require("fs");
let chai = require('chai');
let should = chai.should;
let expect = chai.expect;
let storeSvc = new ss.StoreService();
let electronSvc = new es.ElectronService(storeSvc);

describe('ElectronService', function () {
    describe('#unzipFile()', function () {
        it('should unzips file', function () {
            let zipPath = __dirname + "/test.zip";
            electronSvc.unzipFile(zipPath).then((value) => {                   
                expect(value).to.be.a('string');                
            }).catch((error) => { assert.fail(error); });
        });
    });
});


describe('ElectronService', function () {
    describe('#downloadUrl()', function () {
        it('should downloads url contents to a file', function () {
            let destPath = __dirname + "/google.html";
            electronSvc.downloadUrl('http://www.google.com', destPath).then((value) => {
                setTimeout(() => {
                    const exists = fs.existsSync(destPath);
                    assert.equal(exists, true, `${destPath} should be created.`);                    
                }, 3000)
            }).catch((error) => { assert.fail(error); });
        });
    });
});