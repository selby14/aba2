import { app, BrowserWindow, webContents, screen, ipcMain, Menu, MenuItem, remote, session } from 'electron';
import { StoreService } from './store.service';
import { ElectronService } from './electron.service';
import { IPackage, ILaunchPackage, IParam, ILaunch, IGameBrowser, IAppConfig, ILoadAppOptions } from './common';
import { autoUpdater } from "electron-updater";
import * as isOnline from "is-online";
import * as pathHelper from 'path';
import * as fs from 'fs';
import * as Datastore from 'nedb';
import child_process = require('child_process');
import isDev = require('electron-is-dev');
import log = require('electron-log');
import * as _ from "lodash";

/**
    * Set variables needed
*/
let mainWindow, newWindow, modalWindow, windowTracker, storeSvc, electronSvc, errorMsg, errorBg, errorModalUrl, landingPageAppKey;
const args = process.argv.slice(1);
const serve = args.some(val => val === '--serve');
const isMac = process.platform === 'darwin';

let isUpdating = false;
let hasError = false;

/**
    * Set window variables
*/
const size = { height: 720, width: 1280 };
let initialUrl: string = __dirname + "/index.html";
let modalUrl: string = __dirname + "/modal.html";
let loadingModalUrl: string = __dirname + "/loading.html";
let landingPagePromptUrl: string = __dirname + "/landingPagePrompt.html";

if (serve) {
    require('electron-reload')(__dirname, {
    });
}

function init() { 
    storeSvc = new StoreService();    
    electronSvc = new ElectronService(); 
    createMenu();    
    createWindow(); 
}

/**
    * Creates the electron menu

*/
function createMenu() {
    let template: Array<any> = [
        {
            label: 'Game Browser',
            submenu: [
                {
                    label: 'Exit',
                    accelerator: process.platform === 'darwin' ? 'Command+Q' : 'Ctrl+Q',
                    click() {
                        app.quit();
                    }
                }
            ]
        }
    ];

    // add blank menu for mac os
    //if (process.platform === 'darwin') {
    //    template.unshift({});
    //}   

    // add View menu if not production
    if (process.env.NODE_ENV !== 'production') {
        template.push({
            label: 'View',
            submenu: [
                { role: 'reload' },
                {
                    label: 'Toggle Developer Tools',
                    accelerator: process.platform === 'darwin' ? 'Command+Alt+I' : 'Ctrl+Shift+I',
                    click(item, focusedWindow) {
                        focusedWindow.toggleDevTools();
                    }
                }
            ]
        });
    }
    const mainMenu = Menu.buildFromTemplate(template);
    Menu.setApplicationMenu(mainMenu);
}

/**
    * Creates the main browser window.
*/
function createWindow() {
    mainWindow = new BrowserWindow({
        center: true,
        width: size.width,
        height: size.height,
        minHeight: size.height,
        minWidth: size.width,
        show: false,
        title: "Game Browser",
        icon: pathHelper.join(__dirname, 'assets/icons/png/FlashPoint-Icon_64x64.png')
    });

    // load index.html
    // index.html includes a webView tag that brings in external websites.
    // the initially loaded external site is the loading.html in the app folder.
    // also loads the renderer.js script which sets a listener for currentUrl to load.
    // the webview includes the preload.js file, which securely bridges the communication from the external app to electron 
    loadMainWindow(initialUrl);

    // Open the DevTools.
    if (serve) {
        mainWindow.webContents.openDevTools();
    }
    
    // Emitted when the window is closed.
    mainWindow.on('closed', () => { 
        mainWindow = null;
    });

    // In production, the auto-updater will run and when finished call the getLandingPage function
    if (!isDev) {
        autoUpdater.checkForUpdates();
    } else {
        getLandingPage();
    }

}

/**
    * Loads given url into the main window
    * @param url        url to load

*/
function loadMainWindow(url) {
    mainWindow.loadURL(url);
    mainWindow.once('ready-to-show', () => {
        mainWindow.show()
    })
}

/**
    * Get the initial landing page (hubs) configUrl. Checks the local storage first, then the defaultConfig. If none found, calls for landing page prompt
*/
function getLandingPage() {
    // check local store for landingPageConfigUrl
    let configUrl = storeSvc.getLocalStore('landingPageAppUrl').then((url) => {
        if (url) {
            console.log("got config url from store: ", url);
            loadApp(url, {}, mainWindow);
        } else {
            electronSvc.setDefaultAppUrls().then((url) => {
                closeModal();
                configUrl = url;
                electronSvc.log.info("configUrl: " + configUrl);
                loadApp(configUrl, {}, mainWindow);
            })
                .catch((error) => {
                    createErrorModal("", "", landingPagePromptUrl);
                    electronSvc.log.error("getLandingPage: " + error);
                });
        }
    });
}


/**
    * Downloads config json and loads the resulting app
    * @param configUrl       The url to app config file
    * @param sender    The electron window making the original request
*/
function loadApp(configUrl: string, options: ILoadAppOptions = {}, sender: any = mainWindow) {
    let config: IAppConfig;

    // check if connected to network
    isOnline().then(online => {
        if (online) {
            electronSvc.getAppConfig(configUrl).then((result) => {
                config = typeof result === "string" ? JSON.parse(result) : result;
                electronSvc.log.info("loadApp: configUrl" + configUrl);
                if (config) {
                    const appType = config.appType;
                    if (appType === 'LandingPageApp') {
                        landingPageAppKey = config.appKey;
                    }
                    const _packages: Array<IPackage> = config.gameBrowser.packages;
                    const launchConfig = (isMac) ? _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'darwin' }) : _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'win32' });

                    // store in local storage
                    storeSvc.setLocalStore(configUrl, config);

                    // if appType = Remote, load url
                    if (launchConfig.launchType === "Remote") {
                        launchApp(config, options, sender);
                    }

                    // if appType = Package
                    if (launchConfig.launchType === "Package") {
                        console.log("loadApp landingPageAppKey: ", landingPageAppKey);
                        // get package list and download                 
                        electronSvc.downloadPackages(sender, _packages, landingPageAppKey, config.gameBrowser.basePath).then((result) => {
                            electronSvc.log.info("loadApp - download_complete" + result);
                            sender.webContents.send("package:download_complete", true);
                            launchApp(config, options, sender);
                        })
                            .catch((error) => {
                                electronSvc.log.error("loadApp: error: " + error);
                                sender.webContents.send("app:showError", error);
                            });
                    }
                }
                else {
                    //handle no config
                    electronSvc.log.error("loadApp: error: The config file was not found.");
                    //sender.webContents.send("app:showError", "The config file was not found.");
                    createErrorModal("", "", landingPagePromptUrl);
                }
            })
                .catch((error) => {
                    electronSvc.log.error("loadApp: error: " + error);
                    createErrorModal("", "", landingPagePromptUrl);
                });
        }
        else {
            // if not connected
            // is it in local storage
            electronSvc.log.error('loadApp: offline');
            if (storeSvc.hasLocalStore(configUrl)) {
                storeSvc.getLocalStore(configUrl)
                    .then((value) => {
                        config = value;
                        const launchConfig = (isMac) ? _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'darwin' }) : _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'win32' });
                        electronSvc.log.error("loadApp: offline: " + config);
                        // yes, remote
                        if (launchConfig.launchType === "Remote") {
                            networkConnectionPrompt();
                        }
                        // Package, validate that files have been downloaded
                        if (launchConfig.launchType === "Package") {
                            const landingPageAppKey = (config.appType === 'landingPageApp') ? config.appKey : storeSvc.getLocalStore("LandingPageApp")['appKey'];
                            const _packages: Array<IPackage> = config.gameBrowser.packages;
                            electronSvc.validatePackagesAreDownloaded(sender, _packages, landingPageAppKey).then((result) => {
                                if (result) {
                                    launchApp(config, options, sender);
                                } else {
                                    networkConnectionPrompt();
                                }
                            });
                        }
                    })
                    .catch((error) => {
                        electronSvc.log.error("loadApp: offline: " + error);
                        mainWindow.webContents.send('store:get_response', null);
                    });
            }
            else {
                // no, prompt for network connection
                electronSvc.log.error("Calling no network connection prompt.");
                networkConnectionPrompt();
            }
        }
    });
}

/**
    * launching the app
    * @param configUrl       The url to app config file
    * @param sender    The electron window making the original request
*/
function launchApp(config: IAppConfig, options: ILoadAppOptions = {}, sender: any) {
    const launchConfig = (isMac) ? _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'darwin' }) : _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'win32' });
    electronSvc.log.info("launchApp - options: " + options);
    electronSvc.log.info('launchConfig.appParams: ' + launchConfig.appParams);

    let args = {};
    if (launchConfig.appParams) {
        args = _.merge(launchConfig.appParams, options);
    }

    // remote 
    if (launchConfig.launchType === "Remote") {

        let searchParams = getSearchStringFromArgs(args);
        let path = require('url').format({
            search: searchParams,
            pathname: launchConfig.remoteUrl
        });
        electronSvc.log.info('path: ' + path);
        createOrLoadWindow(config, path);
    }

    // package
    if (launchConfig.launchType === "Package") {

        const appKey = (config.appType === 'LandingPageApp') ? config.appKey : storeSvc.getLocalStore("LandingPage")['appKey'];
        let _args = convertDictionaryToArray(args);

        // launch app
        // check if initial file is opening in an electron window or is a process
        let initialFile = pathHelper.join(electronSvc.rootDataPath, landingPageAppKey, "packages", launchConfig.package.packageKey, launchConfig.package.version, launchConfig.package.initialFile);
        electronSvc.log.info("initialFile: " + initialFile);
        const target = launchConfig.launchTarget;

        if (target === "Process") {
            sender.webContents.send("game:launch_started", true);
            child_process.execFile(initialFile, _args, null, (error: Error, stdout: string, stderr: string) => {
                if (error) {
                    electronSvc.log.error("game:launch: " + error);
                    mainWindow.webContents.send("app:showError", error);
                    sender.webContents.send("game:launch_complete", false);
                } else {
                    electronSvc.log.info("game:launch_complete");
                    sender.webContents.send("game:launch_complete", true);
                }
            });

        }
        else {
            // get local path and load
            let searchParams = getSearchStringFromArgs(launchConfig.appParams);
            let localPath = require('url').format({
                protocol: 'file',
                slashes: true,
                search: searchParams,
                pathname: require('path').join(electronSvc.rootDataPath, appKey, "packages", launchConfig.package.packageKey, launchConfig.package.version, initialFile)
            });
            electronSvc.log.info("local path: " + localPath);
            createOrLoadWindow(config, localPath);
        }
    }
}

/**
    * Determines if a new electron window is required and loads the given url
    * @param configUrl       The url to app config file
    * @param url             The url to load into window
*/
function createOrLoadWindow(config: IAppConfig, url: string) {
    let params, wHeight, wWidth;
    const launchConfig = (isMac) ? _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'darwin' }) : _.find(config.gameBrowser.launch.platforms, function (l) { return l.platformKey === 'win32' });
    let newWindow = (launchConfig.launchTarget === "newWindow");
    // if launchTarget is newWindow, check parameters for window parameters
    if (newWindow) {
        // if launchTarget is newWindow, check parameters for window parameters
        params = launchConfig.launchParams;

        for (const param of params) {
            if (param['windowHeight']) {
                wHeight = param['windowHeight'];
            }
            if (param['windowWidth']) {
                wWidth = param['windowWidth'];
            }
        }
        loadNewWindow(url, { height: wHeight, width: wWidth });
    }
    else {
        // set currentPage in temp store to be requested by the renderer to load into webview
        storeSvc.setCache('currentUrl', url);
        electronSvc.log.info('setCache: currentUrl ' + url);
        mainWindow.webContents.send('app:loadUrl', url);
    }
}

/**
    * Creates a "modal" window that is placed directly over the main window
    * @param msg        The message that is placed in the modal div
    * @param bgColor    Sets the background of the modal div. defaults to black
    * @param url        Sets the url to load into the window. defaults to modal.html
*/
function createErrorModal(msg: string = '', bgColor: string = 'black', url: string = modalUrl, flagAsError: boolean = true) {
    hasError = flagAsError;
    errorMsg = msg;
    errorBg = bgColor;
    errorModalUrl = url;
    let mainWindowPosition = mainWindow.getPosition();
    let defaultOptions = {
        parent: mainWindow,
        modal: false,
        show: false,
        transparent: true,
        frame: false,
        backgroundColor: 'red'
    }

    // check if there is an existing window
    if (modalWindow && !modalWindow.isDestroyed()) {
        modalWindow.loadURL(errorModalUrl);
    } else {
        modalWindow = new BrowserWindow(defaultOptions);
        console.log('modal window url: ', errorModalUrl);
        modalWindow.loadURL(errorModalUrl);
    }
 
    modalWindow.once('ready-to-show', () => {
        modalWindow.setContentBounds(mainWindow.getContentBounds());
        sendStatusToWindow(errorMsg, errorBg);
        modalWindow.show();

        // open dev tools
        if (serve) {
           // modalWindow.webContents.openDevTools();
        }

        mainWindow.webContents.send('overlayWindow:opened', null);
    });
    // set a watch for the mainWindow on 'move', so we can keep the child windows in sync (just for Windows)
    if (process.platform === 'win32') {
        trackMainWindow();
    }
}


/**
    * Loads given url into a new window
    * @param url        url to load
    * @param params     dictionary object that can include height and width of new window

*/
function loadNewWindow(url: string, params: any) {
    let defaultOptions = {
        parent: mainWindow,
        modal: false,
        show: false,
        height: (params && params.height) ? params.height : size.height,
        width: (params && params.width) ? params.width : size.width
    }

    // check if there is an existing window
    if (newWindow && !newWindow.isDestroyed()) {
        storeSvc.setCache('currentUrl', url);
        newWindow.webContents.send('app:loadUrl', url);
    } else {
        newWindow = new BrowserWindow(defaultOptions);
    }
    newWindow.loadURL(initialUrl);
    newWindow.show();
    // open dev tools
    if (serve) {
        //  newWindow.webContents.openDevTools();
    }

    storeSvc.setCache('currentUrl', url);

    newWindow.once('ready-to-show', () => {
        newWindow.webContents.send('app:loadUrl', url);
    });

}

/**
    * Closes the modal window
*/
function closeModal() {
    if (modalWindow && !modalWindow.isDestroyed()) {
        console.log("closing modal window");
        modalWindow.close();
    }

    if (windowTracker && !(modalWindow && !modalWindow.isDestroyed())) {
        mainWindow.removeListener('move', handleWindowMove);
    }
}

/**
    * Tracks the main window movement to keep the modal in place
*/
function trackMainWindow() {
    // remove potential listener first
    mainWindow.removeListener('move', handleWindowMove);
    windowTracker = mainWindow.on('move', handleWindowMove);
}

/**
    * Keeps the modal window in place
*/
function handleWindowMove() {
    if (modalWindow && !modalWindow.isDestroyed()) {
        modalWindow.setContentBounds(mainWindow.getContentBounds());
    }
    if (modalWindow && !modalWindow.isDestroyed()) {
        let bounds = mainWindow.getContentBounds();
        let _x = calculateX(bounds.width);
        let _y = calculateY(bounds.height);
    }
}

/**
    * Used by handleWindowMove to calculate the position for the modal.
    * Takes into account the size difference between a window with a frame and the modal that does not have a frame.
*/
function calculateX(width) {
    let mainWindowPosition = mainWindow.getPosition();
    let dif = Math.round((size.width - width) / 2);
    return mainWindowPosition[0] + dif;
}

/**
    * Used by handleWindowMove to calculate the position for the modal.
    * Takes into account the size difference between a window with a frame and the modal that does not have a frame.
*/
function calculateY(height) {
    let mainWindowPosition = mainWindow.getPosition();
    let dif = Math.round((size.height - height) / 2);
    return mainWindowPosition[1] + dif;
}

/**
    * Gets the current url from the cache and emits back to the index page.
    * This function handles the event call from the index page for the currentUrl.
    * This will be called when the index page first loads and if the user forces a refresh of the page.
    * Checks if there is an error first and if so, pushes the saved error data.
*/
function getCurrentUrl() {
    if (!hasError) {
        let url = storeSvc.getCache("currentUrl").then((url) => {
            mainWindow.webContents.send('app:loadUrl', url);
        });
    } else {
        createErrorModal(errorMsg, errorBg, errorModalUrl);
    }
}

/**
    * generic method to send messages to the modal window. Allows for changing the background color of the message div.
    * @param text       text of the message to send to the modal window to display
    * @param bgColor    sets the background color of the message div of the modal window, default is black
*/
function sendStatusToWindow(text: string, bgColor: string = 'black') {
    modalWindow.webContents.send('app:message', text, bgColor);
}

/**
    * Displays an error modal with the message of needing an internet connection to run.
*/
function networkConnectionPrompt() {

    createErrorModal('You need to be connected to the internet.', 'red');
}

/**
    * url encodes dictionary objects
    * @param args             Dictionary object of parameters
*/
function getSearchStringFromArgs(args: any) {
    let params = [];
    let key;
    _.forIn(args, function (value, key) {
        params.push(key + "=" + value);
    });

    return encodeURI("?" + params.join("&"));
}

/**
    * converts dictionary objects to a stringified array
    * @param obj             Dictionary object of parameters
*/
function convertDictionaryToArray(obj): Array<string> {
    var output = Object.keys(obj).map(function (key) {
        return JSON.stringify({ 'key': key, 'value': (typeof obj[key] === 'string') ? obj[key] : JSON.stringify(obj[key]) });
    });
    return output;
}

function formatStoreDataForIPC(key: string, value: any) {
    return { key: key, value: value };
}

try {

    // This method will be called when Electron has finished
    // initialization and is ready to create browser windows.
    // Some APIs can only be used after this event occurs.
    app.on('ready', () => {
        init(); 
    });
 
    // Quit when all windows are closed.
    app.on('window-all-closed', () => {
        // On OS X it is common for applications and their menu bar
        // to stay active until the user quits explicitly with Cmd + Q
        if (process.platform !== 'darwin') {
            app.quit();
        }
    });

    app.on('activate', () => {
        // On OS X it's common to re-create a window in the app when the
        // dock icon is clicked and there are no other windows open.
        if (mainWindow === null) {
            init();
        }
    });

     /// AUTO UPDATER EVENTS

    autoUpdater.on('checking-for-update', () => {
        isUpdating = true;
        createErrorModal('Checking for update...', '', modalUrl, false);
        electronSvc.log.warn("Checking for update...");
    });

    autoUpdater.on('update-available', (info) => {
        sendStatusToWindow('Update available.');
        electronSvc.log.warn("Update Available");
    });

    autoUpdater.on('update-not-available', (info) => {
        isUpdating = false;
        electronSvc.log.warn("update-not-available");
        closeModal();
        getLandingPage();
    });

    autoUpdater.on('error', (err) => {
        isUpdating = false;
        electronSvc.log.error("auto-updater: " + err); 
        sendStatusToWindow('There was an error checking for updates. ', 'red');
        getLandingPage();
    });

    autoUpdater.on('download-progress', (progressObj) => {
      let log_message = 'Downloading files: ' + Math.round(progressObj.percent) + '%';   
      sendStatusToWindow(log_message);
    });

    autoUpdater.on('update-downloaded', (info) => {
        electronSvc.log.info("autoUpdater: update - downloaded");
        sendStatusToWindow('Update downloaded; will install in 5 seconds');
        setTimeout(function () {
            autoUpdater.quitAndInstall();
        }, 5000);
    });

    ///END AUTO UPDATER EVENTS

    /// STORE EVENTS
    /// Event: cache:set
    ipcMain.on('cache:set', (event, key, value) => {
        console.log("Saving to cache: key ", key);
        storeSvc.setCache(key, value);
    });
    /// Event: cache:get
    ipcMain.on('cache:get', (event, key) => {                
        storeSvc.getCache(key)
            .then((value) => {
                console.log("cache:get", key, value);        
                event.sender.webContents.send('cache:get_response', formatStoreDataForIPC(key, value));                      
            })
            .catch((error) => {                
                electronSvc.log.error("cache:get: error: " + error);     
                event.sender.webContents.send('cache:get_response', null);        
            });
    });
    /// Event: cache:remove
    ipcMain.on('cache:remove', (event, key) => {
        storeSvc.removeCache(key);
    });
    /// Event: store:set
    ipcMain.on('store:set', (event, key, value) => {
        storeSvc.setLocalStore(key, value);
        event.sender.webContents.send('store:set_response', formatStoreDataForIPC(key, value));
    });
    /// Event: store:get
    ipcMain.on('store:get', (event, key) => {        
        storeSvc.getLocalStore(key)
            .then((value) => {
                console.log("store:get", key, value);
                event.sender.webContents.send('store:get_response', formatStoreDataForIPC(key, value));
            })
            .catch((error) => {
                electronSvc.log.error("store:get: error: " + error);
                event.sender.webContents.send('store:get_response', null);
            });
    });
    /// Event: store:remove
    ipcMain.on('store:remove', (event, key) => {
        storeSvc.removeLocalStore(key);
    });
    ///END STORE EVENTS

    /// LOG EVENTS
    /// Event: log:error
    ipcMain.on("log:error", (event, error: any) => {
        electronSvc.log.error(error);
    });
    /// Event: log:info
    ipcMain.on("log:info", (event, info: any) => {
        electronSvc.log.info(info);
    });
    /// Event: log:warn
    ipcMain.on("log:warn", (event, warning: any) => {
        electronSvc.log.warn(warning);
    });
    /// END LOG EVENTS

    /// APP EVENTS
    /// Event: app:load
    ipcMain.on("app:load", (event: any, configUrl: string, options: ILoadAppOptions = {}) => {
        electronSvc.log.info("app:load: " + configUrl);
        loadApp(configUrl, options, event.sender);
    });

    ipcMain.on("app:getCurrentUrl", (event) => { 
        getCurrentUrl(); 
    });

    ipcMain.on('app:closeModal', (event) => {
        closeModal();
    });

    ipcMain.on('app:refresh', (event) => {
        closeModal();
        getLandingPage();
    });

    ipcMain.on('webView:dom-ready', (event) => {
        // check to see if updating app, if not, close the modal window
        if (!isUpdating && !hasError) {
            closeModal();
        }
    });
    
    ipcMain.on("app:submitLandingPageUrl", (event, url: string) => {   
        storeSvc.setLocalStore("landingPageAppUrl", url);
        hasError = false;
        loadApp(url, {}, mainWindow);  
        closeModal();
    });

    /// Event: app:isInstalled
    ipcMain.on("app:isInstalled", (event, appKey: string, version: string = "", hub: string = "") => {

    });

    /// Event: app:isPackageInstalled
    ipcMain.on("app:isPackageInstalled", (event, packageKey: string, version: string = "", hub: string = "") => {

    });

    /// Event: app:getLatestPackageVersion
    ipcMain.on("app:getLatestPackageVersion", (event, packageKey: string, hub: string = "") => {

    });

    /// Event: app:getLatestAppVersion
    ipcMain.on("app:getLatestAppVersion", (event, appKey: string, hub: string = "") => {

    });

    /// Event: app:downLoadPackage
    ipcMain.on("app:downLoadPackage", (event, appKey: string, version: string, url: string, hub: string = "") => {

    });

    /// Event: app:getHubPath
    ipcMain.on("app:getHubPath", (event, hub: string = "") => {

    });

    /// Event: app:getPackagePaths
    ipcMain.on("app:getPackagePath", (event, packageKey: string, version: string = "", hub: string = "") => {

    });

    ipcMain.on("app:printToPDF", (event) => {
        event.sender.webContents.send('webview:showSaveDialog');
        mainWindow.webContents.send('webview:showSaveDialog');
    });

    ipcMain.on("app:showSaveDialog_response", (event, filename: string, data: any) => {
        electronSvc.log.info("app:showSaveDialog_response: " + filename);
        fs.writeFile(filename, data, (error) => {
            if (error) throw error
            mainWindow.send('app:pdf_success', true);
        })
        mainWindow.send('app:pdf_success', true);
    });

    /// END APP EVENTS


} catch (e) {    
    electronSvc.log.error("main try/catch error: " + e);
}