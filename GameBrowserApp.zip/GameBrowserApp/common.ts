export interface IAuthResponse {
    userId: string;
    displayName: string;
    accessToken: string;
    renewalToken: string;
}

export interface IApiReponse {
    success: boolean;
    error?: string;
    data?: any;
}

export interface ICreateSessionData {
    worldKey: string,
    sessionType: string,
    scenarioKey?: string,
    sessionSemVer: string,
    maxUsers: number,
    startTime?: string,
    endTime?: string,
    relatedSessionId?: number
}

export interface IShareSessionData {
    sessionId: number,
    shareType: string,
    requirePassword?: boolean,
    password?: string,
    shareCode?: string,
    maxUsers?: number,
    users?: any       //dictionary of user id and role
}

export interface IEmailData {
    emailTo: string,
    subject: string,
    message: string,
    isMessageHtml: boolean,
    sessionId?: number,
    worldKey?: string,
    scenarioKey?: string
}

export interface IPackage {
    packageKey: string,
    version: string,
    url: string,
    onDemand: boolean
}

export interface ILaunchPackage {
    packageKey: string,
    version: string,
    initialFile: string
}

export interface IParam {
    name: string,
    value: any
}

export interface ILaunch {
    platforms: Array<IPlatforms>
}

export interface IPlatforms {
    platformKey: string,
    launchType: string,
    launchTarget?: string,
    package: ILaunchPackage,
    remoteUrl?: string,
    launchParams: any,
    appParams: any
}

export interface IGameBrowser {
    basePath: string,
    packages?: Array<IPackage>,
    launch: ILaunch
}

export interface IAppConfig {
    schemaVersion: string,
    appType: string,
    appKey: string,
    appVersion: boolean,
    title?: string,
    description?: string,
    gameBrowser: IGameBrowser,
    app?: any
}

export interface ILoadAppOptions {
    needsToken?: boolean,
    token?: string,
    sessionId?: string
}