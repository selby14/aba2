import { AbaV2Page } from './app.po';

describe('aba-v2 App', () => {
  let page: AbaV2Page;

  beforeEach(() => {
    page = new AbaV2Page();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});
