﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace ABA_API.Models
{
  public class APIResponse
  {
    [Required]
    public bool Success { get; set; } = true;
    public string Error { get; set; } = string.Empty;
    public object Data { get; set; } = string.Empty;
  }


  public class APIResponse<T> : APIResponse
  {
    public new T Data { get; set; }
  }
}
