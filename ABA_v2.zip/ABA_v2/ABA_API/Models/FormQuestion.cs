﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ABA_API.Models
{
    public class FormQuestion
  {
        public int Id { get; set; }
        public int FormId { get; set; }
        public int SectionId { get; set; }
        public string Title { get; set; }
        public string HelpText { get; set; }
        public string inputData { get; set; }
        public string LayoutData { get; set; }
        public int OrderBy { get; set; }
        public bool IsRequired { get; set; }
        public bool IsActive { get; set; }
  }
}
