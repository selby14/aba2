﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ABA_API.Models
{
    public class FormData
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string LayoutData { get; set; }

        // reference items
        public List<FormSection> FormSections { get; set; }
        public List<FormQuestion> FormQuestions { get; set; }
  }
}
