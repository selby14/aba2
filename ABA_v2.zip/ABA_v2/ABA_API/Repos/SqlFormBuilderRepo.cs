﻿using ABA_API.Models;
using ABA_API.Services;
using BigfootSQL;

using System;
using System.Collections.Generic;

namespace ABA_API.Repos
{
    public class SqlFormBuilderRepo : IFormBuilderRepo
    {
        private IConfigService _webConfigSvc;        
        private string ConnectionString { get { return _webConfigSvc.DBConnectionString; } }        
        private SqlHelper DB { get { return new SqlHelper(ConnectionString); } }


        #region " Constructors "

        public SqlFormBuilderRepo()
        {
            _webConfigSvc = WebConfigService.Instance;            
        }

        // Testable constructor
        public SqlFormBuilderRepo(IConfigService configSvc)
        {
            _webConfigSvc = configSvc;            
        }

        #endregion
        
        public List<FormData> GetForms()
        {
            var db = DB.SELECT_ALL_FROM("FormData");

            return db.ExecuteCollection<FormData>();
        }


        #region " Interface Implementation "
        
        public FormData GetFormData(int id)
        {
            var db = DB.SELECT_ALL_FROM("FormData")
                        .WHERE("[Id]", id);                       

            return db.ExecuteObject<FormData>();
        }

        public int Add(FormData formData)
        {
            return DB.INSERTINTO("FormData", "[Title], [Description], [LayoutData]")
                     .VALUES(formData.Title, formData.Description, formData.LayoutData)
                     .ExecuteScalarIdentity();
        }

        public void Update(FormData formData)
        {
            DB.UPDATE("FormData")
                .SET("Title", formData.Title)
                .SET("Description", formData.Description)
                .SET("LayoutData", formData.LayoutData)
                .WHERE("Id", formData.Id)
                .ExecuteNonquery();
        }

        public void Delete(int id)
        {
            DB.DELETEFROM("FormData")
              .WHERE("Id", id).ExecuteNonquery();
        }


        #endregion

        protected override Func<IFormBuilderRepo> GetFactory() => () => new SqlFormBuilderRepo();

    }
}
