﻿using System.Collections.Generic;

using ABA_API.Models;

namespace ABA_API.Repos
{
    public interface IFormBuilderRepo
    {
        int Add(FormData data);
        void Update(FormData data);
        void Delete(int id);
        FormData GetFormData(int id);
        List<FormData> GetForms();       
    }
}
