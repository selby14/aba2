﻿
using System;
using System.Configuration;

namespace ABA_API.Services
{
    public class WebConfigService : IConfigService
    {
        private string _connectionStringName = "SiteSqlServer";

        #region " Constructors "

        public WebConfigService() { }

        public WebConfigService(string connectionStringName)
        {
            _connectionStringName = connectionStringName;
        }

        public string GetAppSetting(string key)
        {
            return ConfigurationManager.AppSettings.Get(key);
        }

        #endregion

        public bool GetAppSettingAsBool(string key)
        {
            try
            {
                var valStr = ConfigurationManager.AppSettings.Get(key);
                bool val;
                bool.TryParse(valStr, out val);
                return val;
            }
            catch { return false; }
        }

        public int GetAppSettingAsInt(string key)
        {
            try
            {
                var valStr = ConfigurationManager.AppSettings.Get(key);
                int val;
                int.TryParse(valStr, out val);
                return val;
            }
            catch { return 0; }
        }

        public string DBConnectionString { get { return ConfigurationManager.ConnectionStrings[_connectionStringName].ConnectionString; } }

        protected override Func<IConfigService> GetFactory() => () => new WebConfigService();

        public string GetForm()
        {
            throw new NotImplementedException();
        }
    }
}
