﻿using System;
using System.Linq;
using System.Collections.Generic;
using ABA_API.Repos;
using ABA_API.Models;

namespace ABA_API.Services
{
    public class FormBuilderService : IFormBuilderService
    {
        private IFormBuilderRepo _repo;
        
        #region " Constructors "

        public FormBuilderService()
        {
            _repo = SqlFormBuilderRepo.Instance;
        }

        // Testable constructor
        public FormBuilderService(IFormBuilderRepo repo)
        {
            _repo = repo;
        }

        #endregion

        private List<FormData> GetForms()
        {

            // Get from repo
            var forms = _repo.GetForms();
           
            return forms;            
        }

        public int Add(FormData formData)
        {

            var id = _repo.Add(formData);
            return id;
        }

        public void Update(FormData formData)
        {

            if (formData.Id == 0)
                _repo.Add(formData);
            else
                _repo.Update(formData);       
        }

        public void Delete(int id)
        {
           _repo.Delete(id);                        
        }

        public FormData GetForm(int id)
        {
            var formData = GetForm(id);
            return formData;
        }
        
        protected override Func<IFormBuilderService> GetFactory() => () => new FormBuilderService();

        List<FormData> IFormBuilderService.GetForms()
        {
            throw new NotImplementedException();
        }
    }
}
