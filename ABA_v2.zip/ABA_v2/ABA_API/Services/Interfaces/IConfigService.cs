﻿namespace ABA_API.Services
{
    public interface IConfigService
    {
        string GetForm();
        string DBConnectionString { get; }
    }
}
