﻿using ABA_API.Models;
using System;
using System.Collections.Generic;


namespace ABA_API.Services
{
    public interface IFormBuilderService
    {
        int Add(FormData data);
        void Update(FormData data);
        void Delete(int id);
        FormData GetForm(int id); 
        List<FormData> GetForms();        
    }
}
