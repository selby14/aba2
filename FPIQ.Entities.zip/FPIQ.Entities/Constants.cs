﻿namespace FPIQ.Entities
{
    public static class Constants
    {  
        public static class ContentTypes
        {
            public const string App = "App";            
        }

        public static class ContentSubTypes
        {
            public const string LandingApp = "LandingApp";
            public const string HubApp = "HubApp";
            public const string GameApp = "GameApp";
            public const string MenuApp = "MenuApp";
            public const string CurriculumApp = "CurriculumApp";
        }

        public static class ActiveStatus
        {
            public const string Active = "Active";
            public const string Inactive = "Inactive";
        }

        public static class AppTypes
        {
            public const string LandingPage = "LandingPage";
            public const string HomeScreen = "HomeScreen";
            public const string Game = "Game";
            public const string GameMenu = "GameMenu";
            public const string CurriculumApp = "CurriculumApp";
            public const string Other = "Other";
        }

        public static class Events
        {            
            public const string SessionStart = "SessionStart";
            public const string SessionEnd = "SessionEnd";
            public const string SessionRejoin = "SessionRejoin";
            public const string SessionLeft = "SessionLeft";
            public const string ObjectiveMet = "ObjectiveMet";
            public const string Error = "Error";
            public const string Log = "Log";
        }

        public static class SettingTypes
        {
            public const string System = "System";
            public const string HubClient = "HubClient";
            public const string HubServer = "HubServer";
        }
        
        public static class UploadFileActions
        {
            public const string Add = "Add";
            public const string Replace = "Replace";
            public const string FailIfDuplicate = "FailIfDuplicate";
        }

        public static class LaunchTypes
        {
            public const string Remote = "Remote";
            public const string Package = "Package";            
        }
        
        public static class LaunchTargets
        {
            public const string Process = "Process";
            public const string WiNewWindown = "NewWindow";
            public const string MainWindow = "MainWindow";
        }

        public static class PlatformKeys
        {
            public const string Any = "Any";
            public const string Win = "Win";
            public const string Mac = "Mac";
        }                
       
        public static class SessionStatus
        {
            public const string Created = "Created";
            public const string InProgress = "InProgress";
            public const string Completed = "Completed";
            public const string Abandoned = "Abandoned";
            public const string Corrupted = "Corrupted";
        }

        public static class SessionTypes
        {
            public const string SP = "SP";
            public const string MP = "MP";            
        }

        public static class SessionUserStatus
        {
            public const string Connected = "Connected";
            public const string Disconnected = "Disconnected";
            public const string Invited = "Invited";
            public const string Completed = "Completed";
            public const string Banned = "Banned";
        }

        public static class SessionTimeStatus
        {
            public const string NotScheduled = "NotScheduled";
            public const string Past = "Past";
            public const string Present = "Present";
            public const string Future = "Future";
            public const string Today = "Today";
            public const string Tomorrow = "Tomorrow";
            public const string Next7Days = "Next7Days";
            public const string Next30Days = "Next30Days";
            public const string Next60Days = "Next60Days";
            public const string Next90Days = "Next90Days";
            public const string Next180Days = "Next180Days";
        }
        
        public static class TimeEntryTypes
        {
            public const string World = "World";
            public const string Scenario = "Scenario";
            public const string LO = "LO";
            public const string LOEvent = "LOEvent";
            public const string Other = "Other";
        }

        public static class SessionShareTypes
        {
            public const string AllUsers = "AllUsers";
            public const string Restricted = "Restricted";
        }

        public static class SessionDataTypes
        {
            public const string Objective = "Objective";            
        }

        public static class SessionLogEvents
        {
            public const string Joined = "Joined";
            public const string ReJoined = "ReJoined";
            public const string Left = "Left";
            public const string Completed = "Completed";
        }     

        public static class EventScopes
        {
            public const string Private = "Private";
            public const string Shared = "Shared";
        }

        public static class ObjectiveStatus
        {
            public const string Met = "Met";
            public const string NotMet = "NotMet";
        }

        public static class ObjectiveScopes
        {
            public const string Private = "Private";
            public const string Shared = "Shared";
        }

        public static class ObjectiveTypes
        {
            public const string Auto = "Auto";
            public const string Manual = "Manual";
        }       

        public static class DocTypes
        {
            public const string Word = "Word";
            public const string Excel = "Excel";
            public const string PowerPoint = "PowerPoint";
            public const string PDF = "PDF";
            public const string Image = "Image";
            public const string Other = "Other";
        }

        public static class TrackerContexts
        {
            public const string Content = "Content";
            public const string Location = "Location";
            public const string World = "World";
            public const string Scenario = "Scenario";
            public const string NPC = "NPC";
            public const string Player = "Player";            
        }
        
        public static class TrackerEvents
        {
            public const string Enter = "Enter";
            public const string Exit = "Exit";
            public const string Downloaded = "Downloaded";
            public const string View = "View";
            public const string Interact = "Interact";
            public const string Login = "Login";
            public const string Logout = "Logout";
            public const string Other = "Other";
        }

        public static class EditorTypes
        {
            public const string Raw = "Raw";
            public const string Html = "Html";
            public const string Url = "Url";
            public const string File = "File";
            public const string Boolean  = "Boolean";            
        }

        public static class LicenseGrantTypes
        {
            public const string Access = "Access";
            public const string Usage = "Usage";
        }

        public static class RoleRights
        {
            public const string Facilitator = "Facilitator";
            public const string Observer = "Observer";
        }

        public static class ROITypes
        {
            public const string PerObjective = "PerObjective";
            public const string PerApp = "PerApp";
        }

        public static class CreditStatus
        {
            public const string NotStarted = "NotStarted";
            public const string InProgress = "InProgress";
            public const string Success = "Success";
            public const string Failed = "Failed";
        }

        public static class EvalSentiments
        {
            public const string Positive = "Positive";
            public const string Negative = "Negative";
            public const string Unknown = "Unknown";            
        }

        public static class TestResults
        {
            public const string Passed = "Passed";
            public const string Failed = "Failed";
            public const string Completed = "Completed";
        }

        public static class QuestionTypes
        {
            public const string Textbox = "Textbox";
            public const string Textarea = "Textarea";
            public const string CheckboxList = "CheckboxList";
            public const string RadioList = "RadioList";
            public const string DropdownList = "DropdownList";            
        }

        public static class CertificationStatus
        {
            public const string NA = "NA";
            public const string PreReqsRequired = "PreReqsRequired";
            public const string PreReqsCompleted = "PreReqsCompleted";
            public const string PostReqsRequired = "PostReqsRequired";
            public const string PostReqsCompleted = "PostReqsCompleted";            
        }

        public static class ModuleNames
        {
            public const string AppDetails = "AppDetails";
        }
    }
}
