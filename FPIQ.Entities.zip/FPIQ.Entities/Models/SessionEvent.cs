﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class SessionEvent
    {
        [Key]
        [JsonIgnore]
        public int Id { get; set; }
        [Required]
        public Guid SessionId { get; set; }
        [Required]
        public string EventKey { get; set; }
        [Required]
        public string EventScope { get; set; }
        [Required]
        public DateTime EventDate { get; set; }
        public string EventType { get; set; }
        public string EventGroup { get; set; }        
        public string Title { get; set; }
        public string Description { get; set; }
        public string Loc { get; set; }
        public string Data { get; set; }
        public string Username { get; set; }
        public bool Published { get; set; }
        public string PublishedTo { get; set; }
        public string Ref1 { get; set; }
        public string Ref2 { get; set; }
    }
}
