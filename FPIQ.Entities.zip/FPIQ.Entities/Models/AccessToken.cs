﻿using System;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    [Serializable]
    public class AccessToken
    {
        public string Token { get; set; }
        public string RenewalToken { get; set; }
        public DateTime Expires { get; set; }
        public bool IsExpired { get { return Expires <= DateTime.UtcNow; } }

        #region " Constructors "

        public AccessToken() { }

        public AccessToken(string rawAccessToken)
        {
            try
            {
                if (!string.IsNullOrEmpty(rawAccessToken))
                {
                    var atoken = JsonConvert.DeserializeObject<AccessToken>(rawAccessToken);
                    if (atoken != null)
                    {
                        Token = atoken.Token;
                        RenewalToken = atoken.RenewalToken;
                        Expires = atoken.Expires;
                    }
                }
            }
            catch
            {
                //swallow exception
            }
        }
        #endregion
    }
}
