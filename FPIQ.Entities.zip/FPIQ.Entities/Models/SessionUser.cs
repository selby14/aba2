﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    public class SessionUser : BaseModel
    {
        [Key]
        [JsonIgnore]
        public long Id { get; set; }
        public Guid SessionId { get; set; }        
        public string Username { get; set; }
        [Required]
        public string Status { get; set; }        
        public string PerformanceLevel { get; set; }
        public string RoleKey { get; set; }        
        public DateTime DateCompleted { get; set; }
    }
}
