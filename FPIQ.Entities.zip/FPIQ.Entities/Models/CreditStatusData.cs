﻿namespace FPIQ.Entities.Models
{
    public class CreditStatusData
    {                
        public string CertificationStatus { get; set; }        
        public string LaunchUrl { get; set; }              
    }
}
