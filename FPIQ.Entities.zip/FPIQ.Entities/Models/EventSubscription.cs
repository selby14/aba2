﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class EventSubscription
    {
        [Key]        
        public int Id { get; set; }
        [Required]
        public string EventName { get; set; }
        [Required]
        public string Endpoint { get; set; }
        public string AppKey{ get; set; }
        public string HubKey { get; set; }
        [JsonIgnore]
        public string DataJson { get; set; }
        public Dictionary<string, string> Data { get; set; }

        #region " Constructors "
        public EventSubscription() { }

        public EventSubscription(EventSubscription eventSubscription)
        {
            foreach (var prop in eventSubscription.GetType().GetProperties())
            {
                var property = GetType().GetProperty(prop.Name);
                if (property != null && property.GetGetMethod() != null && property.GetSetMethod() != null)
                {
                    property.SetValue(this, prop.GetValue(eventSubscription, null), null);
                }
            }
        }

        #endregion
    }
}
