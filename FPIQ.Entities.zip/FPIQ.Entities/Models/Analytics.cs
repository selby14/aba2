﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace FPIQ.Entities.Models
{

    public class AnalyticsData
    {
        public LearningSummaryData LearningSummary { get; set; }
        public UserStatsData UserStats { get; set; }
        public SessionStatsData SessionStats { get; set; }
        public CreditStatsData CreditStats{ get; set; }
        public List<GameData> GameList { get; set; }
    }

    public class LearningSummaryData
    {
        public int TotalObjectivesMet { get; set; }
        public double SuccessRate { get; set; }
        public double AveNoOfObjectivesPerSession { get; set; }
        public int PartialSessions_TotalObjectivesMet { get; set; }
        public double PartialSessions_SuccessRate { get; set; }
        public double PartialSessions_AveCompletionBySession { get; set; }
        public int CompletedSessions_TotalObjectivesMet { get; set; }
        public double CompletedSessions_SuccessRate { get; set; }        
        public List<ObjectiveStat> ObjectiveList{ get; set; }
    }

    public class ObjectiveStat
    {
        public string Title { get; set; }
        public int TotalAttempts{ get; set; }
        public int Success { get; set; }
        public int Failure { get; set; }
        public double SuccessRate { get; set; }
    }

    public class UserStatsData
    {
        public int TotalUsers { get; set; }
        public int TotalActiveUsers { get; set; }
        public int TotalInactiveUsers { get; set; }
        public int UsersWithin24Hours { get; set; }
        public int UsersWithinWeek { get; set; }
        public int UsersWithinMonth { get; set; }
        public int UsersWithin3Months { get; set; }
    }

    public class SessionStatsData
    {
        public int TotalSessions { get; set; }
        public int TotalSPSessions { get; set; }
        public int TotalMPSessions { get; set; }
        public int TotalSessionsWithinWeek { get; set; }
        public int TotalSessionsWithinMonth { get; set; }
        public int TotalSessionsWithin3Months { get; set; }
        public int TotalSessionsCompleted { get; set; }
        public int TotalSessionsInProgress { get; set; }
        /// <summary>
        /// Hub level only
        /// </summary>
        public List<GameStat> TopFiveGames { get; set; }
    }

    public class GameStat
    {
        public string GameTitle { get; set; }
        public int TotalSessions { get; set; }
    }

    public class CreditStatsData
    {
        public decimal TotalCreditsEarned { get; set; }        
        public decimal TotalCreditsWithinWeek { get; set; }
        public decimal TotalCreditsWithinMonth { get; set; }
        public decimal TotalCreditsWithin3Months { get; set; }
        public decimal TotalCreditsInProgress { get; set; }
        public decimal TotalCreditsNotStarted { get; set; }        
        public decimal TotalCreditsSuccess { get; set; }
        public decimal TotalCreditsFailed { get; set; }

        public int TotalEvals { get; set; }
        public int TotalEvalsPositive { get; set; }
        public int TotalEvalsNegative { get; set; }
        public int TotalEvalsUnknown { get; set; }
        public int TotalEvalsWithinWeek { get; set; }
        public int TotalEvalsWithinMonth { get; set; }
        public int TotalEvalsWithin3Months { get; set; }

        public decimal AvePreTestScore { get; set; }
        public decimal AvePostTestScore { get; set; }
        public decimal PreTestPassPercentage { get; set; }
        public decimal PostTestPassPercentage { get; set; }

        public int TotalProcessPreReqsAcknowledgement{ get; set; }
        public int TotalProcessPreTest{ get; set; }
        public int TotalProcessPostTest { get; set; }
        public int TotalProcessEval { get; set; }
        public int TotalProcessPostReqsAcknowledgement { get; set; }

        public decimal AccreditationTotalValue { get; set; }
        public decimal AccreditationValueWithinWeek { get; set; }
        public decimal AccreditationValueWithinMonth { get; set; }
        public decimal AccreditationValueWithin3Months { get; set; }

        public List<AccreditationBodyStat> TotalByAccreditation { get; set; }
    }

    public class AccreditationBodyStat
    {
        [JsonIgnore]
        public int CreditConfigId { get; set; }
        [JsonIgnore]
        public string CAKey { get; set; }
        public string Title { get; set; }
        public decimal TotalCredits { get; set; }

    }

    public class GameData
    {
        public string Icon { get; set; }
        public string Title { get; set; }
        public string ShortDescription { get; set; }
        public int TotalSessions { get; set; }        
    }

}
