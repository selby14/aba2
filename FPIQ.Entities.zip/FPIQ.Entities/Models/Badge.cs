﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    public class BadgeEntry
    {
        [Key]
        [Required]        
        public int Id { get; set; }
        [Required]
        public string HubKey { get; set; }
        [Required]
        public string AppKey { get; set; }        
        [Required]
        public string BadgeKey { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public string Title { get; set; }        
        public string Description { get; set; }
        [Required]
        public string IconUrl { get; set; }
        [Required]
        public string Level { get; set; }        
        public string Data { get; set; }        
        public Guid SessionId{ get; set; }
        [Required]
        public DateTime DateAdded { get; set; } = DateTime.UtcNow;
        [Required]
        public DateTime LastModified { get; set; } = DateTime.UtcNow;
    }
}
