﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    public class AppManifest
    {
        [Required]
        public string AppKey { get; set; }
        [Required]
        public string AppType { get; set; }
        [Required]
        public string AppVersion { get; set; }
        [Required]
        public string SchemaVersion { get; set; }
        [Required]
        public string Title { get; set; }
        public string Description { get; set; }        
        public string IconUrl { get; set; }
        public GameBrowserManifest GameBrowser { get; set; }
        public GamificationManifest Gamification { get; set; }
        public App App{ get; set; }
        
        public static AppManifest CreateSample()
        {
            var manifest = new AppManifest
            {
                GameBrowser = new GameBrowserManifest {
                    Packages = new List<PackageInfo> { new PackageInfo {
                            Platforms = new List<PlatformInfo> {
                                new PlatformInfo()
                            }
                        }
                    },
                    Launch = new LaunchManifest {
                        Platforms = new List<LaunchPlatform> {
                            new LaunchPlatform{
                                Package = new LaunchPackageInfo (),
                                AppParams = new Dictionary<string, string>(),
                                LaunchParams = new Dictionary<string, string>()                                
                            }
                        }
                    }
                },
                App = new App {
                    ROI = new ROIInfo {
                        Objectives = new List<ROIObjective> {
                            new ROIObjective()
                        }
                    },
                    Objectives = new List<Objective> { new Objective {
                            MetaData = new Dictionary<string, string>()
                        }
                    },
                    Roles = new List<Role> { new Role {
                            MetaData = new Dictionary<string, string>()
                        }
                    },
                    Settings = new List<AppSetting> { new AppSetting() }
                },
                Gamification = new GamificationManifest {
                    Badges = new List<BadgeInfo> { new BadgeInfo() },
                    Leaderboards = new List<Leaderboard> { new Leaderboard() }
                }
            };
            manifest.GameBrowser.Launch.Platforms[0].LaunchParams.Add("param1", "data 1");
            manifest.GameBrowser.Launch.Platforms[0].AppParams.Add("param1", "data 1");
            manifest.App.Roles[0].MetaData.Add("key1", "value 1");
            manifest.App.Objectives[0].MetaData.Add("key1", "value 1");

            return manifest;
        }
    }

    public class GameBrowserManifest
    {
        public string BasePath { get; set; }
        public List<PackageInfo> Packages { get; set; }
        public LaunchManifest Launch { get; set; }
    }

    public class LaunchManifest
    {
        public List<LaunchPlatform> Platforms { get; set; }
    }

    public class LaunchPlatform
    {
        public string PlatformKey { get; set; }
        public string LaunchType { get; set; }
        public string LaunchTarget { get; set; }
        public LaunchPackageInfo Package { get; set; }
        public string RemoteUrl { get; set; }
        public Dictionary<string, string> LaunchParams { get; set; }
        public Dictionary<string, string> AppParams { get; set; }
    }

    public class LaunchPackageInfo
    {
        public string PackageKey { get; set; }
        public string Version { get; set; }
        public string InitialFile { get; set; }
    }

    public class PackageInfo
    {
        public string PackageKey { get; set; }
        public bool OnDemand { get; set; }
        public List<PlatformInfo> Platforms { get; set; }
    }

    public class PlatformInfo
    {
        public string PlatformKey { get; set; }
        public string Version { get; set; }
        public string Url { get; set; }
    }

    public class GamificationManifest
    {        
        public List<BadgeInfo> Badges { get; set; }
        public List<Leaderboard> Leaderboards { get; set; }
    }

    public class BadgeInfo
    {
        public string BadgeKey { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string IconUrl { get; set; }
        public string IconUrlInactive { get; set; }
    }

    public class Leaderboard
    {
        public string LBKey { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string IconUrl { get; set; }
        public string IconUrlInactive { get; set; }
    }

    public class App
    {
        public ROIInfo ROI { get; set; }
        public List<Objective> Objectives { get; set; }
        public List<Role> Roles { get; set; }
        public List<AppSetting> Settings { get; set; }
    }

    public class ROIInfo
    {
        public string Type { get; set; }
        public decimal AppCost { get; set; }
        public decimal AppValue { get; set; }
        public string Notes { get; set; }
        public List<ROIObjective> Objectives { get; set; }
    }

    public class ROIObjective
    {
        public string ObjectiveKey { get; set; }
        public decimal ObjectiveCost { get; set; }
        public decimal ObjectiveValue { get; set; }
        public string Notes { get; set; }        
    }

    public class Objective
    {
        [Required]
        public string ObjectiveKey { get; set; }
        public string TopicKey { get; set; }
        public string ParentObjectiveKey { get; set; }
        [Required]
        public string ObjectiveType { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public string Description { get; set; }
        public int MaxTry { get; set; }
        public int Order { get; set; }        
        public List<string> Roles { get; set; } 
        public Dictionary<string, string> MetaData { get; set; }
    }

    public class Role
    {
        [Required]
        public string RoleKey  { get; set; }
        [Required]
        public string Title { get; set; }
        public int MaxInRole { get; set; }        
        public List<string> Rights { get; set; }
        public Dictionary<string, string> MetaData { get; set; }
    }

    public class AppSetting
    {
        [Required]
        public string SettingKey { get; set; }
        public string Value { get; set; }
        public string Description { get; set; }
        public Dictionary<string, string> MetaData { get; set; }
    }
}
