﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    public class Credit : BaseModel
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public long ContentId { get; set; }        
        public string HubKey { get; set; }        
        public string AppKey { get; set; }        
        public Guid SessionId { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public int CreditConfigId { get; set; }
        [Required]
        public string CAKey { get; set; }
        public decimal CreditCount { get; set; }
        [Required]
        public string CertKey { get; set; }
        [JsonIgnore]
        public string CertDataJson { get; set; }
        public Dictionary<string, string> CertData { get; set; }
        public bool PreReqAckRequired{ get; set; }
        public bool PreReqAckCompleted { get; set; }
        public bool HasEval { get; set; }
        public bool EvalRequired { get; set; }
        public bool EvalCompleted { get; set; }
        public bool PreTestRequired { get; set; }
        public bool PreTestCompleted { get; set; }
        public decimal PreTestScore { get; set; }
        public bool PreTestPassed { get; set; }
        public bool PostTestRequired { get; set; }
        public bool PostTestCompleted { get; set; }
        public decimal PostTestScore { get; set; }
        public bool PostTestPassed { get; set; }
        public bool PostReqAckRequired { get; set; }
        public bool PostReqAckCompleted { get; set; }
        [Required]
        public string CreditStatus { get; set; } = Constants.CreditStatus.NotStarted;
        public DateTime DateCompleted { get; set; }

        [JsonIgnore]
        public string CertificationStatus
        {
            get
            {
                // return N/A if there are no requirements
                if (!PreReqAckRequired && !PreTestRequired && 
                    !PostTestRequired && !EvalRequired && !PostReqAckRequired)
                    return Constants.CertificationStatus.NA; 

                if (PostReqsCompleted)
                    return Constants.CertificationStatus.PostReqsCompleted;
                
                if (((PostTestRequired && !PostTestCompleted) ||
                    (EvalRequired && !EvalCompleted) ||
                    (PostReqAckRequired && !PostReqAckCompleted)) && PreReqsCompleted)
                    return Constants.CertificationStatus.PostReqsRequired;

                if (PreReqsCompleted)
                    return Constants.CertificationStatus.PreReqsCompleted;
                
                if ((PreReqAckRequired && !PreReqAckCompleted) ||
                    (PreTestRequired && !PreTestCompleted))
                    return Constants.CertificationStatus.PreReqsRequired;              

                return Constants.CertificationStatus.NA; ;                
            }
        }

        [JsonIgnore]
        public bool PreReqsCompleted
        {
            get
            {
                return ((!PreReqAckRequired || (PreReqAckRequired && PreReqAckCompleted)) &&
                        (!PreTestRequired || (PreTestRequired && PreTestCompleted)));                    
            }
        }

        [JsonIgnore]
        public bool PostReqsCompleted
        {
            get
            {
                return (!PostTestRequired || (PostTestRequired && PostTestCompleted)) &&
                       (!EvalRequired || (EvalRequired && EvalCompleted)) &&
                       (!PostReqAckRequired || (PostReqAckRequired && PostReqAckCompleted));
            }
        }
    }

    public class UserEval
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public long ContentId { get; set; }        
        public string HubKey { get; set; }
        public string AppKey { get; set; }
        public Guid SessionId { get; set; }        
        [Required]
        public string Username { get; set; }
        public int CreditConfigId { get; set; }
        public string Sentiment { get; set; } = Constants.EvalSentiments.Unknown;
        public DateTime DateAdded { get; set; } = DateTime.UtcNow;
        /// <summary>
        /// Not a db column
        /// </summary>
        public List<UserEvalAnswer> Answers { get; set; } 
    }

    public class UserEvalAnswer
    {
        [Key]
        public int Id { get; set; }
        public int UserEvalId { get; set; }
        public string QuestionKey { get; set; }
        public string QuestionTitle { get; set; }
        public string ResponseKey { get; set; }
        public string ResponseTitle { get; set; }        
    }

    public class UserTest
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public long ContentId { get; set; }
        public string HubKey { get; set; }
        public string AppKey { get; set; }
        public Guid SessionId { get; set; }
        public string Username { get; set; }
        [Required]
        public int CreditConfigId { get; set; }
        public string TestStatus { get; set; }
        public decimal TestScore { get; set; }
        public decimal PassingScore { get; set; }
        public int TotalQuestions { get; set; }
        public int CorrectQuestions { get; set; }
        public int IncorrectQuestions { get; set; }
        public DateTime DateAdded { get; set; } = DateTime.UtcNow;
        /// <summary>
        /// Not a db column
        /// </summary>
        public List<UserTestAnswer> Answers { get; set; }
    }

    public class UserTestAnswer
    {
        [Key]
        public int Id { get; set; }
        public int UserTestId { get; set; }
        public string QuestionKey { get; set; }
        public string QuestionTitle { get; set; }
        public string ResponseKey { get; set; }
        public string ResponseTitle { get; set; }
        public bool IsCorrect { get; set; }
    } 
}
