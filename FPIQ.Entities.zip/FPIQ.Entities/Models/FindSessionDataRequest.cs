﻿using System;

namespace FPIQ.Entities.Models
{
    public class FindSessionDataRequest
    {
        public Guid SessionId { get; set; }
        public string ForUsername { get; set; }
        public string KeyBeginsWith { get; set; }
        public string KeyEndsWith { get; set; }
        public string ParentKey { get; set; }
        public string GroupKey { get; set; }
        public string DataType { get; set; }
        public string Ref1 { get; set; }
        public string Ref2 { get; set; }
        public string Value { get; set; }
        public string ValueContains { get; set; }        
    }
}
