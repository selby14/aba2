﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class EmailMesssage
    {        
        [Key]
        [JsonIgnore]
        public int Id { get; set; }
        [Required]
        public string HubKey { get; set; }
        [Required]
        public string AppKey { get; set; }
        [Required]
        public string EmailFrom { get; set; }
        [Required]
        public string EmailTo { get; set; }        
        public string CC { get; set; }
        public string BCC { get; set; }
        [Required]
        public string Subject { get; set; }
        [Required]
        public string Message { get; set; }
        public bool IsMessageHtml { get; set; }
        public string Username { get; set; }
        public Guid SessionId { get; set; }        
        public DateTime DateTimeSent { get; set; } = DateTime.UtcNow;      
    }
}
