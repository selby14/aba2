﻿using System;
using System.Collections.Generic;

namespace FPIQ.Entities.Models
{
    public class ParamData
    {
        public Dictionary<string, object> Data { get; set; } = new Dictionary<string, object>();
        
        private object Get(string key)
        {
            return (Data.ContainsKey(key)) ? Data[key] : null;
        }

        public void Add(string key, object value)
        {
            if (Data == null)
                Data = new Dictionary<string, object>();

            Data.Add(key, value);
        }
              
        public int GetInt(string key)
        {
            var val = Get(key);
            var intVal = 0;
            if (val != null)
                int.TryParse(val.ToString(), out intVal);

            return intVal;
        }

        public decimal GetDecimal(string key)
        {
            var val = Get(key);
            var decValue = 0m;
            if (val != null)
                decimal.TryParse(val.ToString(), out decValue);

            return decValue;
        }

        public DateTime GetDate(string key)
        {
            var val = Get(key);
            var dtValue = new DateTime();
            DateTime value;
            if (val != null && DateTime.TryParse(val.ToString(), out value))
                dtValue = value;
            
            return dtValue;
        }

        public string GetString(string key)
        {
            var val = Get(key);
            return val == null ? null : val.ToString();
        }

        public bool GetBool(string key)
        {
            var strVal = GetString(key);
            if (string.IsNullOrEmpty(strVal)) return false;
            
            return (strVal.ToLowerInvariant() == "true" ||
                    strVal.ToLowerInvariant() == "yes" ||
                    strVal.ToLowerInvariant() == "on" ||
                    strVal.ToLowerInvariant() == "1");
        }

        public T GetData<T>(string key)
        {
            try
            {
                return (T)Get(key);
            }           
            catch
            {
                return default(T);
            }
        }

        public bool ContainsKey(string key)
        {
            return Data.ContainsKey(key);
        }

    }
}
