﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class SessionObjective
    {
        [Required]
        public string ObjectiveKey { get; set; }
        [Required]
        public string Status { get; set; }        
        public string Performance{ get; set; }        
        public int TryCount { get; set; }
        public int Duration { get; set; }
        public Dictionary<string, string> Data { get; set; }
    }
}
