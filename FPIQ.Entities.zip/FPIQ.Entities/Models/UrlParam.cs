﻿using System.Linq;
using Newtonsoft.Json;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class UrlParam
    {           
        [Required]
        public string Key { get; set; }                
        public string Value { get; set; }        
    }

    public class UrlParamCollection
    {        
        public List<UrlParam> Data { get; set; }
        public bool SingleParam { get; set; }
        public bool Encrypt { get; set; }

        public void AddParam(string key, string value)
        {
            if (string.IsNullOrEmpty(key)) return;
            key = key.Trim();
            if (HasParam(key))
            {
                var param = GetData(key);
                param.Value = value;
            }
            else
            {
                Data.Add(new UrlParam { Key = key, Value = value });
            }
        }

        public bool HasParam(string key)
        {
            if (string.IsNullOrEmpty(key)) return false;

            return Data.Any(d => d.Key.Equals(key, System.StringComparison.InvariantCultureIgnoreCase));                
        }

        public string GetValue(string key)
        {
            if (HasParam(key))
                return Data.FirstOrDefault(d => d.Key.Equals(key, System.StringComparison.InvariantCultureIgnoreCase)).Value;
            else
                return null;
        }

        public int GetValueAsInt(string key)
        {
            var val = GetValue(key);
            var intVal = 0;
            if (val != null)
                int.TryParse(val, out intVal);

            return intVal;
        }

        public decimal GetValueAsDecimal(string key)
        {
            var val = GetValue(key);
            var decValue = 0m;
            if (val != null)
                decimal.TryParse(val, out decValue);

            return decValue;
        }    

        public bool GetValueAsBool(string key)
        {
            var strVal = GetValue(key);
            if (string.IsNullOrEmpty(strVal)) return false;

            return (strVal.ToLowerInvariant() == "true" ||
                    strVal.ToLowerInvariant() == "yes" ||
                    strVal.ToLowerInvariant() == "on" ||
                    strVal.ToLowerInvariant() == "1");
        }


        #region " Private Methods "
        private UrlParam GetData(string key)
        {
            return Data?.FirstOrDefault(d => d.Key.Equals(key, System.StringComparison.InvariantCultureIgnoreCase));
        }
        #endregion
    }
}
