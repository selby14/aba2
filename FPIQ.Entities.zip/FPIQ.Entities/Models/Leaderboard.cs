﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    public class LeaderboardEntry
    {
        [Key]
        [Required]        
        public int Id { get; set; }
        [Required]
        public string HubKey { get; set; }
        [Required]
        public string AppKey { get; set; }        
        [Required]
        public string LBKey { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public int Points { get; set; }
        public string Data { get; set; }
        [Required]
        public DateTime DateAdded { get; set; } = DateTime.UtcNow;
        [Required]
        public DateTime LastModified { get; set; } = DateTime.UtcNow;
    }
}
