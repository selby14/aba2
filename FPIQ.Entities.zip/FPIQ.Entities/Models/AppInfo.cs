﻿namespace FPIQ.Entities.Models
{
    public class AppInfo : Content
    {        
        public string AppKey { get { return ContentKey; } set { ContentKey = value; }  }
        public string HubKey { get { return GroupKey; } set { GroupKey = value; } }
        public string AppConfigUrl { get { return Source; } set { Source = value; } }        
        public string BasePath { get { return Data.Get("BasePath"); } set { Data.Set("BasePath", value); } }
        public string ManifestJson { get { return Content1; } set { Content1 = value; } }        
    }
}