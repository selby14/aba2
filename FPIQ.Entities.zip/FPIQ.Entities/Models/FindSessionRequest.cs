﻿namespace FPIQ.Entities.Models
{
    public class FindSessionRequest
    {
        public string OwnerName { get; set; }
        public string SessionUsername { get; set; }
        public string SessionStatus { get; set; }
        public string ShareType { get; set; }
        public string AppKey { get; set; }
        public string HubKey { get; set; }        
        public string TimeStatus { get; set; }        
    }
}
