﻿using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class HubInfo : BaseModel
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string HubKey { get; set; }
        [Required]
        public string HubName { get; set; }
        [Required]
        public string ManifestUrl { get; set; }
    }
}
