﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    public class Content : BaseModel
    {
        private PropertyBag<string> _data;

        [Key]
        [Required]
        public long ContentId { get; set; } = -1;
        public int PortalId { get; set; } = -1;        
        public long ParentId { get; set; }
        [Required]
        public string ContentType { get; set; }
        public string ContentSubType { get; set; }
        public int Status { get; set; } = 0;
        public string ContentKey { get; set; }
        public string GroupKey { get; set; }
        [Required]
        public string Title { get; set; }  
        public string Description { get; set; }
        public string Source { get; set; }
        public string AuthorIds { get; set; }
        public string Keywords { get; set; }
        public string Tags { get; set; }
        public int ViewCount { get; set; } = 0;

        public int ContentI1 { get; set; }
        public bool ContentB1 { get; set; }
        public decimal ContentN1 { get; set; }
        public DateTime ContentD1 { get; set; }
        public string Content1 { get; set; }
        public string Content2 { get; set; }
        public bool HasCredit { get; set; }
        public int CreditConfigId { get; set; }        
        public string EmailQuestionTo { get; set; }

        [JsonIgnore]
        public string DataJson { get; set; }
        public PropertyBag<string> Data
        {
            get
            {
                return _data ?? (_data = new PropertyBag<string>(DataJson));
            }
        }

        [JsonIgnore]
        public List<int> AuthorList
        {
            get
            {
                if (string.IsNullOrEmpty(AuthorIds) || AuthorIds.Trim().Length == 0)
                {
                    return new List<int>();
                }

                var rawIds = AuthorIds.Trim().TrimEnd(';').Split(';');
                var idList = new List<int>();
                var authorId = 0;
                foreach (var strId in rawIds)
                {
                    int.TryParse(strId, out authorId);
                    if (authorId > 0)
                    {
                        idList.Add(authorId);
                    }
                }
                return idList;
            }
        }

        #region " Constructors "

        #endregion
    }

}
