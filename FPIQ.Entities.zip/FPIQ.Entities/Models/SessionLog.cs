﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class SessionLog
    {
        [Key]
        [JsonIgnore]
        public long Id { get; set; }
        [Required]
        public Guid SessionId { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public string Event { get; set; }        
        public DateTime LogTime { get; set; } = DateTime.UtcNow;

        #region " Constructors "     

        #endregion
    }
}
