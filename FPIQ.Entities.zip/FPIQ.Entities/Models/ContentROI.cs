﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    public class ContentROI
    {
        [Key]        
        public int Id { get; set; }
        public long ContentId { get; set; }
        public string HubKey { get; set; }        
        public string AppKey { get; set; }                
        public Guid SessionId { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public decimal Value { get; set; }
        [Required]
        public decimal Cost { get; set; }
        [Required]
        public decimal NetROI { get; set; }
        [Required]
        public DateTime DateAdded { get; set; } = DateTime.UtcNow;        
        public List<ContentROIDetail> Details { get; set; }
    }

    public class ContentROIDetail
    {
        [Key]        
        public int Id { get; set; }
        public int ContentROIId { get; set; }
        [Required]
        public string ActivityKey { get; set; }
        [Required]
        public string ActivityTitle { get; set; }
        [Required]
        public decimal ActivityValue { get; set; }
        [Required]
        public decimal ActivityCost { get; set; }
        [Required]
        public decimal ActivityNetROI { get; set; }        
    }
}
