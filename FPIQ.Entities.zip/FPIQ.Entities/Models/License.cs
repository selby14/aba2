﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    public class License
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string LicenseKey { get; set; }

        public string PurchasedByOrg { get; set; }

        public string PurchasedByUser { get; set; }

        public bool DirectUserAssignment { get; set; }

        public string AssignedToUser { get; set; }
        /// <summary>
        /// In UTC
        /// </summary>
        [Required]
        public DateTime PurchaseDate { get; set; } = DateTime.UtcNow;

        // Reference properties, not a table column
        public List<LicenseGrant> Grants { get; set; }
        public List<LicenseCode> Codes { get; set; }
    }

    public class LicenseGrant
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string GrantKey { get; set; }

        [Required]
        public string LicenseKey { get; set; }

        [Required]
        public string GrantType { get; set; }

        public string Code { get; set; }

        public string Username { get; set; }

        public int Count { get; set; }
        /// <summary>
        /// In UTC
        /// </summary>        
        public DateTime ExpirationDate { get; set; }

        public string Data { get; set; }

        // Reference only, not a table column        
        public List<UserLicenseUse> Usage { get; set; }
        [JsonIgnore]
        public bool IsExpired { get { return ExpirationDate != DateTime.MinValue && ExpirationDate <= DateTime.UtcNow; } }
        [JsonIgnore]
        public bool IsUnlimited { get { return GrantType == Constants.LicenseGrantTypes.Access; } }
    }

    public class LicenseCode
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string LicenseKey { get; set; }

        [Required]
        public string Code { get; set; }

        [Required]
        public string Org { get; set; }

        /// <summary>
        /// In UTC
        /// </summary>        
        public DateTime ExpirationDate { get; set; }

        public string AssignedToUser { get; set; }

        public bool Consumed { get; set; }

        public string ConsumedByUser { get; set; }

        // Reference property, not a table column
        public List<LicenseGrant> Grants { get; set; }
        [JsonIgnore]
        public bool IsExpired { get { return ExpirationDate != DateTime.MinValue && ExpirationDate <= DateTime.UtcNow; } }
    }
}
