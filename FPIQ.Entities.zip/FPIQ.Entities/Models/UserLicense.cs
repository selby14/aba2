﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    public class UserLicense
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string LicenseKey { get; set; }

        [Required]
        public string UserId { get; set; }

        public string Org { get; set; }

        public string Code { get; set; }

        // Reference property, not a table column
        public List<LicenseGrant> Grants { get; set; }
    }

    public class UserLicenseUse
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string LicenseKey { get; set; }

        [Required]
        public string GrantKey { get; set; }

        [Required]
        public string UserId { get; set; }

        [Required]
        public int Use { get; set; }

        public string Data { get; set; }

        public DateTime UseDate { get; set; } = DateTime.UtcNow;
    }
}
