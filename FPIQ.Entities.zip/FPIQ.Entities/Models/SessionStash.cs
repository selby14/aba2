﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class SessionStash
    {
        [Key]
        [Required]
        public int Id { get; set; }
        [Required]
        public string OwnerName { get; set; }
        [Required]
        public string SourceOwnerName { get; set; }
        [Required]
        public Guid SourceSessionId { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public SessionStashData Data { get; set; }
        [JsonIgnore]
        public string DataJson { get; set; }
        public DateTime DateCreated { get; set; } = DateTime.UtcNow;
    }

    public class SessionStashData
    {
        public SessionInfo SessionInfo { get; set; }
        public List<SessionDataItem> SessionData { get; set; }
        public SessionUser SessionUser { get; set; }
    }
}
