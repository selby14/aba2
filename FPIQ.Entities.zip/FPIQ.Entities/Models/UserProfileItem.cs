﻿using Newtonsoft.Json;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class UserProfileItem : BaseModel
    {
        [Key]        
        [JsonIgnore]
        public int Id { get; set; }        
        [Required]
        public string Username { get; set; }
        [Required]
        public string Key { get; set; }        
        public string Value { get; set; }
        public string ParentKey { get; set; }
        public bool ServerOnly { get; set; } 
    }
}
