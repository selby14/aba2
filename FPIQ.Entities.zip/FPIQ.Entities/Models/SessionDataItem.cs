﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class SessionDataItem: BaseModel
    {
        [Key]
        [JsonIgnore]
        public long Id { get; set; }
        [Required]
        public Guid SessionId { get; set; }
        public string DataType { get; set; }
        public string GroupKey { get; set; }
        public string Username { get; set; }
        [Required]        
        public string Key { get; set; }        
        public string Value { get; set; }        
        public string ParentKey { get; set; }        
        public string Ref1 { get; set; }
        public string Ref2 { get; set; }
        public List<SessionDataItem> Children { get; set; }        
    }
}
