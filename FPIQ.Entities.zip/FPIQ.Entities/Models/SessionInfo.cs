﻿using System;
using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    public class SessionInfo : BaseModel
    {
        [Key]
        [Required]        
        public Guid Id { get; set; }        
        [Required]
        public string AppKey { get; set; }
        [Required]
        public string HubKey { get; set; }                              
        [Required]
        public string SessionType { get; set; }
        [Required]
        public string ShareType { get; set; }
        public string ShareCode { get; set; }
        public bool RequirePassword { get; set; }        
        public string Password { get; set; }
        [Required]
        public DateTime StartTime { get; set; }
        [Required]
        public DateTime EndTime { get; set; }
        [Required]
        public string Status { get; set; }
        [Required]
        public int MaxUsers { get; set; }
        [Required]
        public string OwnerName { get; set; }
        public Guid RelatedSessionId { get; set; }        
    }
}
