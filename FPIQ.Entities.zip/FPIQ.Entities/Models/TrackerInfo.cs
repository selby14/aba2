﻿using Newtonsoft.Json;
using System;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class TrackerInfo
    {
        [Key]
        [JsonIgnore]
        public int Id { get; set; }        
        public string HubKey { get; set; }
        [Required]
        public string Context { get; set; }
        [Required]
        public string Event { get; set; }
        [Required]
        public string RefId { get; set; }        
        public string Username { get; set; }
        public string Loc { get; set; }
        public string Group { get; set; }
        public string App { get; set; }        
        public Guid SessionId { get; set; }
        public string Objective { get; set; }
        public string Data { get; set; }
        public string Role { get; set; }
        public DateTime DateStamp { get; set; } = DateTime.UtcNow;

        #region " Constructors "     

        #endregion
    }
}
