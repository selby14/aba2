﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    /// <summary>
    /// High performance property bag that can be minimum performance implications
    /// when retreiving large amounts of rows from a database. It's inner serialization as well as
    /// heavy objects are only initialized if required otherwise it just saves the serialized string
    /// passed to it and returns it when asked.
    /// </summary>
    public class PropertyBag<T>
    {
        private string _dataString = "";
        private bool _dataStringInitialized; // set to true when the data string is passed in via the constructor
        private bool _isDirty; // set to true when the data is edited
        private Dictionary<string, T> _data;
              
        public PropertyBag() { }
        
        public PropertyBag(string serializedData)
        {            
            _dataString = serializedData;
            _dataStringInitialized = true;
        }
        
        /// <summary>
        /// Count of items in property bag
        /// </summary>
        public int Count 
        {
            get
            {
                if (Data == null) return 0;
                return Data.Count;                   
            }
        }


        /// <summary>
        /// Sets a key in the property bag
        /// </summary>
        /// <param name="key">The uniqe key</param>
        /// <param name="value">The value of the key</param>
        /// <param name="replaceIfFound">Whether to replace the key if found. By default it will do so. If false will throw an error</param>
        public void Set(string key, T value, bool replaceIfFound = true)
        {            
            // Make sure the 
            key = key.ToLowerInvariant();
            if (Data.ContainsKey(key))
            {
                if (!replaceIfFound) throw new Exception("Key: " + key + " already exists and you elected to not replace the existing value");
                Data[key] = value;
            }
            else
            {
                Data.Add(key, value);
            }
            _isDirty = true; // set it as dirty since it has changed
        }

        /// <summary>
        /// Retreives a particlar value from the Bag.
        /// </summary>
        /// <param name="key">The key of the value to retreive</param>
        /// <param name="strict">When false, and the key is not found, an empty string is returned. If true and the key is not found, an error will result</param>
        /// <returns></returns>
        public T Get(string key, bool strict = false)
        {
            key = key.ToLowerInvariant();
            if (!strict && !Data.ContainsKey(key)) return default(T);
            return Data[key];
        }

        /// <summary>
        /// Removes a key in the property bag
        /// </summary>
        /// <param name="key">The uniqe key</param> 
        public void Remove(string key)
        {        
            key = key.ToLowerInvariant();
            if (Data.ContainsKey(key))
            {                
                Data.Remove(key);
                _isDirty = true; // set it as dirty since it has changed
            }
        }

        private Dictionary<string, T> Data
        {
            get
            {
                // Return the data if already initialized
                if (_data != null) return _data;

                // Create a new one if the dataString was never initialized or it was initialized empty
                if (!_dataStringInitialized || string.IsNullOrEmpty(_dataString))
                {
                    _data = new Dictionary<string, T>();
                }
                // Otherwise deserialize it
                else
                {
                    _data = JsonConvert.DeserializeObject<Dictionary<string, T>>(_dataString);
                }    
                return _data;
            }
        }

        /// <summary>
        /// Determines whether the property bag has changed
        /// </summary>
        public bool IsDirty { get { return _isDirty; } }

        /// <summary>
        /// Serializes the property bag into a JSON string
        /// </summary>
        public string Serialize()
        {
            // If it was never deserialized, which means it was not used, return the _dataString as it would contain the right data whether 
            //  initialized or not
            if (_data == null) return _dataString;
            // If it was deserialized after being initialized with a data string, but it was not changed then return the original data string
            if (_dataStringInitialized && !_isDirty) return _dataString;
            // Otherwise refresh the _dataString and reset the dirty flag
            _dataString = JsonConvert.SerializeObject(_data);
            // Reset the dirty flag
            _isDirty = false;
            // Returned the deserialized string
            return _dataString;
        }       
       

        /// <summary>
        /// Returns a list of items in property bag
        /// </summary>
        public List<T> ToList()
        {
            if (Data == null) return null;

            var list = new List<T>();
            foreach (var item in Data)
            {
                list.Add(Data[item.Key]);
            }
            return list;
        }
      
        /// <summary>
        /// Returns a serialized JSON string of the property bag
        /// </summary>
        public override string ToString()
        {
            return Serialize();
        }
    }
}
