﻿using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class Setting : BaseModel
    {
        [Key]        
        public int Id { get; set; }                
        [Required]
        public string HubKey { get; set; } = Constants.SettingTypes.System;
        [Required]
        public string SettingKey { get; set; }        
        public string SettingValue { get; set; }
        public string SettingType { get; set; } = Constants.SettingTypes.System;
        public string ParentKey { get; set; }
        public string Description { get; set; }
        public bool IsSecure { get; set; }
        public int PortalId { get; set; }
        public string EditorType { get; set; } = Constants.EditorTypes.Raw;
        
        #region " Constructors "
        public Setting() { }

        public Setting(Setting setting)
        {
            foreach (var prop in setting.GetType().GetProperties())
            {
                var property = GetType().GetProperty(prop.Name);
                if (property != null && property.GetGetMethod() != null && property.GetSetMethod() != null)
                {
                    property.SetValue(this, prop.GetValue(setting, null), null);
                }
            }
        }

        #endregion
    }
}