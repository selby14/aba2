﻿using System;
using Newtonsoft.Json;

namespace FPIQ.Entities.Models
{
    public abstract class BaseModel
    {
        [JsonIgnore]
        public DateTime DateCreated { get; set; } = DateTime.UtcNow;
        [JsonIgnore]
        public string CreatedBy { get; set; }
        [JsonIgnore]
        public DateTime LastModified { get; set; } = DateTime.UtcNow;
        [JsonIgnore]
        public string LastModifiedBy { get; set; }
    }
}
