﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class CreditConfigDbItem : BaseModel
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Title { get; set; }
        [Required]
        public string ConfigJson{ get; set; }        
    }

    public class CreditConfig
    {
        public List<AccreditationConfig> Accreditations {get; set;}
        public List<Test> Tests { get; set; }
        public List<Eval> Evals { get; set; }

        public static CreditConfig CreateSample()
        {
            var manifest = new CreditConfig
            {
                Accreditations = new List<AccreditationConfig> {
                    new AccreditationConfig{
                        PreReqAck = new ReqAckConfig(),
                        PreTest = new TestConfig(),
                        PostReqAck = new ReqAckConfig(),
                        PostTest = new TestConfig(),
                        Eval = new EvalConfig(),
                        Cert = new CertConfig {
                            Data = new Dictionary<string, string>()
                        }
                    }
                },
                Tests = new List<Test> {
                    new Test {
                        Questions = new List<Question> {
                            new Question()
                        }
                    }
                },
                Evals = new List<Eval> {
                    new Eval{
                        Questions = new List<Question>{
                            new Question()
                        }
                    }
                }
            };
            manifest.Accreditations[0].Cert.Data.Add("data1", "value 1");
            return manifest;
        }
    }

    public class AccreditationConfig
    {
        [Required]
        public string CAKey { get; set; }
        [Required]
        public string Title { get; set; }
        public string Description { get; set; }
        public decimal CreditCount { get; set; }
        public ReqAckConfig PreReqAck { get; set; }
        public TestConfig PreTest { get; set; }
        public ReqAckConfig PostReqAck { get; set; }
        public TestConfig PostTest { get; set; }              
        public EvalConfig Eval { get; set; }
        public CertConfig Cert { get; set; }
        public decimal Value { get; set; }
    }

    public class EvalConfig
    {
        public bool HasEval { get; set; }
        public bool IsRequired { get; set; }                
        public string Key { get; set; }
    }

    public class CertConfig
    {
        public bool HasCert { get; set; }
        public string Key { get; set; }        
        public Dictionary<string, string> Data { get; set; }
    }

    public class ReqAckConfig
    {
        public bool IsRequired { get; set; }
        public string Content { get; set; }
    }

    public class TestConfig
    {
        public bool IsRequired { get; set; }
        public string Key { get; set; }
    }
    
    public class Eval
    {
        public string Key { get; set; }                
        public List<Question> Questions { get; set; }
        public string EmailTo { get; set; }
    }

    public class Test
    {        
        public string Key { get; set; }        
        public List<Question> Questions { get; set; }
        public decimal PassingScore { get; set; }
    }

    public class Question
    {
        [Required]
        public string Type { get; set; }
        [Required]
        public string Key { get; set; }
        [Required]
        public string Title { get; set; }
        public string Description { get; set; }        
        public List<QuestionOption> Options { get; set; }        
        public string CorrectAnswer { get; set; }
        /// <summary>
        /// Comma-separated values
        /// </summary>
        public string PositiveAnswers { get; set; }
        /// <summary>
        /// Comma-separated values
        /// </summary>
        public string NegativeAnsers { get; set; }
    }

    public class QuestionOption
    {        
        [Required]
        public string Key { get; set; }
        [Required]
        public string Title { get; set; }       
    }
}
