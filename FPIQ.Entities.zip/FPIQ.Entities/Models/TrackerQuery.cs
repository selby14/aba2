﻿using System;
using System.ComponentModel.DataAnnotations;

namespace FPIQ.Entities.Models
{
    public class TrackerQuery
    {
        [Required]
        public string HubKey { get; set; }
        public string Context { get; set; }
        public string Event { get; set; }
        public string RefId { get; set; }
        public string Username { get; set; }
        public string Loc { get; set; }
        public string LocStartsWith { get; set; }
        public string LocEndsWith { get; set; }
        public string LocContains { get; set; }
        public string GroupStartsWith { get; set; }
        public string GroupEndsWith { get; set; }
        public string GroupContains { get; set; }
        public string App { get; set; }
        public Guid SessionId { get; set; }
        public string Objective { get; set; }
        public string Data { get; set; }
        public string DataStartsWith { get; set; }
        public string DataEndsWith { get; set; }
        public string DataContains { get; set; }
        public string Role { get; set; }
        public DateTime DateStart { get; set; }
        public DateTime DateEnd { get; set; }

        #region " Constructors "     

        #endregion
    }
}
