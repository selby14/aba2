﻿using FPIQ.Core;
using System;

namespace FPIQ.Core
{   
    public static class FPIQContainer
    {
        private static IContainer _current;
        public static IContainer Current
        {
            get
            {
                return _current;
            }
        }

        public static void SetContainer(Func<IContainer> create)
        {
            if (create == null) throw new ArgumentNullException("create");
            _current = create();
        }
    }
}
