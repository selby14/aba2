﻿using FPIQ.Entities.Models;
using System;
using System.Collections.Generic;

namespace FPIQ.Core.Repos
{
    public interface IBadgesRepo
    {   
        int AddEntry(BadgeEntry data);
        void UpdateEntry(BadgeEntry data);
        void DeleteEntry(int id);
        void DeleteEntry(string hubKey, string appKey, string badgeKey, string username, Guid sessionId = default(Guid));
        void DeleteEntries(string hubKey, string appKey, string badgeKey = "");
        BadgeEntry GetEntry(int id);
        BadgeEntry GetEntry(string hubKey, string appKey, string badgeKey, string username, Guid sessionId = default(Guid));
        List<BadgeEntry> GetEntries(string hubKey, string appKey, string badgeKey = "", string username = "", Guid sessionId = default(Guid));             
    }
}
