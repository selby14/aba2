﻿using System.Collections.Generic;
using FPIQ.Entities.Models;

namespace FPIQ.Core.Repos
{
    public interface IContentRepo
    {    
        long Add(Content content);
        void Update(Content content);
        void Delete(long id);
        void IncrementViewCount(long id);
        Content GetContent(long id);
        Content GetContent(string contentKey, string groupKey);
        T GetContent<T>(long id);
        T GetContent<T>(string contentKey, string groupKey);
        List<string> GetGroupKeys();
        List<T> GetContents<T>(string groupKey, string contentType = "", string keywords = "");
        List<T> GetContents<T>(int portalId = -1, string contentType = "", string keywords = "", string tags = "");
        List<T> GetContents<T>(List<long> contentIds);        
        List<Content> GetContents(int portalId = -1, string contentType = "", string keywords = "", string tags = "");
    }    
}
