﻿using FPIQ.Entities.Models;
using System;
using System.Collections.Generic;

namespace FPIQ.Core.Services
{
    public interface ILeaderboardsService
    {     
        void Add(string hubKey, string appKey, string lbKey, string username, int points, string data = "");
        void Remove(string hubKey, string appKey, string lbKey, string username);
        List<LeaderboardEntry> GetUsers(string hubKey, string appKey, string lbKey);
    }   
}
