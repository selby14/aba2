﻿using FPIQ.Entities.Models;

namespace FPIQ.Core.Repos
{
    public interface IEmailLogsRepo
    {
        void AddToLog(EmailMesssage email);
    }
}
