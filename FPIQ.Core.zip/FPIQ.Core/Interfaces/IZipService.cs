﻿namespace FPIQ.Core.Services
{
    public interface IZipService
    {
        byte[] GetFile(string zipFilePath, string fileName);
        void DeleteFile(string zipFilePath, string fileName);
        bool FileExists(string zipFilePath, string fileName);
        void Unzip(string zipFilePath, string destPath, bool deleteDestFolder = false, bool overwriteFile = false);
        void Unzip(string zipFilePath, string sourceFolderInZip, string destPath, bool deleteDestFolder = false, bool overwriteFile = false);
    }
}
