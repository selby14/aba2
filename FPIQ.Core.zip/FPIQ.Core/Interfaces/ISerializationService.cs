﻿namespace FPIQ.Core.Services
{
    public interface ISerializationService
    {
        T JsonDeserialize<T>(string serializedData);
        string JsonSerialize(object data);
    }
}
