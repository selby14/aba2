﻿using FPIQ.Entities.Models;
using System.Collections.Generic;

namespace FPIQ.Core.Repos
{
    public interface IUsersRepo
    {        
        int AddUserProfile(UserProfileItem data);
        void UpdateUserProfile(UserProfileItem data);
        void DeleteUserProfile(int id);
        void DeleteUserProfile(string username, string profileKey);
        UserProfileItem GetUserProfile(string username, string profileKey);

        List<UserInfo> GetUsers(List<string> unames);
        List<UserInfo> GetUsers(int portalId, string unameStartsWith = "");
        List<string> GetUsernames(string unameStartsWith);
        UserInfo GetUserInfo(int userId);
        UserInfo GetUserInfo(string username);
    }
}
