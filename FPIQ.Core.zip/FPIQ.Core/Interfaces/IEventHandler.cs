﻿using FPIQ.Entities.Models;

namespace FPIQ.Entities.Interfaces
{
    public interface IEventHandler
    {
        void Execute(string eventName, ParamData data = null, object context = null, string worldKey = "", string scenarioKey = "");
    }
}
