﻿using System.Collections.Generic;
using FPIQ.Entities.Models;

namespace FPIQ.Core.Repos
{
    public interface ISettingsRepo
    {
        int Add(Setting data);
        void Update(Setting data);
        void Delete(int id);
        void Delete(string settingKey, string hubKey);
        Setting GetSetting(int id);
        Setting GetSetting(string settingKey, string hubKey, string settingType = "", string parentKey = "" );        
        List<Setting> GetSettings(string hubKey = "", string keywords = "", string settingType = "");       
    }
}
