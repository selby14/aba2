﻿using FPIQ.Entities.Models;
using System.Collections.Generic;

namespace FPIQ.Core.Repos
{
    public interface ICreditConfigRepo
    {
        int Add(CreditConfigDbItem data);
        void Update(CreditConfigDbItem data);
        void Delete(int id);
        CreditConfigDbItem Get(int id);
        CreditConfigDbItem Get(string title);
        List<CreditConfigDbItem> Search(string keywords = "");
    }
}
