﻿using System.Collections.Generic;
using FPIQ.Entities.Models;

namespace FPIQ.Core.Repos
{
    public interface IHubsRepo
    {
        int Add(HubInfo data);
        void Update(HubInfo data);
        void Delete(int id);
        void Delete(string hubKey);
        HubInfo GetHub(int id);
        HubInfo GetHub(string hubKey);
        List<HubInfo> GetHubs(string keyword = "");       
    }
}
