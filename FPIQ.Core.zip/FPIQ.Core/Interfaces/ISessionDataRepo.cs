﻿using System;
using System.Collections.Generic;
using FPIQ.Entities.Models;

namespace FPIQ.Core.Repos
{
    public interface ISessionDataRepo
    {
        long Add(SessionDataItem data);
        void Update(SessionDataItem data);
        void UpdateValue(long id, string value = "");
        void Delete(long id);
        void Delete(Guid sessionId, string key, string username = "", bool deleteChildren = false);        
        void DeleteChildren(Guid sessionId, string parentKey, string username = "");
        SessionDataItem GetData(long id);
        SessionDataItem GetData(Guid sessionId, string key, string username = "");        
        long GetDataId(Guid sessionId, string key, string username = "");        
        List<SessionDataItem> GetDataItems(Guid sessionId, List<string> keys, string username = "", bool includeChildren = false);
        List<SessionDataItem> GetDataItemsByType(Guid sessionId, string sessionDataType, string username = "");
        List<SessionDataItem> GetChildren(Guid sessionId, string parentKey, string username = "");
        List<SessionDataItem> FindData(FindSessionDataRequest request);
    }
}
