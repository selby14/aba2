﻿using System;

namespace FPIQ.Core.Services
{
    public interface ICacheService
    {
        void Set(string key, object value);
        void Set(string key, object value, DateTime absoluteExpiration);
        void Remove(string key);
        object Get(string key);
        T Get<T>(string key);
        bool Contains(string key);        
    }
}
