﻿using System.Threading.Tasks;

namespace FPIQ.Core.Services
{
    public interface ISmsService
    {
        Task SendSmsAsync(string number, string message);
    }
}
