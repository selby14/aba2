﻿using System.Collections.Generic;
using FPIQ.Entities.Models;
using System;

namespace FPIQ.Core.Repos
{
    public interface ISessionsRepo
    {
        #region " Sessions "
        List<SessionInfo> FindSessions(FindSessionRequest request, int resultCountLimit = 500);
        SessionInfo GetSession(Guid sessionId);
        SessionInfo GetSession(string shareCode);
        void AddSession(SessionInfo data);
        void UpdateSession(SessionInfo data);
        void DeleteSession(Guid sessionId);
        #endregion

        #region " Session Users "
        long AddSessionUser(SessionUser data);
        void UpdateSessionUser(SessionUser data);
        List<SessionUser> GetSessionUsers(Guid sessionId);        
        SessionUser GetSessionUser(Guid sessionId, string userId);        
        void DeleteSessionUser(Guid sessionId, string userId);
        #endregion

        #region " Session Stash "
        int AddSessionStash(SessionStash data);
        SessionStash GetSessionStash(int sessionStashId);
        List<SessionStash> GetSessionStashes(string ownerName, bool includeData = false);
        void DeleteSessionStash(int sessionStashId);
        #endregion
    }
}
