﻿using FPIQ.Entities.Models;
using System.Collections.Generic;

namespace FPIQ.Core.Services
{
    public interface IUrlRepo
    {
        string GetClientUrl(string url, UrlParamCollection param = null);
        string GetClientUrl(string url, string hubKey, string appKey, UrlParamCollection param = null);
        string GetModuleUrl(string moduleName, UrlParamCollection param = null);
        string GetModuleUrl(string moduleName, string hubKey, UrlParamCollection param = null);
        UrlParamCollection GetCurrentUrlParams();
        string ParamsToQueryString(UrlParamCollection param);        
    }
}
