﻿using System.Collections.Generic;
using FPIQ.Entities.Models;

namespace FPIQ.Core.Services
{
    public interface IUsersService
    {
        UserInfo GetMyInfo(string username);
        List<UserInfo> GetUsers(int portalId, string unameStartsWith = "");
        UserProfileItem GetProfileData(string username, string key);        
        string GetProfileValue(string username, string key);
        void SetProfileData(string username, string key, string value, string parentKey = "", bool serverOnly = false);
        void DeleteProfileData(string username, string key);
    }
}
