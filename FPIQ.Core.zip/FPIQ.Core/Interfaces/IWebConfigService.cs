﻿namespace FPIQ.Core.Services
{
    public interface IWebConfigService
    {
        string GetAppSetting(string key);
        bool GetAppSettingAsBool(string key);
        int GetAppSettingAsInt(string key);
        string DBConnectionString { get; }
        string DBProviderName { get; }
    }
}
