﻿using System;

namespace FPIQ.Core
{
    public interface IContainer : IDisposable
    {
        T GetInstance<T>();
        object GetInstance(Type type);        
        void Register<TContract, TImplementation>();
        void RegisterInstance<T>(object instance);
        void RemoveInstance(Type type);
        bool HasInstance(Type type);   
    }
}
