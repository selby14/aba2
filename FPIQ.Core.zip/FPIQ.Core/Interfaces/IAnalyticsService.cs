﻿using FPIQ.Entities.Models;
using System.Collections.Generic;

namespace FPIQ.Core.Services
{
    public interface IAnalyticsService
    {
        LearningSummaryData GetLearningSummary(string hubKey, string appKey = "");
        UserStatsData GetUserStats(int portalId);
        SessionStatsData GetSessionStats(string hubKey, string appKey = "");
        CreditStatsData GetCreditStats(string hubKey, string appKey = "");
        List<GameData> GetGameList(string hubKey);
    }   
}
