﻿using FPIQ.Entities.Models;

namespace FPIQ.Core.Repos
{
    public interface ISessionLogsRepo
    {
        long Add(SessionLog data);
        void Delete(long logId);
        SessionLog GetLog(long logId);
    }
}
