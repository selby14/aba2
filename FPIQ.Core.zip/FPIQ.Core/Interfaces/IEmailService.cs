﻿using System.Collections.Generic;
using System.Threading.Tasks;
using FPIQ.Entities.Models;

namespace FPIQ.Core.Services
{
    public interface IEmailService
    {        
        Task SendEmailAsync(EmailMesssage msg, List<string> attachments = null);        
        void SendEmail(EmailMesssage msg, List<string> attachments = null);
    }
}
