﻿using System;
using System.Collections.Generic;
using FPIQ.Entities.Models;

namespace FPIQ.Core.Repos
{
    public interface ICreditsRepo
    {
        int Add(Credit data);
        void Update(Credit data);
        void Delete(int id);
        void Delete(long contentId, string username, string caKey, Guid sessionId = default(Guid));
        Credit GetCredit(int id);        
        Credit GetCredit(long contentId, string username, string caKey, Guid sessionId = default(Guid));
        Credit GetCredit(string hubKey, string appKey, string username, Guid sessionId = default(Guid));
        List<Credit> GetCredits(long contentId);
        List<Credit> GetCredits(string hubKey, string appKey = "");

        #region " Evals "
        int AddEval(UserEval data);
        void UpdateEval(UserEval data);
        void DeleteEval(int id);
        int AddEvalAnswer(UserEvalAnswer data);
        UserEval GetEval(int id);
        UserEval GetEval(string username, string hubKey, string appKey, Guid sessionId = default(Guid));
        UserEval GetEval(string username, long contentId, Guid sessionId = default(Guid));
        List<UserEval> GetEvals(params long[] contentId);
        List<UserEval> GetEvals(string hubKey, string appKey = "");
        List<UserEvalAnswer> GetEvalAnswers(int evalId);
        #endregion

        #region " Tests "        
        int AddTest(UserTest data);
        void UpdateTest(UserTest data);
        void DeleteTest(int id);
        int AddTestAnswer(UserTestAnswer data);
        UserTest GetTest(int id);
        UserTest GetTest(string username, string hubKey, string appKey, Guid sessionId = default(Guid));
        UserTest GetTest(string username, long contentId, Guid sessionId = default(Guid));
        List<UserTest> GetTests(params long[] contentId);
        List<UserTest> GetTests(string hubKey, string appKey = "");
        List<UserTestAnswer> GetTestAnswers(int testId);
        #endregion


    }
}
