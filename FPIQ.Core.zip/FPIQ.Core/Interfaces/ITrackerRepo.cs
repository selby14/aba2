﻿using FPIQ.Entities.Models;
using System.Collections.Generic;

namespace FPIQ.Core.Repos
{
    public interface ITrackerRepo
    {
        void Track(TrackerInfo data);
        List<TrackerInfo> Search(TrackerQuery query);
    }
}
