﻿namespace FPIQ.Core.Services
{
    public interface IUtilities
    {
        string MapPath(string virtualPath);        
    }
}
