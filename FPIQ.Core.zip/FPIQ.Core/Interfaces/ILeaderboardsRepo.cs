﻿using FPIQ.Entities.Models;
using System.Collections.Generic;

namespace FPIQ.Core.Repos
{
    public interface ILeaderboardsRepo
    {
        #region " Leaderboard Entries "

        int AddEntry(LeaderboardEntry data);
        void UpdateEntry(LeaderboardEntry data);
        void DeleteEntry(int id);
        void DeleteEntry(string hubKey, string appKey, string lbKey, string username);
        void DeleteEntries(string hubKey, string appKey, string lbKey);

        LeaderboardEntry GetEntry(int id);
        LeaderboardEntry GetEntry(string hubKey, string appKey, string lbKey, string username);
        List<LeaderboardEntry> GetEntries(string hubKey, string appKey, string lbKey, string username = "");        

        #endregion
    }
}
