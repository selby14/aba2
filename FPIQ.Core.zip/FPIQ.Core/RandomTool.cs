﻿using System;

namespace FPIQ.Core
{
    public static class RandomTool
    {
        private static Random rd = new Random();

        /// <summary>
        /// Generate random number
        /// </summary>
        /// <param name="noOfDigits">Number of digits (1 to 10)</param>
        /// <returns>Random number in string</returns>
        public static string GenerateRandomNumber(int noOfDigits)
        {
            if (noOfDigits < 0 || noOfDigits > 10) return string.Empty;

            var bytes = new byte[4];
            var rng = System.Security.Cryptography.RandomNumberGenerator.Create();
            rng.GetBytes(bytes);
            ulong random = BitConverter.ToUInt32(bytes, 0) % ulong.Parse("1".PadRight(noOfDigits + 1, '0'));

            return random.ToString("".PadRight(noOfDigits, '0'));
        }

        /// <summary>
        /// Generate random string
        /// </summary>
        /// <param name="stringLength">String length</param>
        /// <returns>Random string</returns>
        public static string GenerateRandomString(int stringLength)
        {
            const string allowedChars = "ABCDEFGHJKLMNOPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz0123456789";
            char[] chars = new char[stringLength];

            for (int i = 0; i < stringLength; i++)
            {
                chars[i] = allowedChars[rd.Next(0, allowedChars.Length)];
            }

            return new string(chars);
        }
    }
}
