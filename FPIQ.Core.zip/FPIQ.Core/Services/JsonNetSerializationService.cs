﻿using Newtonsoft.Json;

namespace FPIQ.Core.Services
{  
    public class JsonNetSerializationService : ISerializationService
    {
        public T JsonDeserialize<T>(string serializedData)
        {
            return JsonConvert.DeserializeObject<T>(serializedData);
        }

        public string JsonSerialize(object data)
        {
            return JsonConvert.SerializeObject(data, new JsonSerializerSettings
            {
                ReferenceLoopHandling = ReferenceLoopHandling.Ignore,
                PreserveReferencesHandling = PreserveReferencesHandling.None
            });
        }
    }
}
