﻿using System;
using System.Collections.Generic;
using FPIQ.Core.Repos;
using FPIQ.Entities.Models;

namespace FPIQ.Core.Services
{
    public interface ITrackerService
    {
        void Track(TrackerInfo data);
        List<TrackerInfo> Query(TrackerQuery query);
    }

    public class TrackerService : ITrackerService
    {
        private readonly ITrackerRepo _repo;
                
        #region " Constructors "
        /// <summary>
        /// Default constructor
        /// </summary>
        public TrackerService()
        {            
            _repo = FPIQContainer.Current.GetInstance<ITrackerRepo>();            
        }

        /// <summary>
        /// Testable constructor 
        /// </summary>                
        public TrackerService(ITrackerRepo repo)
        {
            _repo = repo;            
        }
        #endregion

        /// <summary>
        /// Adds tracker info
        /// </summary>
        /// <param name="trackerInfo"></param>        
        public void Track(TrackerInfo trackerInfo)
        {
            if (trackerInfo == null)
                throw new ArgumentNullException("trackerInfo");
            if (string.IsNullOrEmpty(trackerInfo.HubKey))
                throw new ArgumentNullException("trackerInfo.hubKey");
            if (string.IsNullOrEmpty(trackerInfo.Context))
                throw new ArgumentNullException("trackerInfo.context");
            if (string.IsNullOrEmpty(trackerInfo.Event))
                throw new ArgumentNullException("trackerInfo.event");
            if (string.IsNullOrEmpty(trackerInfo.RefId))
                throw new ArgumentNullException("trackerInfo.refId");

            trackerInfo.DateStamp = DateTime.UtcNow;
            _repo.Track(trackerInfo);    
        }

        /// <summary>
        /// Searches tracking 
        /// </summary>   
        public List<TrackerInfo> Query(TrackerQuery query)
        {
            if (query == null)
                throw new ArgumentNullException("query");
            if (string.IsNullOrEmpty(query.HubKey))
                throw new ArgumentNullException("query.hubKey");

            return _repo.Search(query);
        }
    }
}
