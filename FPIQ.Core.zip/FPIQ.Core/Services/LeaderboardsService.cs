﻿using System;
using System.Linq;
using System.Collections.Generic;
using FPIQ.Core;
using FPIQ.Core.Extensions;
using FPIQ.Core.Repos;
using FPIQ.Core.Services;
using FPIQ.Entities.Models;

namespace FPIQ.Core.Services
{
    /// <summary>
    /// DNNLeaderboardsService   
    /// </summary>
    public class LeaderboardsService : ILeaderboardsService
    {
        private readonly ILeaderboardsRepo _repo;
        private readonly IAppConfigService _appConfigSvc;
        private readonly ICacheService _cacheSvc;
        private string CreateCacheKey(string hubKey, string appKey, string lbKey) { return $"FPIQ:{hubKey}:{appKey}:LB:{lbKey}".ToUpper(); }

        #region " Constructors "
        /// <summary>
        /// Default constructor
        /// </summary>
        public LeaderboardsService()
        {
            _repo = FPIQContainer.Current.GetInstance<ILeaderboardsRepo>();
            _appConfigSvc = FPIQContainer.Current.GetInstance<IAppConfigService>();
            _cacheSvc = FPIQContainer.Current.GetInstance<ICacheService>();
        }       

        /// <summary>
        /// Testable constructor
        /// </summary>
        public LeaderboardsService(ILeaderboardsRepo repo, IAppConfigService appConfigSvc, ICacheService cacheSvc)
        {
            _repo = repo;
            _appConfigSvc = appConfigSvc;
            _cacheSvc = cacheSvc;
        }
        #endregion

        /// <summary>
        /// Add leaderboard entry
        /// </summary>   
        public void Add(string hubKey, string appKey, string lbKey, string username, int points, string data = "")
        {
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (string.IsNullOrEmpty(lbKey))
                throw new ArgumentNullException("lbKey");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");            

            var app = _appConfigSvc.GetApp(appKey, hubKey);
            if (app == null)
                throw new ApplicationException($"App not found: '{appKey}'");
            if (app.Gamification == null || app.Gamification.Leaderboards == null || app.Gamification.Leaderboards.Count == 0)
                throw new ApplicationException($"Leaderboard '{lbKey}' not found for app '{appKey}'");
            var leaderboard = app.Gamification.Leaderboards.FirstOrDefault(lb => lb.LBKey.EqualsIgnoreCase(lbKey));
            if (leaderboard == null)
                throw new ApplicationException($"Leaderboard '{lbKey}' not found for app '{appKey}'");

            var entry = _repo.GetEntry(hubKey, appKey, lbKey, username);
            if (entry != null)
            {                
                entry.Points = points;
                entry.Data = data;
                entry.LastModified = DateTime.UtcNow;
                _repo.UpdateEntry(entry);
            }
            else
            {
                entry = new LeaderboardEntry
                {
                    HubKey = hubKey,
                    AppKey = appKey,
                    LBKey =lbKey,
                    Username = username,                    
                    Points = points,                    
                    Data = data
                };
                _repo.AddEntry(entry);
            }            
            ResetCache(hubKey, appKey, lbKey);
        }

        /// <summary>
        /// Get leaderboard users
        /// </summary>        
        public List<LeaderboardEntry> GetUsers(string hubKey, string appKey, string lbKey)
        {
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (string.IsNullOrEmpty(lbKey))
                throw new ArgumentNullException("lbKey");

            return GetEntriesFromCache(hubKey, appKey, lbKey);
        }

        /// <summary>
        /// Remove leaderboard entry
        /// </summary>   
        public void Remove(string hubKey, string appKey, string lbKey, string username)
        {
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (string.IsNullOrEmpty(lbKey))
                throw new ArgumentNullException("lbKey");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            var entry = _repo.GetEntry(hubKey, appKey, lbKey, username);
            if (entry != null)
            {
                _repo.DeleteEntry(hubKey, appKey, lbKey, username);
                ResetCache(hubKey, appKey, lbKey);
            }
        }
        
        #region " Private Methods "
        private void ResetCache(string hubKey, string appKey, string lbKey)
        {
            var cacheKey = CreateCacheKey(hubKey, appKey, lbKey);
            _cacheSvc.Remove(cacheKey);
        }

        private List<LeaderboardEntry> GetEntriesFromCache(string hubKey, string appKey, string lbKey)
        {
            var cacheKey = CreateCacheKey(hubKey, appKey, lbKey);
            var entries = _cacheSvc.Get<List<LeaderboardEntry>>(cacheKey);
            if (entries == null)
            {
                entries = _repo.GetEntries(hubKey, appKey, lbKey);
                _cacheSvc.Set(cacheKey, entries);
            }

            return entries;
        }

        #endregion
    }
}
