﻿using System;
using System.Collections.Generic;
using FPIQ.Core.Repos;
using FPIQ.Entities.Models;
using FPIQ.Entities;

namespace FPIQ.Core.Services
{
    public interface ISettingsService
    {
        void Upsert(Setting data, string username);
        void UpdateValue(string username, string settingKey, string settingValue = "", string settingType = "", string hubKey = "", string parentKey = "");
        void Delete(int id);
        void Delete(string settingKey, string hubKey = "");
        Setting GetSetting(int id);
        Setting GetSetting(string settingKey, string hubKey = "");
        string GetSettingValue(string settingKey, string hubKey = "");
        List<Setting> GetSettings(string keywords = "", string hubKey = "", string settingType = "");
    }

    public class SettingsService : ISettingsService
    {
        private ISettingsRepo _repo;
        
        #region " Constructors "

        public SettingsService()
        {
            _repo = FPIQContainer.Current.GetInstance<ISettingsRepo>();
        }

        // Testable constructor
        public SettingsService(ISettingsRepo repo)
        {
            _repo = repo;
        }

        #endregion

        #region " Interface Implementation "

        public void Upsert(Setting setting, string username)
        {
            if (setting == null)
                throw new ArgumentNullException("setting");            
            if (string.IsNullOrEmpty(setting.SettingKey))
                throw new ArgumentNullException("setting.settingKey");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            setting.LastModified = DateTime.UtcNow;
            setting.LastModifiedBy = username;
            if (string.IsNullOrEmpty(setting.SettingType))
                setting.SettingType = Constants.SettingTypes.System;
            var _setting = setting.Id > 0 ? _repo.GetSetting(setting.Id) : _repo.GetSetting(setting.SettingKey, setting.HubKey, setting.SettingType);
            if (_setting == null)
            {
                setting.Id = 0;
                setting.CreatedBy = username;
                setting.DateCreated = DateTime.UtcNow;
                setting.HubKey = GetDefaultHubKey(setting.HubKey);                

                _repo.Add(setting);
            }
            else
            {
                setting.Id = _setting.Id;                
                _repo.Update(setting);
            }
        }

        /// <summary>
        /// Updates setting's value
        /// </summary>        
        public void UpdateValue(string username, string settingKey, string settingType = "", string settingValue = "", string hubKey = "", string parentKey = "")
        {
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            ValidateSettingKey(settingKey);

            if (string.IsNullOrEmpty(settingType))
                settingType = Constants.SettingTypes.System;

            hubKey = GetDefaultHubKey(hubKey);
            var setting = _repo.GetSetting(settingKey, hubKey, settingType, parentKey);
            if (setting == null)
                throw new ApplicationException(string.Format("Setting not found: {0}", settingKey));

            setting.SettingValue = settingValue;
            _repo.Update(setting);            
        }

        /// <summary>
        /// Delete setting for a given setting id
        /// </summary>   
        public void Delete(int settingId)
        {                        
            if (settingId > 0)
            {                
                _repo.Delete(settingId);             
            }
        }

        /// <summary>
        /// Delete setting for a given setting key and hub key
        /// </summary>   
        public void Delete(string settingKey, string hubKey = "")
        {
            hubKey = GetDefaultHubKey(hubKey);
            var setting = _repo.GetSetting(settingKey, hubKey);
            if (setting != null)
            {                
                _repo.Delete(setting.Id);                
            }
        }

        /// <summary>
        /// Returns Setting object for a given setting id
        /// </summary>   
        public Setting GetSetting(int settingId)
        {
            if (settingId <= 0)
                throw new ArgumentOutOfRangeException("settingId");

            return _repo.GetSetting(settingId);
        }

        /// <summary>
        /// Returns Setting object for a given setting key and hub key
        /// </summary> 
        public Setting GetSetting(string settingKey, string hubKey = "")
        {
            if (string.IsNullOrEmpty(settingKey))
                throw new ArgumentNullException("settingKey");

            hubKey = GetDefaultHubKey(hubKey);
            return _repo.GetSetting(settingKey, hubKey);
        }

        /// <summary>
        /// Returns setting value for a given setting key and hub key
        /// </summary> 
        public string GetSettingValue(string settingKey, string hubKey = "")
        {
            ValidateSettingKey(settingKey);
            hubKey = GetDefaultHubKey(hubKey);
            var setting = _repo.GetSetting(settingKey, hubKey);
            return setting == null ? string.Empty : setting.SettingValue;
        }

        /// <summary>
        /// Returns list of Setting objects given keyword and/or hub key and/or setting type
        /// </summary> 
        public List<Setting> GetSettings(string keyword = "", string hubKey = "", string settingType = "")
        {            
            
            return _repo.GetSettings(hubKey, keyword, settingType);
        }

        #endregion

        #region " Private Methods "
        private void ValidateSettingKey(string settingKey)
        {
            if (string.IsNullOrEmpty(settingKey))
                throw new ArgumentNullException("settingKey");
        }

        private string GetDefaultHubKey(string hubKey)
        {
            return string.IsNullOrEmpty(hubKey) ? Constants.SettingTypes.System : hubKey;
        }

        #endregion


    }
}
