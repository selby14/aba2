﻿using FPIQ.Core.Extensions;
using FPIQ.Core.Repos;
using FPIQ.Entities.Models;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FPIQ.Core.Services
{
    public interface IBadgesService
    {
        void Award(string hubKey, string appKey, string badgeKey, string username, string level, Guid sessionId = default(Guid), string data = "");
        void RemoveBadge(string hubKey, string appKey, string badgeKey, string username, Guid sessionId = default(Guid));
        List<BadgeEntry> GetBadges(string hubKey, string appKey, string username, Guid sessionId = default(Guid));
        bool HasBadge(string hubKey, string appKey, string badgeKey, string username, Guid sessionId = default(Guid));
    }

    /// <summary>
    /// DNNLeaderboardService    
    /// </summary>
    public class BadgesService : IBadgesService
    {
        private readonly IBadgesRepo _repo;
        private readonly IAppConfigService _appConfigSvc;

        #region " Constructors "
        /// <summary>
        /// Default constructor
        /// </summary>
        public BadgesService()
        {
            _repo = FPIQContainer.Current.GetInstance<IBadgesRepo>();
            _appConfigSvc = FPIQContainer.Current.GetInstance<IAppConfigService>();
        }

        /// <summary>
        /// Testable constructor
        /// </summary>
        public BadgesService(IBadgesRepo repo, IAppConfigService appConfigSvc)
        {
            _repo = repo;
            _appConfigSvc = appConfigSvc;
        }

        #endregion

        /// <summary>
        /// Add badge entry
        /// </summary>   
        public void Award(string hubKey, string appKey, string badgeKey, string username, string level, Guid sessionId = default(Guid), string data = "")
        {
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (string.IsNullOrEmpty(badgeKey))
                throw new ArgumentNullException("badgeKey");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");
            if (string.IsNullOrEmpty(level))
                throw new ArgumentNullException("level");

            var app = _appConfigSvc.GetApp(appKey, hubKey);
            if (app == null)
                throw new ApplicationException($"App not found: '{appKey}'");
            if (app.Gamification == null || app.Gamification.Badges == null || app.Gamification.Badges.Count == 0)
                throw new ApplicationException($"Badge '{badgeKey}' not found for app '{appKey}'");
            var badge = app.Gamification.Badges.FirstOrDefault(b => b.BadgeKey.EqualsIgnoreCase(badgeKey));
            if (badge == null)
                throw new ApplicationException($"Badge '{badgeKey}' not found for app '{appKey}'");

            var entry = _repo.GetEntry(hubKey, appKey, badgeKey, username, sessionId);
            if (entry != null)
            {
                entry.Title = badge.Title;
                entry.Description = badge.Description;
                entry.IconUrl = badge.IconUrl;
                entry.Level = level;
                entry.Data = data;
                entry.LastModified = DateTime.UtcNow;
                _repo.UpdateEntry(entry);
            }
            else
            {
                entry = new BadgeEntry
                {
                    HubKey = hubKey,
                    AppKey = appKey,
                    BadgeKey = badgeKey,
                    Username = username,
                    Title = badge.Title,
                    Description = badge.Description,
                    IconUrl = badge.IconUrl,
                    Level = level,
                    SessionId = sessionId,
                    Data = data                    
                };
                _repo.AddEntry(entry);
            }
        }

        /// <summary>
        /// Get badge entries
        /// </summary>        
        public List<BadgeEntry> GetBadges(string hubKey, string appKey, string username, Guid sessionId = default(Guid))
        {
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            return _repo.GetEntries(hubKey, appKey, string.Empty, username, sessionId);
        }

        /// <summary>
        /// Remove badge entry
        /// </summary>   
        public void RemoveBadge(string hubKey, string appKey, string badgeKey, string username, Guid sessionId = default(Guid))
        {
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (string.IsNullOrEmpty(badgeKey))
                throw new ArgumentNullException("badgeKey");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");
            
            var entry = _repo.GetEntry(hubKey, appKey, badgeKey,username, sessionId);
            if (entry != null)
            {
                _repo.DeleteEntry(hubKey, appKey, badgeKey, username, sessionId);                
            }
        }

        /// <summary>
        /// Checks if user has badge
        /// </summary>   
        public bool HasBadge(string hubKey, string appKey, string badgeKey, string username, Guid sessionId = default(Guid))
        {
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (string.IsNullOrEmpty(badgeKey))
                throw new ArgumentNullException("badgeKey");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            var entry = _repo.GetEntry(hubKey, appKey, badgeKey, username, sessionId);
            return entry != null;
        }

        #region " Private Methods "

        #endregion
    }
}
