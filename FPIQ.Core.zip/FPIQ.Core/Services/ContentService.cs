﻿using System;
using System.Collections.Generic;
using FPIQ.Entities.Models;
using FPIQ.Core.Repos;

namespace FPIQ.Core.Services
{
    public interface IContentService
    {
        void Upsert(Content data, string username);
        void Delete(long id);
        void IncrementViewCount(long id);
        Content GetContent(long id);
        Content GetContent(string contentKey, string groupKey);
        T GetContent<T>(long id);
        T GetContent<T>(string contentKey, string groupKey);
        List<T> GetContents<T>(string groupKey, string contentType = "", string keywords = "");
        List<T> GetContents<T>(int portalId = -1, string contentType = "", string keywords = "", string tags = "");
        List<T> GetContents<T>(List<long> contentIds);
        List<string> GetGroupKeys();
        List<Content> GetContents(string groupKey, string contentType = "", string keywords = "");
        List<Content> GetContents(int portalId = -1, string contentType = "", string keywords = "", string tags = "");
    }

    public class ContentService : IContentService
    {
        private IContentRepo  _repo;

        #region " Constructors "
        public ContentService()
        {
            _repo = FPIQContainer.Current.GetInstance<IContentRepo>();
        }

        // Testable constructor
        public ContentService(IContentRepo repo)
        {
            _repo = repo;
        }
        #endregion     

        public void Delete(long id)
        {
            if (id > 0)
            {
                _repo.Delete(id);
            }
        }

        public Content GetContent(long id)
        {
            if (id <= 0)
                throw new ArgumentOutOfRangeException("id");
            return _repo.GetContent(id);
        }

        public Content GetContent(string contentKey, string groupKey)
        {
            if (string.IsNullOrEmpty(contentKey))
                throw new ArgumentNullException("contentKey");
            if (string.IsNullOrEmpty(groupKey))
                throw new ArgumentNullException("groupKey");

            return _repo.GetContent(contentKey, groupKey);
        }

        public T GetContent<T>(long id)
        {
            if (id <= 0)
                throw new ArgumentOutOfRangeException("id");

            return _repo.GetContent<T>(id);
        }

        public T GetContent<T>(string contentKey, string groupKey)
        {
            if (string.IsNullOrEmpty(contentKey))
                throw new ArgumentNullException("contentKey");
            if (string.IsNullOrEmpty(groupKey))
                throw new ArgumentNullException("groupKey");

            return _repo.GetContent<T>(contentKey, groupKey);
        }
      
        public List<T> GetContents<T>(string groupKey, string contentType = "", string keywords = "")
        {
            if (string.IsNullOrEmpty(groupKey))
                throw new ArgumentNullException("groupKey");

            return _repo.GetContents<T>(groupKey, contentType, keywords);
        }

        public List<T> GetContents<T>(int portalId = -1, string contentType = "", string keywords = "", string tags = "")
        {
            return _repo.GetContents<T>(portalId, contentType, keywords, tags);
        }       

        public List<T> GetContents<T>(List<long> contentIds)
        {
            if (contentIds == null || contentIds.Count == 0)
                throw new ArgumentNullException("contentIds");

            return _repo.GetContents<T>(contentIds);
        }

        public List<string> GetGroupKeys()
        {
            return _repo.GetGroupKeys();
        }

        public List<Content> GetContents(string groupKey, string contentType = "", string keywords = "")
        {
            if (string.IsNullOrEmpty(groupKey))
                throw new ArgumentNullException("groupKey");

            return _repo.GetContents<Content>(groupKey, contentType, keywords);
        }

        public List<Content> GetContents(int portalId = -1, string contentType = "", string keywords = "", string tags = "")
        {
            return _repo.GetContents(portalId, contentType, keywords, tags);
        }

        public void IncrementViewCount(long id)
        {
            if (id <= 0 )
                throw new ArgumentOutOfRangeException("id");

            _repo.IncrementViewCount(id);
        }

        public void Upsert(Content content, string username)
        {
            if (content == null)
                throw new ArgumentNullException("content");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            content.LastModifiedBy = username;
            content.LastModified = DateTime.UtcNow;
            if (content.ContentId <= 0)
            {
                content.DateCreated = DateTime.Now;
                content.CreatedBy = username;
                _repo.Add(content);
            }
            else
            {
                _repo.Update(content);
            }
        }
    }
}
