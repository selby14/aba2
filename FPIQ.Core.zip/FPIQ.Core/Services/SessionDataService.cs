﻿using System;
using System.Collections.Generic;
using FPIQ.Entities.Models;
using FPIQ.Core.Repos;
using FPIQ.Core.Extensions;

namespace FPIQ.Core.Services
{
    public interface ISessionDataService
    {
        void SetData(string currentUsername, SessionDataItem data, bool overwriteAllChildren = false, bool createParentIfNotFound = false);
        void SetDataItems(string currentUsername, List<SessionDataItem> dataItems, bool overwriteAllChildren = false, bool createParentIfNotFound = false);
        void SetValue(Guid sessionId, string key, string value = "", string username = "");
        SessionDataItem GetData(Guid sessionId, string key, string username = "", bool includeChildren = false);
        T GetData<T>(Guid sessionId, string key, string username = "");
        List<SessionDataItem> GetDataItems(Guid sessionId, List<string> keys = null, string username = "", bool includeChildren = false);
        List<SessionDataItem> GetDataItems(Guid sessionId, string sessionDataType, string username = "");        
        List<T> GetDataItems<T>(Guid sessionId, string sessionDataType, string username = "");
        string GetValue(Guid sessionId, string key, string username = "");
        void Delete(Guid sessionId, string key, string username = "", bool deleteChildren = false);
        void DeleteChildren(Guid sessionId, string parentKey, string username = "");
        List<SessionDataItem> GetChildren(Guid sessionId, string parentKey, string username = "");
        List<SessionDataItem> FindData(FindSessionDataRequest request);
    }

    public class SessionDataService : ISessionDataService
    {
        private readonly ISessionDataRepo _repo;
        private readonly ISerializationService _serializer;

        #region " Constructors "
        public SessionDataService()
        {            
            _repo = FPIQContainer.Current.GetInstance<ISessionDataRepo>();
            _serializer = FPIQContainer.Current.GetInstance<ISerializationService>();

        }

        // Testable constructor
        public SessionDataService(ISessionDataRepo repo, ISerializationService serializer)
        {
            _repo = repo;
            _serializer = serializer;
        }

        #endregion

        /// <summary>
        /// Saves a data item for this session. 
        /// </summary>        
        public void SetData(string currentUsername, SessionDataItem sessionData, bool overwriteAllChildren = false, bool createParentIfNotFound = false)
        {
            if (string.IsNullOrEmpty(currentUsername))
                throw new ArgumentNullException("currentUsername");
            if (sessionData == null)
                throw new ArgumentNullException("sessionData");
            if (sessionData.SessionId.IsNullOrEmpty())
                throw new ArgumentNullException("sessionData.sessionId");
            if (string.IsNullOrEmpty(sessionData.Key))
                throw new ArgumentNullException("sessionData.key");

            sessionData.Key = sessionData.Key.Trim();
            sessionData.ParentKey = string.IsNullOrEmpty(sessionData.ParentKey) ? sessionData.ParentKey : sessionData.ParentKey.Trim();
            sessionData.LastModifiedBy = currentUsername;
            sessionData.LastModified = DateTime.UtcNow;
            
            // Create parent if needed
            CreateParentIfNeeded(currentUsername, sessionData, createParentIfNotFound);

            // Save session data
            var id = _repo.GetDataId(sessionData.SessionId, sessionData.Key, sessionData.Username);
            if (id > 0)       
            {
                // UPDATE mode
                sessionData.Id = id;                
                _repo.Update(sessionData);
            }
            else
            {
                // ADD mode
                sessionData.Id = 0;
                sessionData.CreatedBy = currentUsername;
                sessionData.DateCreated = DateTime.UtcNow;
                _repo.Add(sessionData);
            }

            var dataKey = sessionData.Key;
            // Delete children if requested
            if (overwriteAllChildren)
            {
                DeleteChildren(sessionData.SessionId, dataKey, sessionData.Username);
            }

            // Save children if provided
            if (sessionData.Children != null && sessionData.Children.Count > 0)
            {
                sessionData.Children.ForEach(child =>
                {
                    // Ignore children without Key
                    if (!string.IsNullOrEmpty(child.Key))
                    {
                        child.ParentKey = dataKey;
                        child.SessionId = sessionData.SessionId;
                        child.Username = sessionData.Username;
                        SetData(currentUsername, child);
                    }
                });
            }
        }

        /// <summary>
        /// Saves the given data items
        /// </summary>   
        public void SetDataItems(string currentUsername, List<SessionDataItem> dataItems, bool overwriteAllChildren = false, bool createParentIfNotFound = false)
        {
            if (dataItems == null || dataItems.Count == 0)
                throw new ArgumentNullException("sessionDataItems");

            // Save each session data
            foreach (var sessionData in dataItems)
            {
                // Ignore session data without sessionId or key
                if (sessionData.SessionId.IsNullOrEmpty() || string.IsNullOrEmpty(sessionData.Key))
                {
                    continue;
                }

                SetData(currentUsername, sessionData, overwriteAllChildren, createParentIfNotFound);            
            }
        }

        /// <summary>
        /// Saves a data item value for this session. 
        /// </summary>        
        public void SetValue(Guid sessionId, string key, string value = "", string username = "")
        {
            ValidateSessionIdAndKey(sessionId, key);

            var dataId = _repo.GetDataId(sessionId, key, username);
            if (dataId == 0)
                throw new ApplicationException($"Session data not found: {sessionId} {key} {username}");
            
            _repo.UpdateValue(dataId, value);
        }

        /// <summary>
        /// Finds a list of SessionDataItem that matches the provided criteria. 
        /// </summary>
        /// <param name="sessionId"></param>
        /// <param name="request"></param>
        /// <returns></returns>
        public List<SessionDataItem> FindData(FindSessionDataRequest request)
        {          
            if (request == null)
                throw new ArgumentNullException("request");
            if (request.SessionId.IsNullOrEmpty())
                throw new ArgumentNullException("request.sessionId");

            return _repo.FindData(request);
        }

        /// <summary>
        /// Retrieves a SessionDataItem of the given key. 
        /// </summary>        
        public SessionDataItem GetData(Guid sessionId, string key, string username = "", bool includeChildren = false)
        {
            ValidateSessionIdAndKey(sessionId, key);

            key = key.Trim();
            username = string.IsNullOrEmpty(username) ? username : username.Trim();
            var data = _repo.GetData(sessionId, key, username);
            if (data != null && includeChildren)
                data.Children = GetChildren(sessionId, key, username);

            return data;
        }

        /// <summary>
        /// Retrieves a generic type object of the given key. 
        /// </summary>        
        public T GetData<T>(Guid sessionId, string key, string username = "") 
        {
            ValidateSessionIdAndKey(sessionId, key);

            key = key.Trim();
            username = string.IsNullOrEmpty(username) ? username : username.Trim();
            var data = _repo.GetData(sessionId, key, username);            
            try
            {
                return _serializer.JsonDeserialize<T>(data.Value);
            }
            catch
            {
                // swallow deserialization error and return null;
                return default(T);
            }
        }

        /// <summary>
        /// Retrieves a list of SessionDataItem of the given keys. 
        /// </summary>        
        public List<SessionDataItem> GetDataItems(Guid sessionId, List<string> keys = null, string username = "", bool includeChildren = false)
        { 
            if (sessionId.IsNullOrEmpty())
                throw new ArgumentNullException("sessionId");

            return _repo.GetDataItems(sessionId, keys, username, includeChildren);            
        }

        /// <summary>
        /// Retrieves a list of SessionDataItem of the given sessionId and data type. 
        /// </summary>        
        public List<SessionDataItem> GetDataItems(Guid sessionId, string sessionDataType, string username = "")
        {
            if (sessionId.IsNullOrEmpty())
                throw new ArgumentNullException("sessionId");
            if (string.IsNullOrEmpty(sessionDataType))
                throw new ArgumentNullException("sessionDataType");
            
            username = string.IsNullOrEmpty(username) ? username : username.Trim();
            return _repo.GetDataItemsByType(sessionId, sessionDataType, username);                        
        }

        /// <summary>
        /// Retrieves a list of generic data objects of the given keys. 
        /// </summary>        
        public List<T> GetDataItems<T>(Guid sessionId, string sessionDataType, string username = "")
        {
            if (sessionId.IsNullOrEmpty())
                throw new ArgumentNullException("sessionId");

            var list = new List<T>();
            username = string.IsNullOrEmpty(username) ? username : username.Trim();
            var items = _repo.GetDataItemsByType(sessionId, sessionDataType, username);
            foreach (var data in items)
            {
                T item = default(T);
                try
                {
                    item = _serializer.JsonDeserialize<T>(data.Value);
                    list.Add(item);
                }
                catch
                {
                    // swallow deserialization error
                }
            }

            return list;
        }
        

        /// <summary>
        /// Retrieves a SessionDataItem value of the given key. 
        /// </summary>        
        public string GetValue(Guid sessionId, string key, string username = "")
        {
            ValidateSessionIdAndKey(sessionId, key);

            var data = _repo.GetData(sessionId, key, username);
            return data?.Value;
        }

        /// <summary>
        /// Deletes a session data entry for the provided key.
        /// </summary>        
        public void Delete(Guid sessionId, string key, string username = "", bool deleteChildren = false)
        {
            ValidateSessionIdAndKey(sessionId, key);

            _repo.Delete(sessionId, key, username, deleteChildren);            
        }

        /// <summary>
        /// Deletes all children of a session data entry.
        /// </summary>        
        public void DeleteChildren(Guid sessionId, string parentKey, string username = "")
        {
            ValidateSessionIdAndKey(sessionId, parentKey);

            _repo.DeleteChildren(sessionId, parentKey, username);
        }

        /// <summary>
        /// Retrieves a list of SessionDataItem entries whose parent key matches the provided parent key.
        /// </summary>        
        public List<SessionDataItem> GetChildren(Guid sessionId, string parentKey, string username = "")
        {
            ValidateSessionId(sessionId);
            if (string.IsNullOrEmpty(parentKey))
                throw new ArgumentNullException("parentKey");

            return _repo.GetChildren(sessionId, parentKey, username);
        }

        #region " Private Methods "

        private void ValidateSessionId(Guid sessionId)
        {
            if (sessionId.IsNullOrEmpty())
                throw new ArgumentNullException("sessionId");            
        }

        private void ValidateSessionIdAndKey(Guid sessionId, string key)
        {
            if (sessionId.IsNullOrEmpty())
                throw new ArgumentNullException("sessionId");
            if (string.IsNullOrEmpty(key))
                throw new ArgumentNullException("key");
        }
        
        private void CreateParentIfNeeded(string currentUsername, SessionDataItem sdata, bool createParentIfNotFound)
        {
            // If parentKey is provided, create parent if requested and not found
            var hasParentKey = !string.IsNullOrEmpty(sdata.ParentKey);
            var parent = hasParentKey ? GetData(sdata.SessionId, sdata.ParentKey.Trim(), sdata.Username) : null;
            if (createParentIfNotFound && hasParentKey && parent == null)
            {
                parent = new SessionDataItem
                {
                    SessionId = sdata.SessionId,
                    Key = sdata.ParentKey,
                    Username = sdata.Username
                };
                // Add parent sesion data
                SetData(currentUsername, parent);
            }
        }

        #endregion
    }
}
