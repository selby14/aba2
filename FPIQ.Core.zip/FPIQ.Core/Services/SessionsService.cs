﻿using System;
using System.Collections.Generic;
using System.Linq;
using FPIQ.Entities.Models;
using FPIQ.Core.Repos;
using FPIQ.Core.Extensions;
using FPIQ.Entities;

namespace FPIQ.Core.Services
{
    public interface ISessionsService
    {
        SessionInfo JoinOrCreate(string username, string appKey, string hubKey, string sessionType, string caKey = "");
        SessionInfo CreateSession(string username, string appKey, string hubKey, string sessionType, DateTime startTime = default(DateTime), DateTime endTime = default(DateTime), int maxUsers = 0, Guid relatedSessionId = default(Guid), string caKey = "");
        void UpdateSessionTime(string currentOwnerName, Guid sessionId, DateTime startTime, DateTime endTime);
        void SessionCompleted(string username, Guid sessionId, bool completeForAllUsers = true);
        void UpdateSessionStatus(string username, Guid sessionId, string newStatus);
        void ReAssignSessionOwner(string currentOwnerName, Guid sessionId, string newOwnerName);
        SessionInfo JoinSession(string username, Guid sessionId, string shareCode = "", string password = "");
        void ExitSession(string username, Guid sessionId, bool completed = false, string performanceLevel = "");
        SessionInfo GetSession(Guid sessionId);
        List<SessionUser> GetSessionUsers(Guid sessionId);
        List<SessionInfo> FindSessions(FindSessionRequest request);
        SessionInfo ShareSession(string username, Guid sessionId, string shareType, bool requirePassword, string password = "", string shareCode = "", Dictionary<string, string> users = null, int maxUsers = 0);
        void AddUserToSession(string currentOwnerName, Guid sessionId, string username, string role = "");
        void BanUserFromSession(string currentOwnerName, Guid sessionId, string username);
        string GenerateShareCode(int length);

        #region " Session Stash "
        SessionStash CreateSessionStash(Guid sessionId, string username, string stashOwnerName);
        int AddSessionStash(SessionStash sessionStash);
        SessionStash GetSessionStash(int sessionStashId);
        List<SessionStash> GetSessionStashes(string ownerId, bool includeData = false);
        void DeleteSessionStash(int id);
        SessionInfo RestoreSessionStash(SessionStash sessionStash, string targetUsername);
        SessionInfo RestoreSessionStash(int stashId, string targetUsername);
        #endregion
    }

    public class SessionsService : ISessionsService
    {
        private readonly ISessionsRepo _repo;
        private readonly ISessionDataRepo _dataRepo;        
        private readonly ISessionLogsRepo _logRepo;
        private readonly IContentService _contentSvc;
        private readonly ICreditsService _creditSvc;
        private readonly IAppConfigService _appConfigSvc;
        private readonly ISerializationService _serializer;

        #region " Constructors "
        /// <summary>
        /// Default constructor
        /// </summary>
        public SessionsService()
        {
            
            _repo = FPIQContainer.Current.GetInstance<ISessionsRepo>();
            _dataRepo = FPIQContainer.Current.GetInstance<ISessionDataRepo>();            
            _logRepo = FPIQContainer.Current.GetInstance<ISessionLogsRepo>();
            _contentSvc = FPIQContainer.Current.GetInstance<IContentService>();
            _creditSvc = FPIQContainer.Current.GetInstance<ICreditsService>();
            _appConfigSvc = FPIQContainer.Current.GetInstance<IAppConfigService>();
            _serializer = FPIQContainer.Current.GetInstance<ISerializationService>();
        }
                
        /// <summary>
        /// Testable constructor 
        /// </summary>        
        public SessionsService(ISessionsRepo repo, ISessionLogsRepo logRepo)
        {
            _repo = repo;
            _logRepo = logRepo;            
        }

        /// <summary>
        /// Testable constructor 2
        /// </summary>        
        public SessionsService(ISessionsRepo repo, ISessionLogsRepo logRepo, ISessionDataRepo dataRepo)
        {
            _repo = repo;
            _logRepo = logRepo;
            _dataRepo = dataRepo;            
        }

        /// <summary>
        /// Testable constructor 3
        /// </summary>        
        public SessionsService(ISessionsRepo repo, ISessionLogsRepo logRepo, ISessionDataRepo dataRepo, IContentService contentSvc, ICreditsService creditsSvc, IAppConfigService appConfigService, ISerializationService serializer)
        {
            _repo = repo;
            _logRepo = logRepo;
            _dataRepo = dataRepo;
            _contentSvc = contentSvc;            
            _creditSvc = creditsSvc;
            _appConfigSvc = appConfigService;
            _serializer = serializer;
        }
        
        #endregion

        #region " Properties " 

        #endregion

        /// <summary>
        /// Adds a user to a session. It assumes that the Session has been shared. This marks the user status as Invited. Only the owner of a session would call this method
        /// </summary>
        /// <param name="sessionId"></param>
        /// <param name="username"></param>
        /// <param name="role"></param>        
        public void AddUserToSession(string currentOwnerName, Guid sessionId, string username, string role = "" )
        {
            if (string.IsNullOrEmpty(currentOwnerName))
                throw new ArgumentNullException("currentOwnerName");
            ValidateSessionId(sessionId);
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            var session = ValidateSession(sessionId);
            if (!session.OwnerName.EqualsIgnoreCase(currentOwnerName))
                throw new ApplicationException("Only the owner can add user to session.");

            var sessionUser = _repo.GetSessionUser(sessionId, username);
            // if user has record already, do nothing
            if (sessionUser != null) return;

            if (session.ShareType.EqualsIgnoreCase(Constants.SessionShareTypes.Restricted))                
                throw new ApplicationException($"Can not add user to session when share type is '{Constants.SessionShareTypes.Restricted}'");

            AddSessionUser(currentOwnerName, username, sessionId, Constants.SessionUserStatus.Invited, role);            
        }

        /// <summary>
        /// Bans a user from a session. 
        /// If when banning a user, the user is not in the SessionUsers, then simply add a record and set the status to Banned. 
        /// </summary>
        /// <param name="sessionId"></param>
        /// <param name="username"></param>
        public void BanUserFromSession(string currentOwnerName, Guid sessionId, string username)
        {
            if (string.IsNullOrEmpty(currentOwnerName))
                throw new ArgumentNullException("currentOwnerName");
            ValidateSessionId(sessionId);
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            var session = ValidateSession(sessionId);
            if (session.OwnerName == username)
                throw new ApplicationException($"User '{username}' is the session owner and can not be banned.");
            if (!session.OwnerName.EqualsIgnoreCase(currentOwnerName))
                throw new ApplicationException("Only the owner can ban user from session.");

            var sessionUser = _repo.GetSessionUser(sessionId, username);
            if (sessionUser == null)
            {                
                AddSessionUser(currentOwnerName, username, sessionId, Constants.SessionUserStatus.Banned);                
            }
            else
            {
                sessionUser.Status = Constants.SessionUserStatus.Banned;
                _repo.UpdateSessionUser(sessionUser);
            }            
        }

        public SessionInfo CreateSession(string username, string appKey, string hubKey, string sessionType, DateTime startTime = default(DateTime), DateTime endTime = default(DateTime), int maxUsers = 0, Guid relatedSessionId = default(Guid), string caKey = "")
        {            
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(sessionType))
                throw new ArgumentNullException("sessionType");

            var app = _contentSvc.GetContent<AppInfo>(appKey, hubKey);            

            // Create session
            var session = new SessionInfo
            {
                Id = Guid.NewGuid(),
                SessionType = sessionType,
                AppKey = appKey,
                HubKey = hubKey,
                OwnerName = username,
                Status = Constants.SessionStatus.Created,
                ShareType = Constants.SessionShareTypes.Restricted,
                MaxUsers = maxUsers,
                StartTime = startTime == default(DateTime) ? DateTime.UtcNow : startTime,
                EndTime = endTime,
                RelatedSessionId = relatedSessionId,
                CreatedBy = username,
                LastModifiedBy = username
            };      

            _repo.AddSession(session);

            // Add session user         
            AddSessionUser(username, username, session.Id, Constants.SessionUserStatus.Connected);

            // Add session user objectives
            AddSessionUserObjectives(username, username, session.Id, appKey, hubKey);

            // Add credit record
            AddCreditRecord(app, hubKey, appKey, session.Id, username, caKey);            

            return session;            
        }
                
        /// <summary>
        /// Marks the SessionUser record for this user as Disconnected or Completed.
        /// </summary>
        /// <param name="sessionId"></param>
        /// <param name="completed"></param>
        /// <param name="performanceLevel"></param>
        public void ExitSession(string username, Guid sessionId, bool completed = false, string performanceLevel = "")
        {
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            ValidateSession(sessionId);

            var sessionUser = _repo.GetSessionUser(sessionId, username);                
            if (sessionUser == null)
                throw new ApplicationException($"Session user not found: '{sessionId}:{username}'");

            sessionUser.Status = Constants.SessionUserStatus.Disconnected;
            if (completed)
            {
                sessionUser.Status = Constants.SessionUserStatus.Completed;
                sessionUser.DateCompleted = DateTime.UtcNow;
                if (!string.IsNullOrEmpty(performanceLevel))
                    sessionUser.PerformanceLevel = performanceLevel;
            }                            

            _repo.UpdateSessionUser(sessionUser);

            if (completed)
            {
                AddSessionLog(sessionId, username, Constants.SessionLogEvents.Completed);
                //RaiseEvent(Constants.Events.SessionEnd, sessionId, username);
            }
            else
            {
                AddSessionLog(sessionId, username, Constants.SessionLogEvents.Left);
                //RaiseEvent(Constants.Events.SessionLeft, sessionId, username);
            }
        }

        /// <summary>
        /// Finds a list of session that matches the provided criteria. Only sessions belonging to the same Client as the User.
        /// </summary>        
        /// <param name="request"></param>
        /// <returns></returns>
        public List<SessionInfo> FindSessions(FindSessionRequest request)
        {            
            if (request == null)
                throw new ArgumentNullException("request");
            if (string.IsNullOrEmpty(request.AppKey))
                throw new ArgumentNullException("request.appKey");
            if (string.IsNullOrEmpty(request.HubKey))
                throw new ArgumentNullException("request.hubKey");

            return _repo.FindSessions(request);
        }

        /// <summary>
        /// Generate share code
        /// </summary>       
        /// <param name="length">Share code length. Minimum of 8</param>
        public string GenerateShareCode(int length = 8)
        {
            return GenerateShareCodeRecursively(length);
        }

        /// <summary>
        /// Retrieves a SessionInfo object given the Session Id
        /// </summary>
        /// <param name="sessionId"></param>        
        public SessionInfo GetSession(Guid sessionId)
        {
            ValidateSessionId(sessionId);

            return _repo.GetSession(sessionId);
        }

        /// <summary>
        /// Retrieves a list of SessionUser objects given the Session Id
        /// </summary>
        /// <param name="sessionId"></param>
        public List<SessionUser> GetSessionUsers(Guid sessionId)
        {
            ValidateSessionId(sessionId);
            return _repo.GetSessionUsers(sessionId);
        }

        /// <summary>
        /// Join or create session.
        /// Given a particular appKey/hubKey combination, it will either join a previous session, or create a new one.
        /// </summary>        
        public SessionInfo JoinOrCreate(string username, string appKey, string hubKey, string sessionType, string caKey = "")
        {
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");
            if (string.IsNullOrEmpty(sessionType))
                throw new ArgumentNullException("sessionType");

            var app = _contentSvc.GetContent<AppInfo>(appKey, hubKey);
            var request = new FindSessionRequest { AppKey = appKey, HubKey = hubKey, SessionUsername = username, SessionStatus = Constants.SessionStatus.Created };            
            var sessions = _repo.FindSessions(request);
            if (sessions == null || sessions.Count == 0)
            {
                // Create session
                var session = new SessionInfo
                {
                    Id = Guid.NewGuid(),
                    SessionType = sessionType,
                    AppKey = appKey,
                    OwnerName = username,
                    Status = Constants.SessionStatus.Created,
                    ShareType = Constants.SessionShareTypes.Restricted,
                    StartTime = DateTime.UtcNow,
                    CreatedBy = username,
                    LastModifiedBy = username
                };
                
                _repo.AddSession(session);

                // Add user to session                
                AddSessionUser(username, username, session.Id, Constants.SessionUserStatus.Connected);
                // Add session user objectives
                AddSessionUserObjectives(username, username, session.Id, appKey, hubKey);
                // Add credit record
                AddCreditRecord(app, hubKey, appKey, session.Id, username, caKey);

                return session;
            }
            else
            {
                // Session found, select first item
                var session = sessions.FirstOrDefault();                                
                var sessionUser = _repo.GetSessionUser(session.Id, username);                
                if (sessionUser == null)
                {
                    // Add user to session
                    AddSessionUser(username, username, session.Id, Constants.SessionUserStatus.Connected);
                    // Add session user objectives
                    AddSessionUserObjectives(username, username, session.Id, appKey, hubKey);
                    // Add credit record
                    AddCreditRecord(app, hubKey, appKey, session.Id, username, caKey);
                }
                return session;
            }           
        }

        /// <summary>
        /// Joins a session.
        /// By default, sessions are not shared, and only the owner of a particular session can join it.
        /// Users can only join a session whose status is not marked as Completed, and if a Start and End time is specified, unless you are the Owner, 
        /// you would only be able to join if the current time falls within the Start and End time.
        /// </summary>        
        public SessionInfo JoinSession(string username, Guid sessionId, string shareCode = "" , string password = "")
        {
            if (sessionId.IsNullOrEmpty() && string.IsNullOrEmpty(shareCode))
                throw new ApplicationException("sessionId or shareCode must be provided");
                        
            var session = !sessionId.IsNullOrEmpty() ? _repo.GetSession(sessionId) : _repo.GetSession(shareCode);
            if (session == null)
                throw new ApplicationException("Session not found");

            // Make sure session status is NOT completed
            if (session.Status.EqualsIgnoreCase(Constants.SessionStatus.Completed))
                throw new ApplicationException($"Session '{sessionId}' is already completed");

            // If username is NOT the owner, check if already joined before
            if (!session.OwnerName.EqualsIgnoreCase(username))
            {
                var sessionUser = _repo.GetSessionUser(session.Id, username);
                if (sessionUser != null)
                {
                    // User previously joined, check if user is banned
                    if (sessionUser.Status.EqualsIgnoreCase(Constants.SessionUserStatus.Banned))
                        throw new ApplicationException("User is banned from joining this session");

                    // If session status is already "Completed", add session log with event "ReJoined"
                    if (sessionUser.Status.EqualsIgnoreCase(Constants.SessionUserStatus.Completed))
                    {
                        AddSessionLog(sessionId, username, Constants.SessionLogEvents.ReJoined);
                        ResetSessionUserObjectives(username, session);
                        //RaiseEvent(Constants.Events.SessionRejoin, sessionId, username);
                    }
                    // If status is "Invited", add session user objectives
                    else if (sessionUser.Status.EqualsIgnoreCase(Constants.SessionUserStatus.Invited))
                    {
                        AddSessionUserObjectives(username, username, session.Id, session.AppKey, session.HubKey);
                    }

                    // If previously "Completed", reset DateCompleted field
                    if (sessionUser.Status.EqualsIgnoreCase(Constants.SessionUserStatus.Completed))
                        sessionUser.DateCompleted = DateTime.MinValue;

                    // Change status to "Connected"
                    sessionUser.Status = Constants.SessionUserStatus.Connected;                  
                    _repo.UpdateSessionUser(sessionUser);
                }
                else
                {
                    // First time joining, check if session is shared
                    if (!session.ShareType.EqualsIgnoreCase(Constants.SessionShareTypes.AllUsers))
                        throw new ApplicationException("User is not allowed to join this session");

                    // Check password requirement             
                    if (!string.IsNullOrEmpty(session.Password) && !session.Password.Equals(password))
                        throw new ApplicationException("Invalid session password");
                    
                    // If passed all validations, add session user, session user objectives and session log                    
                    AddSessionUser(username, username, session.Id, Constants.SessionUserStatus.Connected);                    
                    AddSessionUserObjectives(username, username, session.Id, session.AppKey, session.HubKey);                    
                    AddSessionLog(sessionId, username, Constants.SessionLogEvents.Joined);
                    //RaiseEvent(Constants.Events.SessionStart, sessionId, username);
                }
            }
            else  // User IS the session owner
            {
                var sessionUser = _repo.GetSessionUser(session.Id, username);
                if (sessionUser == null)
                {
                    // Add session user                                        
                    AddSessionUser(username, username, session.Id, Constants.SessionUserStatus.Connected);
                    // Add session user objectives
                    AddSessionUserObjectives(username, username, session.Id, session.AppKey, session.HubKey);
                    // Add session log
                    AddSessionLog(sessionId, username, Constants.SessionLogEvents.Joined);
                    //RaiseEvent(Constants.Events.SessionStart, sessionId, username);
                }
                else
                {
                    // If previously completed, reset DateCompleted field
                    if (sessionUser.Status.EqualsIgnoreCase(Constants.SessionUserStatus.Completed))
                        sessionUser.DateCompleted = DateTime.MinValue;

                    // Change status to "Connected"
                    sessionUser.Status = Constants.SessionUserStatus.Connected;
               
                    _repo.UpdateSessionUser(sessionUser);
                    // Rest session user objectives
                    ResetSessionUserObjectives(username, session);
                    // Add session log
                    AddSessionLog(sessionId, username, Constants.SessionLogEvents.Joined);
                    //RaiseEvent(Constants.Events.SessionStart, sessionId, username);
                }
            }

            return session;
        }

        /// <summary>
        /// Re-Assigns a session's owner to the one provided. Can only be done by the current Owner.
        /// </summary>
        /// <param name="username"></param>
        /// <param name="sessionId"></param>
        /// <param name="newOwnerName"></param>
        public void ReAssignSessionOwner(string currentOwnerName, Guid sessionId, string newOwnerName)
        {
            if (string.IsNullOrEmpty(currentOwnerName))
                throw new ArgumentNullException("currentOwnerName");
            ValidateSessionId(sessionId);
            if (string.IsNullOrEmpty(newOwnerName))
                throw new ArgumentNullException("newOwnerName");

            var session = ValidateSession(sessionId);

            if (!session.OwnerName.EqualsIgnoreCase(currentOwnerName))
                throw new ApplicationException("Only the owner can re-assign session.");

            session.OwnerName = newOwnerName;
            _repo.UpdateSession(session);
        }

        /// <summary>
        /// Marks a session as completed. Only the owner can mark a session as completed.
        /// </summary>
        /// <param name="username"></param>
        /// <param name="sessionId"></param>
        public void SessionCompleted(string username, Guid sessionId, bool completeForAllUsers = true)
        {
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");                        
            var session = ValidateSession(sessionId);
            if (!session.OwnerName.EqualsIgnoreCase(username))
                throw new ApplicationException("Only the owner can mark this session as completed");

            session.Status = Constants.SessionStatus.Completed;
            session.EndTime = DateTime.UtcNow;  
            _repo.UpdateSession(session);

            // Update session user and log event
            var sessionUser = _repo.GetSessionUser(sessionId, username);
            if (sessionUser != null)
            {
                sessionUser.DateCompleted = DateTime.UtcNow;
                sessionUser.Status = Constants.SessionUserStatus.Completed;
                _repo.UpdateSessionUser(sessionUser);
                AddSessionLog(sessionId, username, Constants.SessionLogEvents.Completed);
                //RaiseEvent(Constants.Events.SessionEnd, sessionId, username);
            }            
                        
            // If requested, set all session users to "Completed" and log event for each session user
            if (completeForAllUsers)
            {
                var sessionUsers = _repo.GetSessionUsers(sessionId);
                if (sessionUsers != null && sessionUsers.Count > 0)
                {
                    foreach (var sUser in sessionUsers.Where(su => !su.Username.EqualsIgnoreCase(username)))
                    {
                        sUser.DateCompleted = DateTime.UtcNow;
                        sUser.Status = Constants.SessionUserStatus.Completed;
                        _repo.UpdateSessionUser(sUser);
                        AddSessionLog(sessionId, sUser.Username, Constants.SessionLogEvents.Completed);
                        //RaiseEvent(Constants.Events.SessionEnd, sessionId, sUser.Username);
                    }
                }
            }                      
        }
        
        /// <summary>
        /// Updates a sessions's status
        /// </summary>
        /// <param name="username">The user Id making the request</param>
        /// <param name="sessionId">The session Id</param>
        /// <param name="newStatus">The status the session will be placed in</param>
        public void UpdateSessionStatus(string username, Guid sessionId, string newStatus)
        {
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");
            if (string.IsNullOrEmpty(newStatus))
                throw new ArgumentNullException("newStatus");
            var session = ValidateSession(sessionId);

            if (newStatus != Constants.SessionStatus.Created &&
                newStatus != Constants.SessionStatus.InProgress &&
                newStatus != Constants.SessionStatus.Completed &&
                newStatus != Constants.SessionStatus.Corrupted &&
                newStatus != Constants.SessionStatus.Abandoned)
                throw new ApplicationException($"Invalid newStatus: '{newStatus}'");

            if (!session.OwnerName.EqualsIgnoreCase(username))
                throw new ApplicationException("Only the owner can change the status of this session");
                        
            session.Status = newStatus;
            session.LastModifiedBy = username;
            session.LastModified = DateTime.UtcNow;

            _repo.UpdateSession(session);
        }

        /// <summary>
        /// Shares a session.
        /// The session must have already been created. 
        /// Anybody that receives the Share Code and optionally the session password, would be able to join the session as long as the session is marked as AllUsers.
        /// </summary>        
        public SessionInfo ShareSession(string username, Guid sessionId, string shareType, bool requirePassword, string password = "", string shareCode = "", Dictionary<string, string> users = null, int maxUsers = 0)
        {
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            ValidateSessionId(sessionId);
            
            if (string.IsNullOrEmpty(shareType))
                throw new ArgumentNullException("shareType");
            if (requirePassword && string.IsNullOrEmpty(password))
                throw new ApplicationException("'password' must be provided if 'requirePassword' is true");
            if (shareType.EqualsIgnoreCase(Constants.SessionShareTypes.Restricted) && (users == null || users.Count == 0))
                throw new ApplicationException($"'users' must be provided if 'shareType' is '{Constants.SessionShareTypes.Restricted}'");

            var session = ValidateSession(sessionId);
            // Make sure shareCode is unique
            if (!string.IsNullOrEmpty(shareCode))
            {
                var _session = _repo.GetSession(shareCode);
                if (_session != null && _session.Id != session.Id)
                    throw new ApplicationException($"shareCode '{shareCode}' already exists.");
            }

            session.ShareType = shareType;
            session.MaxUsers = maxUsers;
            session.ShareCode = shareCode;            
            if (!string.IsNullOrEmpty(password))
                session.Password = password;           

            // Update session
            _repo.UpdateSession(session);
            
            // Add session users if provided
            if (users != null)
            {
                foreach (var user in users)
                {                    
                    var sessionUser = new SessionUser {
                        SessionId = session.Id,
                        Status = Constants.SessionUserStatus.Invited,
                        Username = user.Key,
                        RoleKey = user.Value,                        
                        CreatedBy = username,
                        LastModifiedBy = username
                    };
                    _repo.AddSessionUser(sessionUser);                    
                }                
            }

            return session;
        }

        /// <summary>
        /// Updates session time. Only the session owner can adjust the session start / end time.
        /// Start and End times are assumed to be in the default system time zone.
        /// </summary>        
        public void UpdateSessionTime(string username, Guid sessionId, DateTime startTime, DateTime endTime)
        {
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            var session = ValidateSession(sessionId);

            if (!session.OwnerName.EqualsIgnoreCase(username))
                throw new ApplicationException("Only the session owner can update the session time");

            session.StartTime = startTime;
            session.EndTime = endTime;

            _repo.UpdateSession(session);
        }


        #region " Session Stash "  
        /// <summary>
        /// Create session stash from the given session info.
        /// This methods does not adds session stash record to repo.
        /// </summary>        
        public SessionStash CreateSessionStash(Guid sessionId, string username, string stashOwnerName)
        {
            ValidateSessionId(sessionId);
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");
            if (string.IsNullOrEmpty(stashOwnerName))
                throw new ArgumentNullException("stashOwnerName");

            var sessionInfo = ValidateSession(sessionId);
            var sessionStash = new SessionStash { SourceSessionId = sessionId, OwnerName = stashOwnerName };
            var stashData = new SessionStashData();
            sessionStash.SourceOwnerName = sessionInfo.OwnerName;
            stashData.SessionInfo = sessionInfo;
            var sessionUsers = GetSessionUsers(sessionId);
            if (sessionUsers != null && sessionUsers.Count > 0)
            {
                stashData.SessionUser = sessionUsers.FirstOrDefault(su => su.Username.EqualsIgnoreCase(username));
                // Get all session data
                stashData.SessionData = _dataRepo.GetDataItems(sessionId, null);
            }
            sessionStash.Data = stashData;

            return sessionStash;
        }

        public int AddSessionStash(SessionStash sessionStash)
        {
            if (sessionStash == null)
                throw new ArgumentNullException("sessionStash");
            return _repo.AddSessionStash(sessionStash);
        }

        public SessionStash GetSessionStash(int stashId)
        {
            ValidateStashId(stashId);
            return _repo.GetSessionStash(stashId);
        }

        public List<SessionStash> GetSessionStashes(string ownerId, bool includeData = false)
        {
            if (string.IsNullOrEmpty(ownerId))
                throw new ArgumentNullException("ownerId");
            return _repo.GetSessionStashes(ownerId, includeData);
        }

        public void DeleteSessionStash(int stashId)
        {
            ValidateStashId(stashId);
            _repo.DeleteSessionStash(stashId);
        }

        public SessionInfo RestoreSessionStash(SessionStash sessionStash, string targetUsername)
        {
            if (sessionStash == null)
                throw new ArgumentNullException("sessionStash");
            if (sessionStash.Data == null)
                throw new ArgumentNullException("sessionStash.data");
            if (sessionStash.Data.SessionInfo == null)
                throw new ArgumentNullException("sessionStash.data.sessionInfo");

            var stash = sessionStash;
            var session = stash.Data.SessionInfo;
            var sessionId = Guid.NewGuid();
            session.Id = sessionId;
            session.OwnerName = targetUsername;
            session.Status = Constants.SessionStatus.Created;
            // Add session
            _repo.AddSession(session);
            // Add session user
            if (stash.Data.SessionUser != null)
            {
                var sessionUser = stash.Data.SessionUser;
                sessionUser.SessionId = sessionId;
                sessionUser.Username = targetUsername;
                sessionUser.Status = Constants.SessionUserStatus.Connected;
                sessionUser.DateCompleted = DateTime.MinValue;
                _repo.AddSessionUser(sessionUser);
            }
            // Add session data
            if (stash.Data.SessionData != null)
            {
                foreach (var data in stash.Data.SessionData)
                {
                    data.SessionId = sessionId;
                    _dataRepo.Add(data);
                }
            }
            return session;
        }

        public SessionInfo RestoreSessionStash(int stashId, string targetUsername)
        {
            ValidateStashId(stashId);
            var stash = _repo.GetSessionStash(stashId);
            return RestoreSessionStash(stash, targetUsername);
        }

        #endregion

        #region " Private Methods "       
        /// <summary>
        /// Helper method to validate session
        /// </summary>        
        private SessionInfo ValidateSession(Guid sessionId)
        {
            ValidateSessionId(sessionId);
            var session = _repo.GetSession(sessionId);
            if (session == null)
                throw new ApplicationException($"Session not found: '{sessionId}'");

            return session;
        }

        /// <summary>
        /// Helper method to validate session id
        /// </summary>        
        private void ValidateSessionId(Guid sessionId)
        {
            if (sessionId.IsNullOrEmpty())
                throw new ArgumentNullException("sessionId");
        }

        /// <summary>
        /// Helper method to validate session stash id
        /// </summary>
        /// <param name="stashId"></param>        
        private void ValidateStashId(int stashId)
        {
            if (stashId <= 0)
                throw new ArgumentOutOfRangeException("stashId");
        }

        /// <summary>
        /// Helper method to add session user
        /// </summary>  
        private void AddSessionUser(string currentUsername, string username, Guid sessionId, string status, string role = "")
        {            
            var sessionUser = new SessionUser
            {
                SessionId = sessionId,
                Status = status,
                RoleKey = role,
                Username = username,
                CreatedBy = currentUsername,
                LastModifiedBy = currentUsername
            };
            _repo.AddSessionUser(sessionUser);
        }

        /// <summary>
        /// Helper method to add session user objectives
        /// </summary>  
        private void AddSessionUserObjectives(string currentUsername, string sessionUsername, Guid sessionId, string appKey, string hubKey)
        {
            var appManifest = _appConfigSvc.GetApp(appKey, hubKey);
            if (appManifest == null || appManifest.App == null) return;

            if (appManifest.App.Objectives != null && appManifest.App.Objectives.Count > 0)
            {
                foreach (var objective in appManifest.App.Objectives)
                {
                    var sessionObjective = new SessionObjective {
                        ObjectiveKey = objective.ObjectiveKey,
                        Data = objective.MetaData,
                        Status = Constants.ObjectiveStatus.NotMet,
                        TryCount = 0                        
                    };
                    var data = new SessionDataItem
                    {
                        DataType = Constants.SessionDataTypes.Objective,
                        SessionId = sessionId,
                        Key = objective.ObjectiveKey,
                        Value = _serializer.JsonSerialize(sessionObjective),
                        Username = sessionUsername,
                        CreatedBy = currentUsername,
                        LastModifiedBy = currentUsername
                    };
                    _dataRepo.Add(data);
                }
            }
        }

        /// <summary>
        /// Helper method to reset session user objectives
        /// </summary>  
        private void ResetSessionUserObjectives(string currentUsername, SessionInfo session)
        {
            if (string.IsNullOrEmpty(currentUsername) || session == null) return;
                        
            var dataItems = _dataRepo.GetDataItemsByType(session.Id, Constants.SessionDataTypes.Objective, session.OwnerName);
            if (dataItems != null && dataItems.Count > 0)
            {
                foreach (var dataItem in dataItems)
                {
                    // Ignore invalid session user objective
                    if (string.IsNullOrEmpty(dataItem.Value)) continue;

                    SessionObjective sessionObjective = null;
                    try
                    {
                        sessionObjective = _serializer.JsonDeserialize<SessionObjective>(dataItem.Value);
                        sessionObjective.Status = Constants.ObjectiveStatus.NotMet;
                        sessionObjective.TryCount = 0;
                        sessionObjective.Performance = string.Empty;
                        sessionObjective.Duration = 0;                        
                    }
                    catch
                    {
                        // swallow deserialization error which means invalid session user objective
                    }

                    if (sessionObjective != null)
                    {
                        dataItem.Value = _serializer.JsonSerialize(sessionObjective);
                        dataItem.LastModified = DateTime.UtcNow;
                        dataItem.LastModifiedBy = currentUsername;
                        _dataRepo.Update(dataItem);
                    }
                }
            }
        }


        /// <summary>
        /// Helper method to add session log
        /// </summary>        
        private void AddSessionLog(Guid sessionId, string username, string logEvent)
        {
            if (sessionId.IsNullOrEmpty() || string.IsNullOrEmpty(username) || string.IsNullOrEmpty(logEvent)) return;

            var log = new SessionLog { Event = logEvent, SessionId = sessionId, Username = username };
            _logRepo.Add(log);
        }

        /// <summary>
        /// Helper method to add credit record
        /// </summary>        
        private void AddCreditRecord(AppInfo app, string hubKey, string appKey, Guid sessionId, string username, string caKey)
        {
            // Add credit record if applicable
            if (app != null && app.HasCredit && app.CreditConfigId > 0)
            {
                _creditSvc.Add(hubKey, appKey, sessionId, username, app.CreditConfigId, caKey);
            }
        }

        /// <summary>
        /// Generate unique share code 
        /// </summary>        
        private string GenerateShareCodeRecursively(int length)
        {
            if (length < 8)
                length = 8;
            var shareCode = RandomTool.GenerateRandomNumber(length);
            var session = _repo.GetSession(shareCode);
            if (session == null)
                return shareCode;
            else
                return GenerateShareCodeRecursively(length);
        }
        #endregion
    }
}
