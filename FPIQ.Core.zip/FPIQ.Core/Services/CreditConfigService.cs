﻿using System;
using System.Net.Http;
using FPIQ.Entities.Models;
using FPIQ.Core.Repos;
using System.Collections.Generic;

namespace FPIQ.Core.Services
{
    public interface ICreditConfigService
    {
        void Upsert(CreditConfigDbItem data, string username);
        CreditConfigDbItem GetCreditConfigDbItem(int id);
        CreditConfigDbItem GetCreditConfigDbItem(string title);
        CreditConfig GetCreditConfig(int id);
        List<CreditConfigDbItem> GetCreditConfigDbItems(string keywords = "");
        void Delete(int id);
    }

    public class CreditConfigService : ICreditConfigService
    {        
        private readonly ISerializationService _serializer;
        private readonly ICreditConfigRepo _repo;

        #region " Constructors "
        public CreditConfigService()
        {
            _repo = FPIQContainer.Current.GetInstance<ICreditConfigRepo>();            
            _serializer = FPIQContainer.Current.GetInstance<ISerializationService>();
        }

        // Testable constructors
        public CreditConfigService(ICreditConfigRepo repo, ISerializationService serializer)
        {
            _repo = repo;
            _serializer = serializer;
        }

        #endregion

        /// <summary>
        /// Adds / updates credit config db item
        /// </summary>        
        public void Upsert(CreditConfigDbItem item, string username)
        {            
            if (item == null)
                throw new ArgumentNullException("item");
            if (string.IsNullOrEmpty(item.ConfigJson))
                throw new ArgumentNullException("item.configJson");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            item.LastModified = DateTime.UtcNow;
            item.LastModifiedBy = username;
            if (item.Id == 0)
            {
                item.CreatedBy = username;
                item.DateCreated = DateTime.UtcNow;
                _repo.Add(item);
            }
            else
            {
                _repo.Update(item);
            }
        }

        /// <summary>
        /// Gets credit config db item by id
        /// </summary>        
        public CreditConfigDbItem GetCreditConfigDbItem(int id)
        {
            if (id <= 0)
                throw new ArgumentOutOfRangeException("id");

            return _repo.Get(id);
        }


        /// <summary>
        /// Gets credit config db item by title
        /// </summary>        
        public CreditConfigDbItem GetCreditConfigDbItem(string title)
        {
            if (string.IsNullOrEmpty(title))
                throw new ArgumentNullException("title");

            return _repo.Get(title);
        }

        /// <summary>
        /// Gets credit config object
        /// </summary>        
        public CreditConfig GetCreditConfig(int id)
        {
            if (id <= 0)
                throw new ArgumentOutOfRangeException("id");

            var dbItem = _repo.Get(id);
            try
            {
                return _serializer.JsonDeserialize<CreditConfig>(dbItem.ConfigJson);
            }
            catch
            {
                return null;
            }
        }

        // <summary>
        /// Gets list of GetCreditConfigDbItem objects
        /// </summary>        
        public List<CreditConfigDbItem> GetCreditConfigDbItems(string keywords = "")
        {
            return _repo.Search(keywords);            
        }

        /// <summary>
        /// Deletes credit config item
        /// </summary>        
        public void Delete(int id)
        {
            if (id <= 0 )
                throw new ArgumentOutOfRangeException("id");            
            _repo.Delete(id);            
        }

        #region " Private Methods "       

        private void ValidateAppAndHubKey(string appKey, string hubKey)
        {
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
        }

        private AppManifest GetAppManifest(string appConfigUrl)
        {
            if (string.IsNullOrEmpty(appConfigUrl)) return null;

            var httpClient = new HttpClient();
            var url = appConfigUrl;
            var response = httpClient.GetAsync(url).Result;
            var jsonResult = response.Content.ReadAsStringAsync().Result;
            AppManifest app = null;
            try
            {
                if (!string.IsNullOrEmpty(jsonResult))
                    app = _serializer.JsonDeserialize<AppManifest>(jsonResult);

                return app;
            }
            catch
            {
                //swallow deserialization error
                return app;
            }
        }

        #endregion
    }
}
