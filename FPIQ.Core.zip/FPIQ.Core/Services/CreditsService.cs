﻿using System;
using System.Collections.Generic;
using System.Linq;
using FPIQ.Core.Extensions;
using FPIQ.Core.Repos;
using FPIQ.Entities.Models;

namespace FPIQ.Core.Services
{
    public interface ICreditsService
    {
        // Credits
        Credit GetCredit(string hubKey, string appKey, string username, Guid sessionId = default(Guid));
        CreditStatusData GetCreditStatus(string hubKey, string appKey, string username, Guid sessionId = default(Guid));        
        List<Credit> GetCredits(string hubKey, string appKey);
        void Add(string hubKey, string appKey, Guid sessionId, string username, int creditConfigId, string caKey = "");
        void Upsert(Credit data, string username);

        // Evals
        UserEval GetEval(int evalId);
        List<UserEval> GetEvals(params long[] contentIds);
        List<UserEval> GetEvals(string hubKey, string appKey = "");        
        void UpsertEval(UserEval data, string username);
        void DeleteEval(int evalId);

        // Tests
        UserTest GetTest(int testId);
        List<UserTest> GetTests(params long[] contentId);
        List<UserTest> GetTests(string hubKey, string appKey = "");
        void UpsertTest(UserTest data, string username);
        void DeleteTest(int testId);
    }

    public class CreditsService : ICreditsService
    {
        private readonly ICreditsRepo _repo;
        private readonly ICreditConfigService _creditConfigSvc;
        private readonly IContentService _contentSvc;

        #region " Constructors "
        /// <summary>
        /// Default constructor
        /// </summary>
        public CreditsService()
        {            
            _repo = FPIQContainer.Current.GetInstance<ICreditsRepo>();
            _creditConfigSvc = FPIQContainer.Current.GetInstance<ICreditConfigService>();
            _contentSvc = FPIQContainer.Current.GetInstance<IContentService>();
        }

        /// <summary>
        /// Testable constructor 
        /// </summary>                
        public CreditsService(ICreditsRepo repo, ICreditConfigService creditConfigSvc, IContentService contentSvc)
        {
            _repo = repo;
            _creditConfigSvc = creditConfigSvc;
            _contentSvc = contentSvc;
        }
        #endregion

        #region " Credits "
        /// <summary>
        /// Adds / updates credit
        /// </summary>        
        public void Upsert(Credit credit, string username)
        {
            if (credit == null)
                throw new ArgumentNullException("credit");
            if (credit.ContentId <= 0)
                throw new ArgumentOutOfRangeException("credit.contentId");
            if (string.IsNullOrEmpty(credit.Username))
                throw new ArgumentNullException("credit.username");
            if (credit.CreditConfigId <= 0)
                throw new ArgumentOutOfRangeException("credit.creditConfigId");            
            if (string.IsNullOrEmpty(credit.Username))
                throw new ArgumentNullException("credit.username");
            if (string.IsNullOrEmpty(credit.CertKey))
                throw new ArgumentNullException("credit.certKey");
            if (credit.CreditCount <= 0)
                throw new ArgumentOutOfRangeException("credit.creditCount");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            var _credit = _repo.GetCredit(credit.ContentId, credit.Username, credit.CAKey, credit.SessionId);
            credit.LastModified = DateTime.UtcNow;
            credit.LastModifiedBy = username;
            if (_credit == null)
            {
                credit.DateCreated = DateTime.UtcNow;
                credit.CreatedBy = username;
                _repo.Add(credit);
            }
            else
            {
                credit.Id = _credit.Id;
                _repo.Update(credit);
            }
        }

        /// <summary>
        /// Adds credit
        /// </summary>        
        public void Add(string hubKey, string appKey, Guid sessionId, string username, int creditConfigId, string caKey = "")
        {   
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (sessionId.IsNullOrEmpty())
                throw new ArgumentNullException("sessionId");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");            
            if (creditConfigId <= 0)
                throw new ArgumentOutOfRangeException("creditConfigId");
           
            hubKey = hubKey.Trim();
            appKey = appKey.Trim();
            username = username.Trim();
            var appInfo = _contentSvc.GetContent<AppInfo>(appKey, hubKey);
            var credit = _repo.GetCredit(hubKey, appKey, username, sessionId);            
            if (credit == null && appInfo != null)
            {                
                var cconfig = _creditConfigSvc.GetCreditConfig(creditConfigId);
                if (cconfig == null)
                    throw new ApplicationException($"Credit config not found: '{creditConfigId}'");
                if (cconfig.Accreditations == null || cconfig.Accreditations.Count == 0)
                    throw new ApplicationException($"Credit config has no accreditation: '{creditConfigId}'");

                // Select accreditation
                if (cconfig.Accreditations.Count > 1 && string.IsNullOrEmpty(caKey))
                    throw new ApplicationException($"Credit has multiple accreditations, please provide specific 'caKey'");
                var acc = cconfig.Accreditations.Count == 1 ? cconfig.Accreditations.First() : cconfig.Accreditations.FirstOrDefault(a => a.CAKey.EqualsIgnoreCase(caKey));
                if (acc == null)
                    throw new ApplicationException($"Accreditation key not found: '{caKey}'");

                credit = new Credit
                {
                    ContentId = appInfo.ContentId,
                    HubKey = hubKey,
                    AppKey = appKey,
                    SessionId = sessionId,
                    Username = username,
                    CreditConfigId = creditConfigId,
                    CAKey = acc.CAKey,
                    CreditCount = acc.CreditCount,
                    CertKey = acc.Cert?.Key,
                    CertData = acc.Cert?.Data,
                    PreReqAckRequired = acc.PreReqAck == null ? false : acc.PreReqAck.IsRequired,
                    PreTestRequired = acc.PreTest == null ? false : acc.PreTest.IsRequired,
                    PostTestRequired = acc.PostTest == null ? false : acc.PostTest.IsRequired,
                    PostReqAckRequired = acc.PostReqAck == null ? false : acc.PostReqAck.IsRequired,
                    HasEval = acc.Eval == null ? false : acc.Eval.HasEval,
                    EvalRequired = acc.Eval == null ? false : acc.Eval.IsRequired,                    
                    LastModifiedBy = username,                    
                    CreatedBy = username
                };
                _repo.Add(credit);
            }            
        }

        /// <summary>
        /// Gets credit status data
        /// </summary>        
        public CreditStatusData GetCreditStatus(string hubKey, string appKey, string username, Guid sessionId = default(Guid))
        {           
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");            
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            var status = new CreditStatusData();
            var credit = _repo.GetCredit(hubKey, appKey, username, sessionId);
            status.CertificationStatus = credit.CertificationStatus;

            return status;            
        }

        /// <summary>
        /// Gets credit 
        /// </summary>        
        public Credit GetCredit(string hubKey, string appKey, string username, Guid sessionId)
        {
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");            
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");            

            return _repo.GetCredit(hubKey, appKey, username, sessionId);           
        }

        /// <summary>
        /// Gets credit list
        /// </summary>        
        public List<Credit> GetCredits(string hubKey, string appKey = "")
        {
            ValidateHubKey(hubKey);

            return _repo.GetCredits(hubKey, appKey);
        }

        #endregion

        #region " Evals "

        /// <summary>
        /// Adds / updates user eval
        /// </summary>        
        public void UpsertEval(UserEval eval, string username)
        {
            if (eval == null)
                throw new ArgumentNullException("eval");
            if (eval.ContentId <= 0)
                throw new ArgumentOutOfRangeException("eval.contentId");
            if (string.IsNullOrEmpty(eval.Username))
                throw new ArgumentNullException("eval.username");
            if (eval.CreditConfigId <= 0)
                throw new ArgumentOutOfRangeException("eval.creditConfigId");        
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            var _eval = eval.Id > 0 ? _repo.GetEval(eval.Id) : _repo.GetEval(eval.Username, eval.HubKey, eval.AppKey, eval.SessionId);            
            if (_eval == null)
            {
                eval.DateAdded = DateTime.UtcNow;
                var evalId = _repo.AddEval(eval);
                if (eval.Answers != null && eval.Answers.Count > 0)
                {
                    foreach (var answer in eval.Answers)
                    {
                        answer.UserEvalId = evalId;
                        _repo.AddEvalAnswer(answer);
                    }
                }
            }
            else
            {
                eval.Id = _eval.Id;
                _repo.UpdateEval(eval);
            }
        }

        /// <summary>
        /// Get user eval by eval id
        /// </summary>     
        public UserEval GetEval(int evalId)
        {
            if (evalId <= 0)
                throw new ArgumentOutOfRangeException("evalId");

            return _repo.GetEval(evalId);
        }

        public List<UserEval> GetEvals(params long[] contentIds)
        {
            if (contentIds == null || contentIds.Length == 0) return null;                   

            return _repo.GetEvals(contentIds);
        }

        public List<UserEval> GetEvals(string hubKey, string appKey = "")
        {
            ValidateHubKey(hubKey);

            return _repo.GetEvals(hubKey, appKey);
        }

        /// <summary>
        /// Delete user eval by id
        /// </summary>     
        public void DeleteEval(int evalId)
        {
            if (evalId <= 0)
                throw new ArgumentOutOfRangeException("evalId");

            var eval = _repo.GetEval(evalId);
            // Delete only if eval exists
            if (eval != null)
            {
                _repo.DeleteEval(evalId);
            }            
        }
        #endregion

            #region " Tests "
            /// <summary>
            /// Adds / updates user test
            /// </summary>        
            public void UpsertTest(UserTest test, string username)
        {
            if (test == null)
                throw new ArgumentNullException("test");
            if (test.ContentId <= 0)
                throw new ArgumentOutOfRangeException("test.contentId");
            if (string.IsNullOrEmpty(test.Username))
                throw new ArgumentNullException("test.username");
            if (test.CreditConfigId <= 0)
                throw new ArgumentOutOfRangeException("test.creditConfigId");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            var _test = test.Id > 0 ? _repo.GetTest(test.Id) : _repo.GetTest(test.Username, test.HubKey, test.AppKey, test.SessionId);
            if (_test == null)
            {
                test.DateAdded = DateTime.UtcNow;
                var testId = _repo.AddTest(test);
                if (test.Answers != null && test.Answers.Count > 0)
                {
                    foreach (var answer in test.Answers)
                    {
                        answer.UserTestId = testId;
                        _repo.AddTestAnswer(answer);
                    }
                }
            }
            else
            {
                test.Id = _test.Id;
                _repo.UpdateTest(test);
            }
        }

        /// <summary>
        /// Get user test by test id
        /// </summary>        
        public UserTest GetTest(int testId)
        {
            if (testId <= 0)
                throw new ArgumentOutOfRangeException("testId");

            return _repo.GetTest(testId);
        }

        public List<UserTest> GetTests(params long[] contentIds)
        {
            if (contentIds == null || contentIds.Length == 0) return null;

            return _repo.GetTests(contentIds);
        }

        public List<UserTest> GetTests(string hubKey, string appKey = "")
        {
            ValidateHubKey(hubKey);

            return _repo.GetTests(hubKey, appKey);
        }

        /// <summary>
        /// Delete user test by id
        /// </summary>     
        public void DeleteTest(int testId)
        {
            if (testId <= 0)
                throw new ArgumentOutOfRangeException("testId");

            var test = _repo.GetTest(testId);
            // Delete only if tests exists
            if (test != null)
            {
                _repo.DeleteTest(testId);
            }
        }

        #endregion


        #region " Private Methods "
        private void ValidateHubKey(string hubKey)
        {
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
        }
        #endregion

    }
}
