﻿using System;
using System.Collections.Generic;
using FPIQ.Entities.Models;
using FPIQ.Core.Repos;

namespace FPIQ.Core.Services
{
    public interface IHubsService
    {
        void Upsert(HubInfo hub, string username);
        void Delete(string hubKey);
        HubInfo GetHub(string hubKey);
        List<HubInfo> GetHubs(string keyword = "");
    }

    public class HubsService : IHubsService
    {
        private readonly IHubsRepo _repo;
        private readonly ISerializationService _serializer;

        #region " Constructors "
        public HubsService()
        {

            _repo = FPIQContainer.Current.GetInstance<IHubsRepo>();            
        }

        // Testable constructors
        public HubsService(IHubsRepo hubsRepo)
        {
            _repo = hubsRepo;            
        }

        #endregion

        /// <summary>
        /// Adds / Updates a hub
        /// </summary>        
        public void Upsert(HubInfo hub, string username)
        {
            if (hub == null)
                throw new ArgumentNullException("hub");
            if (string.IsNullOrEmpty(hub.HubKey))
                throw new ArgumentNullException("hub.hubKey");
            if (string.IsNullOrEmpty(hub.HubName))
                throw new ArgumentNullException("hub.hubName");
            if (string.IsNullOrEmpty(hub.ManifestUrl))
                throw new ArgumentNullException("hub.manifestUrl");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            var _hub = _repo.GetHub(hub.HubKey);
            hub.LastModified = DateTime.UtcNow;
            hub.LastModifiedBy = username;
            if (_hub == null)
            {
                hub.Id = 0;
                hub.CreatedBy = username;
                hub.DateCreated = DateTime.UtcNow;
                _repo.Add(hub);
            }
            else
            {
                hub.Id = _hub.Id;
                _repo.Update(hub);
            }
        }

        /// <summary>
        /// Deletes hub
        /// </summary>        
        public void Delete(string hubKey)
        {
            ValidateHubKey(hubKey);

            var hub = _repo.GetHub(hubKey);
            if (hub != null)
                _repo.Delete(hub.Id);           
        }

        /// <summary>
        /// Retrieves hub
        /// </summary>        
        public HubInfo GetHub(string hubKey)
        {
            ValidateHubKey(hubKey);

            return _repo.GetHub(hubKey);
        }

        /// <summary>
        /// Retrieves a list of hubs
        /// </summary>        
        public List<HubInfo> GetHubs(string keyword = "")
        {            
            return _repo.GetHubs(keyword);
        }

        #region " Private Methods "       

        private void ValidateHubKey(string hubKey)
        {
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
        }      

        #endregion
    }
}
