﻿using System;
using System.Net.Http;
using System.Collections.Generic;
using FPIQ.Entities.Models;
using FPIQ.Entities;

namespace FPIQ.Core.Services
{
    public interface IAppConfigService
    {
        void RegisterApp(string appKey, string hubKey, string appConfigUrl, string username);
        void DeleteApp(string appKey, string hubKey);
        AppManifest GetApp(string appKey, string hubKey);
        List<AppManifest> GetAppList(string hubKey, string keywords = "");
    }

    public class AppConfigService : IAppConfigService
    {
        private readonly IContentService _contentSvc;
        private readonly ISerializationService _serializer;

        #region " Constructors "
        public AppConfigService()
        {

            _contentSvc = FPIQContainer.Current.GetInstance<IContentService>();
            _serializer = FPIQContainer.Current.GetInstance<ISerializationService>();
        }

        // Testable constructors
        public AppConfigService(IContentService contentSvc, ISerializationService serializer)
        {
            _contentSvc = contentSvc;
            _serializer = serializer;
        }

        #endregion

        /// <summary>
        /// Registers an app
        /// </summary>        
        public void RegisterApp(string appKey, string hubKey, string appConfigUrl, string username)
        {
            ValidateAppAndHubKey(appKey, hubKey);
            if (string.IsNullOrEmpty(appConfigUrl))
                throw new ArgumentNullException("appConfigUrl");
            if (string.IsNullOrEmpty(username))
                throw new ArgumentNullException("username");

            var appInfo = _contentSvc.GetContent<AppInfo>(appKey, hubKey);
            var appManifest = GetAppManifest(appConfigUrl);
            if (appManifest == null)
                throw new ApplicationException($"Unable to retrieve app manifest from the given url: '{appConfigUrl}'");

            if (appInfo == null)
            {
                appInfo = new AppInfo
                {
                    ContentType = Constants.ContentTypes.App,                    
                    AppKey = appKey,
                    HubKey = hubKey
                };
            }

            appInfo.AppConfigUrl = appConfigUrl;
            appInfo.Title = appManifest.Title;
            appInfo.Description = appManifest.Description;
            appInfo.BasePath = appManifest.GameBrowser == null ? string.Empty : appManifest.GameBrowser.BasePath;
            appInfo.HubKey = hubKey;
            appInfo.AppKey = appKey;
            appInfo.ManifestJson = _serializer.JsonSerialize(appManifest);           

            _contentSvc.Upsert(appInfo, username);
        }

        /// <summary>
        /// Retrieves an app manifest
        /// </summary>        
        public AppManifest GetApp(string appKey, string hubKey)
        {
            ValidateAppAndHubKey(appKey, hubKey);

            var appInfo = _contentSvc.GetContent<AppInfo>(appKey, hubKey);
            try
            {
                var appManifest = _serializer.JsonDeserialize<AppManifest>(appInfo.ManifestJson);
                return appManifest;
            }
            catch
            {
                // swallow deserialization error
                return null;
            }
        }

        /// <summary>
        /// Retrieves a list of apps
        /// </summary>        
        public List<AppManifest> GetAppList(string hubKey, string keywords = "")
        {
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");

            var apps = _contentSvc.GetContents<AppInfo>(hubKey, Constants.ContentTypes.App, keywords);
            if (apps == null)
                return null;

            var appList = new List<AppManifest>();
            foreach (var appInfo in apps)
            {
                AppManifest app = null;
                try
                {
                    if (!string.IsNullOrEmpty(appInfo.ManifestJson))
                    {
                        app = _serializer.JsonDeserialize<AppManifest>(appInfo.ManifestJson);
                        appList.Add(app);
                    }
                }
                catch
                {
                    //swallow deserialization error                    
                }
            }
            return appList;
        }

        /// <summary>
        /// Deletes an app 
        /// </summary>        
        public void DeleteApp(string appKey, string hubKey)
        {
            ValidateAppAndHubKey(appKey, hubKey);
            var appInfo = _contentSvc.GetContent<AppInfo>(appKey, hubKey);
            if (appInfo != null)
            {
                _contentSvc.Delete(appInfo.ContentId);
            }
        }

        #region " Private Methods "       

        private void ValidateAppAndHubKey(string appKey, string hubKey)
        {
            if (string.IsNullOrEmpty(appKey))
                throw new ArgumentNullException("appKey");
            if (string.IsNullOrEmpty(hubKey))
                throw new ArgumentNullException("hubKey");
        }

        private AppManifest GetAppManifest(string appConfigUrl)
        {
            if (string.IsNullOrEmpty(appConfigUrl)) return null;

            var httpClient = new HttpClient();
            var url = appConfigUrl;
            var response = httpClient.GetAsync(url).Result;
            var jsonResult = response.Content.ReadAsStringAsync().Result;
            AppManifest app = null;
            try
            {
                if (!string.IsNullOrEmpty(jsonResult))
                    app = _serializer.JsonDeserialize<AppManifest>(jsonResult);

                return app;
            }
            catch
            {
                //swallow deserialization error
                return app;
            }
        }

        #endregion
    }
}
