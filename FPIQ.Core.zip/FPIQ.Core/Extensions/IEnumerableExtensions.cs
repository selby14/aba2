﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace FPIQ.Core.Extensions
{
    public static class IEnumerableExtensions
    {
        public static decimal ComputeAverage<T>(this IEnumerable<T> source, Func<T, decimal> selector)
        {
            if (source == null || !source.Any()) return 0;
            return source.Average(selector);            
        }

        public static decimal ComputeSum<T>(this IEnumerable<T> source, Func<T, decimal> selector)
        {
            if (source == null || !source.Any()) return 0;
            return source.Sum(selector);
        }
    }
}
