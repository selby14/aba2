﻿using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;

namespace FPIQ.Core.Extensions
{
    /// <summary>
    /// Extension methods for Newtonsoft.Json
    /// </summary>
    public static class JsonExtensions
    {
        /// <summary>
        /// Converts the given object to a JSON string.
        /// </summary>
        /// <param name="obj">The object to convert</param>
        /// <param name="camelCase">Indicates whether this object will be camelCase or not. Default is true</param>
        /// <param name="indented">Indicates whether this object will be indented or not. Default is false</param>
        /// <returns>The object converted to json string</returns>
        public static string ToJsonString(this object obj, bool camelCase = true, bool indented = false)
        {
            var options = new JsonSerializerSettings();

            if (camelCase)
            {
                options.ContractResolver = new CamelCasePropertyNamesContractResolver();
            }

            if (indented)
            {
                options.Formatting = Formatting.Indented;
            }

            return JsonConvert.SerializeObject(obj, options);
        }
    }
}
