﻿using System;

namespace FPIQ.Core.Extensions
{
    public static class GuidExtensions
    {
        public static bool IsNullOrEmpty(this Guid guid)
        {
            if (guid == null || guid == Guid.Empty) return true;
            
            return false;
        }

        // Returns DBNull.Value if input is null or empty guid. 
        // Use to prevent having empty string value in DB instead of just NULL
        public static object ValueOrDBNull(this Guid input)
        {
            if (input.IsNullOrEmpty())
            {
                return DBNull.Value;
            }

            return input;
        }
    }   
}