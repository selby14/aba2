﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace FPIQ.Core.Extensions
{
    public static class StringExtensions
    {
        /// <summary>
        /// Uses string.Split method to split given string by given separator.
        /// </summary>
        public static string[] Split(this string str, string separator)
        {
            return str.Split(new[] { separator }, StringSplitOptions.None);
        }

        /// <summary>
        /// Uses string.Split method to split given string by given separator.
        /// </summary>
        public static string[] Split(this string str, string separator, StringSplitOptions options)
        {
            return str.Split(new[] { separator }, options);
        }

        public static bool ContainsIgnoreCase(this string str, string subString)
        {
            if (str == null && subString == null) return true;
            if (str == null) return false;

            return str.IndexOf(subString, StringComparison.InvariantCultureIgnoreCase) >= 0;
        }

        public static bool EqualsIgnoreCase(this string str, string compareTo)
        {
            if (str == null && compareTo == null) return true;
            if (str == null) return false;

            return str.Equals(compareTo, StringComparison.InvariantCultureIgnoreCase);
        }      

        public static string TrimOrDefault(this string str, string def = "")
        {
            if (string.IsNullOrEmpty(str))
            {
                return def;
            }

            return str.Trim();
        }

        // Returns DBNull.Value if str is null, empty or white space. 
        // Use to prevent having empty string value in DB instead of just NULL
        public static object ValueOrDBNull(this string str)
        {
            if (string.IsNullOrEmpty(str) || string.IsNullOrWhiteSpace(str))
            {
                return DBNull.Value;
            }

            return str.Trim();
        }

        public static List<string> ToStringList(this string str, char delimeter = '|')
        {
            if (string.IsNullOrEmpty(str))
                return new List<string>();

            var arrItems = str.Trim().TrimEnd(delimeter).Split(delimeter);
            var items = new List<string>();
            foreach (var item in arrItems)
            {
                if (!string.IsNullOrEmpty(item) && !string.IsNullOrWhiteSpace(item))
                    items.Add(item.Trim());
            }
            return items;
        }

        public static string ParseValidEmails(this string input, string delimiter = ",")
        {
            var output = string.Empty;
            var emails = input.Split(delimiter.ToCharArray());
            if (emails.Length > 0)
            {
                output = emails.Where(email => email.IsValidEmail()).Aggregate(output, (current, email) => current + string.Format("{0},", email.Trim()));
                output = output.TrimEnd(',');
            }
            return output;
        }

        public static List<string> ToValidEmailList(this string input, string delimiter = ",")
        {
            var emails = input.Split(delimiter.ToCharArray());
            var emailList = new List<string>();

            foreach (var email in emails)
            {
                if (email.IsValidEmail())
                    emailList.Add(email.Trim());
            }
            return emailList;
        }

        public static bool IsValidEmail(this string email)
        {
            if (string.IsNullOrEmpty(email) || email.Trim().Length == 0)
            {
                return false;
            }

            const string pattern = @"^(?!\.)(""([^""\r\\]|\\[""\r\\])*""|"
                                   + @"([-a-z0-9!#$%&'*+/=?^_`{|}~]|(?<!\.)\.)*)(?<!\.)"
                                   + @"@[a-z0-9][\w\.-]*[a-z0-9]\.[a-z][a-z\.]*[a-z]$";
            var regex = new Regex(pattern, RegexOptions.IgnoreCase);
            return regex.IsMatch(email.Trim());
        }

        public static string FirstValidEmail(this string input, string delimiter = ",")
        {
            var output = string.Empty;
            var emails = input.Split(delimiter.ToCharArray());
            if (emails.Length > 0)
            {
                foreach (var email in emails)
                {
                    if (email.IsValidEmail())
                    {
                        output = email.Trim();
                        break;
                    }
                }
            }
            return output;
        }
    }
}