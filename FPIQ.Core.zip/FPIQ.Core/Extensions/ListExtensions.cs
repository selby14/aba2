﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FPIQ.Core.Extensions
{
    public static class ListExtensions
    {
        public static string ToStringDelimited(this List<string> list, char delimeter = '|')
        {
            if (list == null) return string.Empty;

            var sb = new StringBuilder();
            foreach (var item in list)
            {
                if (!string.IsNullOrEmpty(item) && !string.IsNullOrWhiteSpace(item))
                    sb.Append(item.Trim() + delimeter);
            }
            return sb.ToString().TrimEnd(delimeter);
        }

        public static string[] ToStringArray(this List<long> list)
        {
            if (list == null) return null;

            var strArray = new string[list.Count];
            var i = 0;
            foreach (var item in list)
            {
                strArray[i++] = item.ToString();                    
            }
            return strArray;
        }
    }
}
