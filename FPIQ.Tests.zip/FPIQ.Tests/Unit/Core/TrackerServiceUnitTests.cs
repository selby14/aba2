﻿using FPIQ.Core.Repos;
using FPIQ.Core.Services;
using FPIQ.Entities;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class TrackerServiceUnitTests
    {
        [TestInitialize]
        public void Initialize()
        {
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TrackerServiceUnitTests_Track_ShouldThrowsArgumentNullException()
        {
            //Arrange          
            var mockRepo = new Mock<ITrackerRepo>();
            var service = new TrackerService(mockRepo.Object);                

            //Act
            service.Track(null);            
        }

        [TestMethod]
        public void TrackerServiceUnitTests_Track_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<ITrackerRepo>();
            var service = new TrackerService(mockRepo.Object);
            TrackerInfo data = null;
            // Invalid Context
            try
            {
                data = new TrackerInfo { Context = null, Event = "event", RefId = "refid" };
                //Act
                service.Track(data);
                //Assert         
                Assert.Fail("Track should have thrown ArgumentNullException: data.context");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Track should have thrown ArgumentNullException: data.context");
            }
            // Invalid Event
            try
            {
                data = new TrackerInfo { Context = "context", Event = null, RefId = "refid" };
                //Act
                service.Track(data);
                //Assert         
                Assert.Fail("Track should have thrown ArgumentNullException: data.event");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Track should have thrown ArgumentNullException: data.event");
            }
            // Invalid RefId
            try
            {
                data = new TrackerInfo { Context = "context", Event = "event", RefId = null };
                //Act
                service.Track(data);
                //Assert         
                Assert.Fail("Track should have thrown ArgumentNullException: data.refId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Track should have thrown ArgumentNullException: data.refId");
            }           
        }

        [TestMethod]
        public void TrackerServiceUnitTests_Track_ShouldAddsRecord()
        {
            //Arrange            
            var data = new TrackerInfo { HubKey = "hubKey", Context = "context", Event = "event", RefId = "refId" };
            var mockRepo = new Mock<ITrackerRepo>();
            mockRepo.Setup(m => m.Track(data));
            
            var service = new TrackerService(mockRepo.Object);

            //Act
            service.Track(data);

            //Assert            
            mockRepo.Verify(m => m.Track(data));            
        }
        
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TrackerServiceUnitTests_Query_ShouldThrowsArgumentNullException_InvalidQuery()
        {
            //Arrange            
            var mockRepo = new Mock<ITrackerRepo>();
            var service = new TrackerService(mockRepo.Object);
           
            //Act
            service.Query(null);            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void TrackerServiceUnitTests_Query_ShouldThrowsArgumentNullException_InvalidHubKey()
        {
            //Arrange            
            var mockRepo = new Mock<ITrackerRepo>();
            var service = new TrackerService(mockRepo.Object);
            var query = new TrackerQuery { HubKey = null };

            //Act
            service.Query(query);
        }

        [TestMethod]
        public void TrackerServiceUnitTests_Query_ShouldReturnsRecords()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var hubKey = "HUB_KEY;";
            var context = Constants.TrackerContexts.Content;
            var evt = Constants.TrackerEvents.Interact;
            var entry1 = new TrackerInfo { Id = 1, HubKey = hubKey, Context = context, Event = evt, RefId = "refId", SessionId = sessionId, Group = "group1" };
            var entry2 = new TrackerInfo { Id = 2, HubKey = hubKey, Context = context, Event = evt, RefId = "refId", SessionId = sessionId, Group = "group1" };
            var entry3 = new TrackerInfo { Id = 3, HubKey = hubKey, Context = context, Event = evt, RefId = "refId", SessionId = sessionId, Group = "group2" };
            var entry4 = new TrackerInfo { Id = 4, HubKey = hubKey, Context = context, Event = evt, RefId = "refId", SessionId = sessionId, Group = "group2" };
            var entry5 = new TrackerInfo { Id = 5, HubKey = hubKey, Context = context, Event = evt, RefId = "refId", SessionId = sessionId, Group = "group2" };
            var entry6 = new TrackerInfo { Id = 5, HubKey = hubKey, Context = context, Event = evt, RefId = "refId", SessionId = sessionId, Group = "group3" };
            var dlist = new List<TrackerInfo>();
            dlist.Add(entry1);
            dlist.Add(entry2);
            dlist.Add(entry3);
            dlist.Add(entry4);
            dlist.Add(entry5);
            dlist.Add(entry6);

            var query = new TrackerQuery { HubKey = hubKey, SessionId = sessionId, GroupContains = "group2"};
            var mockRepo = new Mock<ITrackerRepo>();
            mockRepo.Setup(m => m.Search(It.IsAny<TrackerQuery>())).Returns(dlist.FindAll(c => c.SessionId == sessionId));
            mockRepo.Setup(m => m.Search(query)).Returns(dlist.FindAll(c => c.SessionId == query.SessionId && c.Group.Contains(query.GroupContains)));

            var service = new TrackerService(mockRepo.Object);            
            //Act            
            var result = service.Query(new TrackerQuery { HubKey = hubKey, SessionId = sessionId });         

            //Assert                             
            Assert.IsTrue(result != null & result.Count == 6, "6 records should have been returned.");
            mockRepo.Verify(m => m.Search(It.IsAny<TrackerQuery>()));
            
            //Act            
            result = service.Query(query);

            //Assert                             
            Assert.IsTrue(result != null && result.Count == 3, "3 records should have been returned.");
            mockRepo.Verify(m => m.Search(query));            
        }
    }
}
