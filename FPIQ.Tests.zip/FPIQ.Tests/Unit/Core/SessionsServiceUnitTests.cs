﻿using FPIQ.Core;
using FPIQ.Core.Repos;
using FPIQ.Core.Services;
using FPIQ.Entities;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class SessionsServiceUnitTests
    {
        private IContainer _container;

        [TestInitialize]
        public void Initialize()
        {
            _container = new MoqContainer_Integration();
            FPIQContainer.SetContainer(() => _container);
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_GetSession_ShouldThrowsArgumentNullException()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);                

            //Act
            var result = service.GetSession(Guid.Empty);

            //Assert         
        }

        [TestMethod]
        public void SessionsServiceUnitTests_GetSession_ShouldReturnsSession()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sList = new List<SessionInfo>();
            var session1 = new SessionInfo { Id = Guid.NewGuid(), AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP };
            var session2 = new SessionInfo { Id = Guid.NewGuid(), AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP };
            var session3 = new SessionInfo { Id = Guid.NewGuid(), AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP };
            sList.Add(session1);
            sList.Add(session2);
            sList.Add(session3);            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session1);

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            var result = service.GetSession(session1.Id);

            //Assert
            Assert.AreEqual(session1, result);            
            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_FindSessions_ShouldThrowsArgumentNullException()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();   
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            var result = service.FindSessions(null);

            //Assert         
        }

        [TestMethod]
        public void SessionsServiceUnitTests_FindSessions_ShouldReturnsSessions()
        {
            //Arrange
            var appKey = "APP_KEY";
            var request = new FindSessionRequest { ShareType = Constants.SessionShareTypes.AllUsers, AppKey = appKey, HubKey = "hubKey" };
            var sList = new List<SessionInfo>();
            var session1 = new SessionInfo { Id = Guid.NewGuid(), AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP };
            var session2 = new SessionInfo { Id = Guid.NewGuid(), AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP };
            var session3 = new SessionInfo { Id = Guid.NewGuid(), AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP };
            sList.Add(session1);
            sList.Add(session2);
            sList.Add(session3);
           
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            
            mockRepo.Setup(m => m.FindSessions(It.IsAny<FindSessionRequest>(), It.IsAny<int>())).Returns(sList);
                        
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            var result = service.FindSessions(request);

            //Assert
            Assert.AreEqual(sList, result);            
            mockRepo.Verify(m => m.FindSessions(It.IsAny<FindSessionRequest>(), It.IsAny<int>()));
        }
             

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_JoinOrCreate_ShouldReturnsAnExceptionWithInvalidArguments()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();                       

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            var result = service.JoinOrCreate(null, null, null, null);

            //Assert         
        }

        [TestMethod]
        public void SessionsServiceUnitTests_JoinOrCreate_ShouldCreateSession()
        {
            //Arrange
            var appKey = "APP_KEY";
            var request = new FindSessionRequest { ShareType = Constants.SessionShareTypes.AllUsers, AppKey = appKey };            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            var mockDataRepo = new Mock<ISessionDataRepo>();
            var mockContentSvc = new Mock<IContentService>();
            var mockCreditSvc = new Mock<ICreditsService>();
            var mockAppConfigSvc = new Mock<IAppConfigService>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.FindSessions(It.IsAny<FindSessionRequest>(), It.IsAny<int>())).Returns(new List<SessionInfo>());
            mockRepo.Setup(m => m.AddSession(It.IsAny<SessionInfo>()));
            mockRepo.Setup(m => m.AddSessionUser(It.IsAny<SessionUser>()));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object, mockDataRepo.Object, mockContentSvc.Object, mockCreditSvc.Object, mockAppConfigSvc.Object, mockSerializer.Object);

            //Act
            var result = service.JoinOrCreate("username", appKey, "hubKey", "sessionType");

            //Assert
            Assert.AreEqual(appKey, result.AppKey);            
            mockRepo.Verify(m => m.FindSessions(It.IsAny<FindSessionRequest>(), It.IsAny<int>()));
            mockRepo.Verify(m => m.AddSession(It.IsAny<SessionInfo>()));
            mockRepo.Verify(m => m.AddSessionUser(It.IsAny<SessionUser>()));
        }


        [TestMethod]
        public void SessionsServiceUnitTests_JoinOrCreate_ShouldJoinSession()
        {
            //Arrange
            var appKey = "APP_KEY";
            var request = new FindSessionRequest { ShareType = Constants.SessionShareTypes.AllUsers };
            var sList = new List<SessionInfo>();
            var session1 = new SessionInfo { Id = Guid.NewGuid(), AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP };
            var session2 = new SessionInfo { Id = Guid.NewGuid(), AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP };
            var session3 = new SessionInfo { Id = Guid.NewGuid(), AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP };
            sList.Add(session1);
            sList.Add(session2);
            sList.Add(session3);
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            var mockDataRepo = new Mock<ISessionDataRepo>();
            var mockContentSvc = new Mock<IContentService>();
            var mockCreditSvc = new Mock<ICreditsService>();
            var mockAppConfigSvc = new Mock<IAppConfigService>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.FindSessions(It.IsAny<FindSessionRequest>(), It.IsAny<int>())).Returns(sList);
            mockRepo.Setup(m => m.GetSessionUser(It.IsAny<Guid>(), It.IsAny<string>()));
            mockRepo.Setup(m => m.AddSessionUser(It.IsAny<SessionUser>()));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object, mockDataRepo.Object, mockContentSvc.Object, mockCreditSvc.Object, mockAppConfigSvc.Object, mockSerializer.Object);

            //Act
            var result = service.JoinOrCreate(appKey, "username", "workdKey", "sessionType");

            //Assert
            Assert.AreEqual(appKey, result.AppKey);
            mockRepo.Verify(m => m.FindSessions(It.IsAny<FindSessionRequest>(), It.IsAny<int>()));
            mockRepo.Setup(m => m.GetSessionUser(It.IsAny<Guid>(), It.IsAny<string>()));
            mockRepo.Setup(m => m.AddSessionUser(It.IsAny<SessionUser>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void SessionsServiceUnitTests_JoinSession_ShouldReturnsApplicationExeption()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.JoinSession("appKey", Guid.Empty, null, null);

            //Assert         
        }

        [TestMethod]        
        public void SessionsServiceUnitTests_JoinSession_ShouldReturnsApplicationException_SessionNotFound()
        {
            //Arrange            
            var username = "USER_NAME";
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            try
            {
                //Act
                service.JoinSession(username, Guid.NewGuid());                
            }
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Session not found"));
            }
        }

        [TestMethod]        
        public void SessionsServiceUnitTests_JoinSession_ShouldThrowsApplicationException_UserIsBanned()
        {
            try
            {
                //Arrange
                var appKey = "APP_KEY";
                var sessionId = Guid.NewGuid();
                var username = "USER_NAME";
                var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = username };
                var sessionUser =  new SessionUser { SessionId = sessionId, Status = Constants.SessionUserStatus.Banned, Username = username };
                var mockRepo = new Mock<ISessionsRepo>();
                var mockLogRepo = new Mock<ISessionLogsRepo>();
                var mockDataRepo = new Mock<ISessionDataRepo>();
                var mockContentSvc = new Mock<IContentService>();
                var mockCreditSvc = new Mock<ICreditsService>();
                var mockAppConfigSvc = new Mock<IAppConfigService>();
                var mockSerializer = new Mock<ISerializationService>();
                mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);
                mockRepo.Setup(m => m.GetSessionUser(It.IsAny<Guid>(), It.IsAny<string>())).Returns(sessionUser);

                var service = new SessionsService(mockRepo.Object, mockLogRepo.Object, mockDataRepo.Object, mockContentSvc.Object, mockCreditSvc.Object, mockAppConfigSvc.Object, mockSerializer.Object);

                //Act
                service.JoinSession(username, sessionId);
                mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
                mockRepo.Verify(m => m.GetSessionUser(It.IsAny<Guid>(), It.IsAny<string>()));
            }     
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("User is banned"));
            }
        }

        [TestMethod]
        public void SessionsServiceUnitTests_JoinSession_ShouldThrowsApplicationException_InvalidPassword()
        {           
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = "ownerName", RequirePassword = true, Password = "password" };
            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);
            mockRepo.Setup(m => m.GetSessionUser(It.IsAny<Guid>(), It.IsAny<string>())).Returns(default(SessionUser));
            try
            {
                var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

                //Act
                service.JoinSession(username, sessionId, null, "pwd");
                mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
                mockRepo.Verify(m => m.GetSessionUser(It.IsAny<Guid>(), It.IsAny<string>()));
            }
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Invalid session password"));
            }
        }


        [TestMethod]
        public void SessionsServiceUnitTests_JoinSession_ShouldJoinsSession()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username= "USER_NAME";
            var sList = new List<SessionInfo>();
            var session1 = new SessionInfo { Id = Guid.NewGuid(), AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP };
            var session2 = new SessionInfo { Id = Guid.NewGuid(), AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP };
            var session3 = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = username };
            sList.Add(session1);
            sList.Add(session2);
            sList.Add(session3);
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            var mockDataRepo = new Mock<ISessionDataRepo>();
            var mockContentSvc = new Mock<IContentService>();
            var mockCreditSvc = new Mock<ICreditsService>();
            var mockAppConfigSvc = new Mock<IAppConfigService>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session3);
            mockRepo.Setup(m => m.AddSessionUser(It.IsAny<SessionUser>()));
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object, mockDataRepo.Object, mockContentSvc.Object, mockCreditSvc.Object, mockAppConfigSvc.Object, mockSerializer.Object);

            //Act
            service.JoinSession(username, sessionId);

            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
            mockRepo.Verify(m => m.AddSessionUser(It.IsAny<SessionUser>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_ReAssignSessionOwner_ShouldThrowsArgumentNullException_InvalidCurrentOwnerName()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.ReAssignSessionOwner(null, Guid.Empty, "newOwnerName");

            //Assert         
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_ReAssignSessionOwner_ShouldThrowsArgumentNullException_InvalidSessionId()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.ReAssignSessionOwner("currentOwnerName", Guid.Empty, "newOwnerName");

            //Assert         
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_ReAssignSessionOwner_ShouldThrowsArgumentNullException_InvalidNewOwnerName()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.ReAssignSessionOwner("currentOwnerName", Guid.NewGuid(), null);

            //Assert         
        }

        [TestMethod]        
        public void SessionsServiceUnitTests_ReAssignSessionOwner_ShouldThrowsApplicationException_NotTheSessionOwner()
        {
            //Arrange            
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var currentOwnerName = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = "ownerName", RequirePassword = true, Password = "password" };

            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);            
            
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            try
            {
                //Act
                service.ReAssignSessionOwner(currentOwnerName, Guid.NewGuid(), "newOwnerName");

                //Assert         
                Assert.Fail("ReAssignSessionOwner should have been thrown application exception.");
            }
            
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Only the owner can re-assign session"));
            }
        }

        [TestMethod]
        public void SessionsServiceUnitTests_ReAssignSessionOwner_ShouldReassignsOwner()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";            
            var session3 = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = username };
            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session3);
            mockRepo.Setup(m => m.UpdateSession(It.IsAny<SessionInfo>()));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.ReAssignSessionOwner(username, sessionId, "newOwnerName");

            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
            mockRepo.Verify(m => m.UpdateSession(It.IsAny<SessionInfo>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_SessionCompleted_ShouldThrowsArgumentNullException_InvalidSessionId()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.SessionCompleted("username", Guid.Empty);

            //Assert         
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_SessionCompleted_ShouldThrowsArgumentNullException_InvalidUsername()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.SessionCompleted(null, Guid.NewGuid());

            //Assert         
        }

        [TestMethod]
        public void SessionsServiceUnitTests_SessionCompleted_ShouldThrowsApplicationException_NotTheSessionOwner()
        {
            //Arrange            
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var currentOwnerName = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = currentOwnerName, RequirePassword = true, Password = "password" };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);            

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            try
            {
                //Act
                service.SessionCompleted("ownerName", Guid.NewGuid());

                //Assert         
                Assert.Fail("SessionCompleted should have been thrown application exception.");
            }
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Only the owner can mark this session as completed"));
            }
        }

        [TestMethod]
        public void SessionsServiceUnitTests_SessionCompleted_ShouldThrowsApplicationException_SessionNotFound()
        {
            //Arrange                        
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";     
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(default(SessionInfo));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            try
            {
                //Act
                service.SessionCompleted(username, sessionId);

                //Assert         
                Assert.Fail("SessionCompleted should have been thrown application exception.");
            }
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Session not found"));
            }
        }

        [TestMethod]
        public void SessionsServiceUnitTests_SessionCompleted_ShouldCompletesSession()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var session3 = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = username };

            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session3);
            mockRepo.Setup(m => m.UpdateSession(It.IsAny<SessionInfo>()));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.SessionCompleted(username, sessionId);

            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
            mockRepo.Verify(m => m.UpdateSession(It.IsAny<SessionInfo>()));
        }

        [TestMethod]        
        public void SessionsServiceUnitTests_ShareSession_ShouldThrowsExceptions()
        {
            //Arrange            
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = username };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            // Invalid username
            try
            {
                //Act                
                service.ShareSession(null, Guid.NewGuid(), Constants.SessionShareTypes.AllUsers, false);

                //Assert         
                Assert.Fail("ShareSession should have been thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("ShareSession should have been thrown ArgumentNullException: username");
            }
            // Invalid sessionId
            try
            {
                //Act                
                service.ShareSession(username, Guid.Empty, Constants.SessionShareTypes.AllUsers, false);

                //Assert         
                Assert.Fail("ShareSession should have been thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("ShareSession should have been thrown ArgumentNullException: sessionId");
            }
            // Invalid shareType
            try
            {
                //Act                
                service.ShareSession(username, Guid.NewGuid(), null, false);

                //Assert         
                Assert.Fail("ShareSession should have been thrown ArgumentNullException: shareType");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("ShareSession should have been thrown ArgumentNullException: shareType");
            }
            // Invalid shareType
            try
            {
                //Act                
                service.ShareSession(username, Guid.NewGuid(), null, false);

                //Assert         
                Assert.Fail("ShareSession should have been thrown ArgumentNullException: shareType");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("ShareSession should have been thrown ArgumentNullException: shareType");
            }
        }       

        [TestMethod]
        public void SessionsServiceUnitTests_ShareSession_ShouldThrowsApplicationException_SessionNotFound()
        {
            //Arrange                        
            var sessionId = Guid.NewGuid();            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();

            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(default(SessionInfo));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            try
            {
                //Act
                service.ShareSession("username", sessionId, Constants.SessionShareTypes.AllUsers, false);

                //Assert         
                Assert.Fail("ShareSession should have been thrown application exception.");
            }
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Session not found"));
            }
        }

        [TestMethod]
        public void SessionsServiceUnitTests_ShareSession_ShouldSharesSession()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = username };
            var users = new Dictionary<string, string>();
            users.Add("user1", "admin");
            users.Add("user2", "player");
            users.Add("user3", null);

            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
                        
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);
            mockRepo.Setup(m => m.UpdateSession(It.IsAny<SessionInfo>()));
            mockRepo.Setup(m => m.AddSessionUser(It.IsAny<SessionUser>()));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.ShareSession(username, sessionId, Constants.SessionShareTypes.AllUsers, false, string.Empty, string.Empty, users);

            //Assert
            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
            mockRepo.Verify(m => m.UpdateSession(It.IsAny<SessionInfo>()));
            mockRepo.Verify(m => m.AddSessionUser(It.IsAny<SessionUser>()));
        }

        [TestMethod]        
        public void SessionsServiceUnitTests_UpdateSessionTime_ShouldThrowsExceptions()
        {
            //Arrange            
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = username };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();

            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            // Invalid username
            try
            {
                //Act                
                service.UpdateSessionTime(null, sessionId, DateTime.Now, DateTime.Now.AddHours(1));

                //Assert         
                Assert.Fail("UpdateSessionTime should have been thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("UpdateSessionTime should have been thrown ArgumentNullException: username");
            }
            // Invalid sessionId
            try
            {
                //Act                
                service.UpdateSessionTime(username, Guid.Empty, DateTime.Now, DateTime.Now.AddHours(1));

                //Assert         
                Assert.Fail("UpdateSessionTime should have been thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("UpdateSessionTime should have been thrown ArgumentNullException: sessionId");
            }
        }       

        [TestMethod]
        public void SessionsServiceUnitTests_UpdateSessionTime_ShouldThrowsApplicationException_SessionNotFound()
        {
            //Arrange                        
            var sessionId = Guid.NewGuid();
            var currentOwnerName = "USER_NAME";            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(default(SessionInfo));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            try
            {
                //Act
                service.UpdateSessionTime(currentOwnerName, sessionId, DateTime.Now, DateTime.Now.AddHours(1));

                //Assert         
                Assert.Fail("UpdateSessionTime should have been thrown application exception.");
            }
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Session not found"));
            }
        }

        [TestMethod]
        public void SessionsServiceUnitTests_UpdateSessionTime_ShouldThrowsApplicationException_NotTheSessionOwner()
        {
            //Arrange            
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var currentOwnerName = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = currentOwnerName, RequirePassword = true, Password = "password" };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();

            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            try
            {
                //Act
                service.UpdateSessionTime("notTheOwnerName", Guid.NewGuid(), DateTime.Now, DateTime.Now.AddHours(1));

                //Assert         
                Assert.Fail("UpdateSessionTime should have been thrown application exception.");
            }
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Only the session owner can update"));
            }
        }

        [TestMethod]
        public void SessionsServiceUnitTests_UpdateSessionTime_ShouldUpdatesSessionTime()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = username };
            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);
            mockRepo.Setup(m => m.UpdateSession(It.IsAny<SessionInfo>()));            

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.UpdateSessionTime(username, Guid.NewGuid(), DateTime.Now, DateTime.Now.AddHours(1));

            //Assert
            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
            mockRepo.Verify(m => m.UpdateSession(It.IsAny<SessionInfo>()));            
        }
        
        [TestMethod]        
        public void SessionsServiceUnitTests_AddUserToSession_ShouldThrowsException()
        {
            //Arrange            
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var ownerName = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = ownerName };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            // Invalid currentOwnerName
            try
            {
                //Act                
                service.AddUserToSession(null, sessionId, "username");

                //Assert         
                Assert.Fail("AddUserToSession should have been thrown ArgumentNullException: currentOwnerName");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("AddUserToSession should have been thrown ArgumentNullException: currentOwnerName");
            }
            // Invalid sessionId
            try
            {
                //Act                
                service.AddUserToSession(ownerName, Guid.Empty, "username");

                //Assert         
                Assert.Fail("AddUserToSession should have been thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("AddUserToSession should have been thrown ArgumentNullException: sessionId");
            }
            // Invalid username
            try
            {
                //Act                
                service.AddUserToSession(ownerName, sessionId, null);

                //Assert         
                Assert.Fail("AddUserToSession should have been thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("AddUserToSession should have been thrown ArgumentNullException: username");
            }
        }

        [TestMethod]
        public void SessionsServiceUnitTests_AddUserToSession_ShouldThrowsApplicationException_SessionNotFound()
        {
            //Arrange                        
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(default(SessionInfo));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            try
            {
                //Act
                service.AddUserToSession("ownerName", sessionId, username);

                //Assert         
                Assert.Fail("AddUserToSession should have been thrown application exception.");
            }
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Session not found"));
            }
        }

        [TestMethod]
        public void SessionsServiceUnitTests_AddUserToSession_ShouldThrowsApplicationException_NotTheSessionOwner()
        {
            //Arrange            
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var currentOwnerName = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = "ownerName", RequirePassword = true, Password = "password" };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            try
            {
                //Act
                service.AddUserToSession(currentOwnerName, Guid.NewGuid(), currentOwnerName);
            }
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Only the owner can add user"));
            }
            catch (Exception)
            {
                //Assert         
                Assert.Fail("AddUserToSession should have been thrown application exception.");
            }

            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
        }

        [TestMethod]
        public void SessionsServiceUnitTests_AddUserToSession_ShouldAddsUser()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var ownerName = "ownerName";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = ownerName};
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);            
            mockRepo.Setup(m => m.AddSessionUser(It.IsAny<SessionUser>()));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.AddUserToSession(ownerName, sessionId, username);

            //Assert
            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
            mockRepo.Verify(m => m.AddSessionUser(It.IsAny<SessionUser>()));
        }
        
        [TestMethod]        
        public void SessionsServiceUnitTests_BanUserFromSession_ShouldThrowsExceptions()
        {
            //Arrange            
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var ownerName = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = ownerName };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            // Invalid currentOwnerName
            try
            {
                //Act                                
                service.BanUserFromSession(null, sessionId, "username");

                //Assert         
                Assert.Fail("BanUserFromSession should have been thrown ArgumentNullException: currentOwnerName");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("BanUserFromSession should have been thrown ArgumentNullException: currentOwnerName");
            }
            // Invalid sessionId
            try
            {
                //Act                
                service.BanUserFromSession(ownerName, Guid.Empty, "username");

                //Assert         
                Assert.Fail("BanUserFromSession should have been thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("BanUserFromSession should have been thrown ArgumentNullException: sessionId");
            }
            // Invalid username
            try
            {
                //Act                
                service.BanUserFromSession(ownerName, sessionId, null);

                //Assert         
                Assert.Fail("BanUserFromSession should have been thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("BanUserFromSession should have been thrown ArgumentNullException: username");
            }
        }      

        [TestMethod]
        public void SessionsServiceUnitTests_BanUserFromSession_ShouldThrowsApplicationException_SessionNotFound()
        {
            //Arrange                        
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(default(SessionInfo));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            try
            {
                //Act
                service.BanUserFromSession("ownerName", sessionId, username);

                Assert.Fail("BanUserFromSession should have been thrown application exception.");
            }
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Session not found"));
            }
            catch (Exception)
            {                
                Assert.Fail("BanUserFromSession should have been thrown application exception.");
            }

            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
        }

        [TestMethod]
        public void SessionsServiceUnitTests_BanUserFromSession_ShouldThrowsApplicationException_OwnerAndUserTheSame()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var ownerName = "OWNER_NAME";            
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = ownerName };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            try
            {
                //Act
                service.BanUserFromSession(ownerName, sessionId, ownerName);
                                
                Assert.Fail("ApplicationException should have been thrown.");
            }
            catch (ApplicationException ex) 
            {
                Assert.IsTrue(ex.Message.EndsWith("can not be banned."));
            }
            catch (Exception)
            {
                Assert.Fail("ApplicationException should have been thrown.");
            }

            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
        }

        [TestMethod]
        public void SessionsServiceUnitTests_BanUserFromSession_ShouldBansUser()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var ownerName = "OWNER_NAME";
            var username = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = ownerName };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);
            mockRepo.Setup(m => m.GetSessionUser(It.IsAny<Guid>(), It.IsAny<string>())).Returns(default(SessionUser));
            mockRepo.Setup(m => m.AddSessionUser(It.IsAny<SessionUser>()));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.BanUserFromSession(ownerName, sessionId, username);

            //Assert
            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
            mockRepo.Verify(m => m.GetSessionUser(It.IsAny<Guid>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.AddSessionUser(It.IsAny<SessionUser>()));
        }

        [TestMethod]
        public void SessionsServiceUnitTests_CreateSession_ShouldThrowsArgumentNullException()
        {
            //Arrange                                    
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(default(SessionInfo));
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            // Invalid username
            try
            {
                //Act
                service.CreateSession(null, "appkey", "hubKey", "sessionType");

                //Assert         
                Assert.Fail("CreateSession(null, string, string, string) should have been thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("CreateSession(null, string, string, string) should have been thrown ArgumentNullException: username");
            }
            // Invalid appKey
            try
            {
                //Act
                service.CreateSession("username", null, "hubKey", "sessionType");
                //Assert         
                Assert.Fail("CreateSession(string, null, string, string) should have been thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("CreateSession(string, null, string, string) should have been thrown ArgumentNullException: appKey");
            }
            // Invalid hubKey
            try
            {
                //Act
                service.CreateSession("username", "appKey", null, "sessionType");
                //Assert         
                Assert.Fail("CreateSession(string, string, null, string) should have been thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("CreateSession(string, string, null, string) should have been thrown ArgumentNullException: hubKey");
            }
            // Invalid sessionType
            try
            {
                //Act
                service.CreateSession("username", "appKey", "hubKey", null);
                //Assert         
                Assert.Fail("CreateSession(string, string, string, null) should have been thrown ArgumentNullException: sessionType");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("CreateSession(string, string, string, null) should have been thrown ArgumentNullException: sessionType");
            }          
        }

        [TestMethod]
        public void SessionsServiceUnitTests_CreateSession_ShouldCreatesSession()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = username };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            var mockDataRepo = new Mock<ISessionDataRepo>();
            var mockContentSvc = new Mock<IContentService>();
            var mockCreditSvc = new Mock<ICreditsService>();
            var mockAppConfigSvc = new Mock<IAppConfigService>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.AddSession(It.IsAny<SessionInfo>()));            
            mockRepo.Setup(m => m.AddSessionUser(It.IsAny<SessionUser>()));
            
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object, mockDataRepo.Object, mockContentSvc.Object, mockCreditSvc.Object, mockAppConfigSvc.Object, mockSerializer.Object);

            //Act
            service.CreateSession(username, appKey, "hubKey", "sessionType");

            //Assert            
            mockRepo.Verify(m => m.AddSession(It.IsAny<SessionInfo>()));
            mockRepo.Verify(m => m.AddSessionUser(It.IsAny<SessionUser>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_ExitSession_ShouldThrowsArgumentNullException_InvalidSessionId()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.ExitSession("username", Guid.Empty);                   
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_ExitSession_ShouldThrowsArgumentNullException_InvalidUsername()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.ExitSession(null, Guid.NewGuid());                    
        }

        [TestMethod]
        public void SessionsServiceUnitTests_ExitSession_ShouldThrowsApplicationException_SessionNotFound()
        {
            //Arrange                        
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(default(SessionInfo));
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            try
            {
                //Act
                service.ExitSession(username, sessionId);

                //Assert         
                Assert.Fail("ExitSession should have been thrown application exception.");
            }
            catch (ApplicationException ex)
            {
                Assert.IsTrue(ex.Message.StartsWith("Session not found"));
            }
            catch (Exception)
            {
                Assert.Fail("ExitSession should have been thrown application exception.");
            }
        }

        [TestMethod]
        public void SessionsServiceUnitTests_ExitSession_ShouldExitsSession()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = username };
            var sessionUser = new SessionUser { SessionId = sessionId, Status = Constants.SessionUserStatus.Connected, Username = username };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);
            mockRepo.Setup(m => m.GetSessionUser(It.IsAny<Guid>(), It.IsAny<string>())).Returns(sessionUser);
            mockRepo.Setup(m => m.UpdateSessionUser(It.IsAny<SessionUser>()));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.ExitSession(username, sessionId);

            //Assert
            mockRepo.Verify(m => m.GetSession(It.IsAny<Guid>()));
            mockRepo.Verify(m => m.GetSessionUser(It.IsAny<Guid>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.UpdateSessionUser(It.IsAny<SessionUser>()));
        }

        #region " Session Stash "
        [TestMethod]
        public void SessionsServiceUnitTests_CreateSessionStash_ShouldCreatesSessionStash()
        {
            //Arrange
            var appKey = "APP_KEY";
            var sessionId = Guid.NewGuid();
            var username = "USER_NAME";
            var ownerName = "USER_NAME";
            var session = new SessionInfo { Id = sessionId, AppKey = appKey, HubKey = "hubKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = username };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();

            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(session);
            mockRepo.Setup(m => m.GetSessionUsers(It.IsAny<Guid>())).Returns(new List<SessionUser>());           

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            //Act
            service.CreateSessionStash(sessionId, username, ownerName);

            //Assert            
            mockRepo.Verify(m => m.GetSessionUsers(It.IsAny<Guid>()));            
        }

        [TestMethod]
        public void SessionsServiceUnitTests_CreateSessionStash_ShouldThrowsExceptions()
        {
            //Arrange                                    
            var session = new SessionInfo { Id = Guid.NewGuid(), AppKey = "appKey", ShareType = Constants.SessionShareTypes.AllUsers, SessionType = Constants.SessionTypes.SP, OwnerName = "ownerName" };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            
            mockRepo.Setup(m => m.GetSession(It.IsAny<Guid>())).Returns(default(SessionInfo));
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);
            // Invalid session
            try
            {
                //Act
                service.CreateSessionStash(Guid.Empty, "username", "ownerName");

                //Assert         
                Assert.Fail("CreateSessionStash(null, string, string) should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("CreateSessionStash(null, string, string) should have been thrown ArgumentNullException.");
            }
            // Invalid username
            try
            {
                //Act
                service.CreateSessionStash(session.Id, null, "ownerName");
                //Assert         
                Assert.Fail("CreateSessionStash(session.Id, null, string) should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("CreateSessionStash(session.Id, null, string) should have been thrown ArgumentNullException.");
            }
            // Invalid ownerName
            try
            {
                //Act
                service.CreateSessionStash(session.Id, "username", null);
                //Assert         
                Assert.Fail("CreateSessionStash(session.Id, string, null) should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("CreateSessionStash(session.Id, string, null) should have been thrown ArgumentNullException.");
            }          
        }
        
        [TestMethod]
        public void SessionsServiceUnitTests_AddSessionStash_ShouldAddsSessionStash()
        {
            //Arrange            
            var sessionId = Guid.NewGuid();            
            var ownerName = "OWNER_NAME";
            var stash = new SessionStash { SourceSessionId = sessionId, SourceOwnerName = ownerName, OwnerName=ownerName };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.AddSessionStash(stash));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.AddSessionStash(stash);

            //Assert            
            mockRepo.Verify(m => m.AddSessionStash(stash));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_AddSessionStash_ShouldThrowsArgumentNullException()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.AddSessionStash(null);
        }

        [TestMethod]
        public void SessionsServiceUnitTests_GetSessionStash_ShouldReturnsSessionStash()
        {
            //Arrange            
            var stashId = 369;
            var ownerName = "OWNER_NAME";
            var stash = new SessionStash { Id= stashId, SourceSessionId = Guid.NewGuid(), SourceOwnerName = ownerName, OwnerName = ownerName };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            mockRepo.Setup(m => m.GetSessionStash(stashId)).Returns(stash);

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            var result = service.GetSessionStash(stashId);

            //Assert     
            Assert.AreEqual(stash, result);       
            mockRepo.Verify(m => m.GetSessionStash(stashId));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void SessionsServiceUnitTests_GetSessionStash_ShouldThrowsArgumentOutOfRangeException()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.GetSessionStash(0);
        }

        [TestMethod]
        public void SessionsServiceUnitTests_GetSessionStashes_ShouldReturnsSessionStashes()
        {
            //Arrange                        
            var ownerName = "OWNER_NAME";
            var sessionId = Guid.NewGuid();
            var stash = new SessionStash { Id = 1, SourceSessionId = sessionId, SourceOwnerName = ownerName, OwnerName = ownerName };
            var stash2 = new SessionStash { Id = 2, SourceSessionId = sessionId, SourceOwnerName = ownerName, OwnerName = ownerName };
            var list = new List<SessionStash>();
            list.Add(stash);
            list.Add(stash2);
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            
            mockRepo.Setup(m => m.GetSessionStashes(ownerName, false)).Returns(list);
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            var result = service.GetSessionStashes(ownerName, false);

            //Assert     
            Assert.AreEqual(list, result);
            mockRepo.Verify(m => m.GetSessionStashes(ownerName, false));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_GetSessionStashes_ShouldThrowsArgumentNullException()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();            
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.GetSessionStashes(null);
        }

        [TestMethod]
        public void SessionsServiceUnitTests_DeleteSessionStash_ShouldDeletesSessionStash()
        {
            //Arrange            
            var stashId = 369;
            var sessionId = Guid.NewGuid();
            var ownerName = "OWNER_NAME";
            var stash = new SessionStash { Id = stashId, SourceSessionId = sessionId, SourceOwnerName = ownerName, OwnerName = ownerName };
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            mockRepo.Setup(m => m.DeleteSessionStash(stashId));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.DeleteSessionStash(stashId);

            //Assert                 
            mockRepo.Verify(m => m.DeleteSessionStash(stashId));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void SessionsServiceUnitTests_DeleteSessionStash_ShouldThrowsArgumentOutOfRangeException()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.DeleteSessionStash(0);
        }

        [TestMethod]
        public void SessionsServiceUnitTests_RestoreSessionStash_ShouldRestoresSessionStash()
        {
            //Arrange            
            var sessionId = Guid.NewGuid();
            var targetUsername = "TARGET_USER_ID";
            var ownerName = "OWNER_NAME";
            var stash = new SessionStash { SourceSessionId = sessionId, SourceOwnerName = ownerName, OwnerName = ownerName };
            var data = new SessionStashData();
            data.SessionInfo = new SessionInfo();
            data.SessionUser = new SessionUser();
            data.SessionData = new List<SessionDataItem>();
            data.SessionData.Add(new SessionDataItem());
            stash.Data = data;
            var mockRepo = new Mock<ISessionsRepo>();
            var mockDataRepo = new Mock<ISessionDataRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
                        
            mockRepo.Setup(m => m.AddSession(data.SessionInfo));
            mockRepo.Setup(m => m.AddSessionUser(data.SessionUser));
            mockDataRepo.Setup(m => m.Add(data.SessionData.FirstOrDefault()));

            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object, mockDataRepo.Object);

            //Act
            service.RestoreSessionStash(stash, targetUsername);

            //Assert            
            mockRepo.Verify(m => m.AddSession(data.SessionInfo));
            mockRepo.Verify(m => m.AddSessionUser(data.SessionUser));
            mockDataRepo.Verify(m => m.Add(data.SessionData.FirstOrDefault()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_RestoreSessionStash_ShouldThrowsArgumentNullException()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            
            
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.RestoreSessionStash(null, "targetUsername");
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionsServiceUnitTests_RestoreSessionStash_ShouldThrowsArgumentNullException2()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionsRepo>();
            var mockLogRepo = new Mock<ISessionLogsRepo>();
            
            
            var service = new SessionsService(mockRepo.Object, mockLogRepo.Object);

            //Act
            service.RestoreSessionStash(new SessionStash(), null);
        }
        #endregion
    }
}
