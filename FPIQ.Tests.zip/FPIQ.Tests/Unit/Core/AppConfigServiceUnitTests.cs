﻿using FPIQ.Core;
using FPIQ.Core.Services;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class AppConfigServiceUnitTests
    {
        private IContainer _container;

        [TestInitialize]
        public void Initialize()
        {
            _container = new MoqContainer_Integration();
            FPIQContainer.SetContainer(() => _container);
        }

        [TestMethod]        
        public void AppConfigServiceUnitTests_RegisterApp_ShouldThrowsArgumentNullExceptions()
        {
            //Arrange            
            var mockContentSvc = new Mock<IContentService>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new AppConfigService(mockContentSvc.Object, mockSerializer.Object);
            // Invalid appKey
            try
            {
                //Act
                service.RegisterApp(null, "hubKey", "appConfigUrl", "username");
                //Assert         
                Assert.Fail("RegisterApp should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("RegisterApp should have thrown ArgumentNullException: appKey");
            }
            // Invalid hubKey
            try
            {
                //Act
                service.RegisterApp("appKey", null, "appConfigUrl", "username");
                //Assert         
                Assert.Fail("RegisterApp should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("RegisterApp should have thrown ArgumentNullException: hubKey");
            }
            // Invalid appConfigUrl
            try
            {
                //Act
                service.RegisterApp("appKey", "hubKey", null, "username");
                //Assert         
                Assert.Fail("RegisterApp should have thrown ArgumentNullException: appConfigUrl");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("RegisterApp should have thrown ArgumentNullException: appConfigUrl");
            }
            // Invalid username
            try
            {
                //Act
                service.RegisterApp("appKey", "hubKey", "appConfigUrl", null);
                //Assert         
                Assert.Fail("RegisterApp should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("RegisterApp should have thrown ArgumentNullException: username");
            }           
        }
        
        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void AppConfigServiceUnitTests_RegisterApp_ShouldThrowsApplicationException_InvalidManifest()
        {
            //Arrange            
            var mockContentSvc = new Mock<IContentService>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new AppConfigService(mockContentSvc.Object, mockSerializer.Object);

            //Act
            service.RegisterApp("appKey", "hubKey", "http://www.google.com", "username");
            //Assert         
        }

        [TestMethod]
        public void AppConfigServiceUnitTests_GetApp_ShouldThrowsArgumentNullExceptions()
        {
            //Arrange            
            var mockContentSvc = new Mock<IContentService>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new AppConfigService(mockContentSvc.Object, mockSerializer.Object);
            // Invalid appKey
            try
            {
                //Act
                service.GetApp(null, "hubKey");
                //Assert         
                Assert.Fail("GetApp should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetApp should have thrown ArgumentNullException: appKey");
            }
            // Invalid hubKey
            try
            {
                //Act
                service.GetApp("appKey", null);
                //Assert         
                Assert.Fail("GetApp should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetApp should have thrown ArgumentNullException: hubKey");
            }          
        }

        [TestMethod]
        public void AppConfigServiceUnitTests_GetApp_ShouldReturnsApp()
        {
            //Arrange
            var appKey = "APP_KEY";
            var hubKey = "HUB_KEY";
            var app = new AppInfo { ContentId = 1, AppKey = appKey, HubKey = hubKey };
            var appManifest = new AppManifest
            {
                SchemaVersion = "1.0.0",
                AppType = "LandingPageApp",
                AppKey = "app1",
                AppVersion = "1.0.0",
                Title = "Test App",
                Description = "App description",
                GameBrowser = new GameBrowserManifest(),
                Gamification = new GamificationManifest()                
            };

            var mockContentSvc = new Mock<IContentService>();
            var mockSerializer = new Mock<ISerializationService>();                       
            mockContentSvc.Setup(m => m.GetContent<AppInfo>(It.IsAny<string>(), It.IsAny<string>())).Returns(app);
            mockSerializer.Setup(m => m.JsonDeserialize<AppManifest>(It.IsAny<string>())).Returns(appManifest);

            var service = new AppConfigService(mockContentSvc.Object, mockSerializer.Object);

            //Act
            var result = service.GetApp(appKey, hubKey);

            //Assert
            mockContentSvc.Verify(m => m.GetContent<AppInfo>(It.IsAny<string>(), It.IsAny<string>()));
            mockSerializer.Verify(m => m.JsonDeserialize<AppManifest>(It.IsAny<string>()));
        }
        
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void AppConfigServiceUnitTests_GetAppList_ShouldThrowsArgumentNullException()
        {
            //Arrange            
            var mockContentSvc = new Mock<IContentService>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new AppConfigService(mockContentSvc.Object, mockSerializer.Object);
            
            //Act
            service.GetAppList(null);            
        }

        [TestMethod]
        public void AppConfigServiceUnitTests_GetAppList_ShouldReturnsApps()
        {
            //Arrange
            var appKey = "APP_KEY";
            var appKey2 = "APP_KEY_2";
            var hubKey = "HUB_KEY";
            var app = new AppInfo { ContentId = 1, AppKey = appKey, HubKey = hubKey, ManifestJson = "dummy manifest json" };
            var app2 = new AppInfo { ContentId = 2, AppKey = appKey2, HubKey = hubKey, ManifestJson = "dummy manifest json" };
            var appList = new List<AppInfo> { app, app2 };
            var appManifest = new AppManifest
            {
                SchemaVersion = "1.0.0",
                AppType = "LandingPageApp",
                AppKey = "app1",
                AppVersion = "1.0.0",
                Title = "Test App",
                Description = "App description",
                GameBrowser = new GameBrowserManifest(),
                Gamification = new GamificationManifest()
            };

            var mockContentSvc = new Mock<IContentService>();
            var mockSerializer = new Mock<ISerializationService>();
            mockContentSvc.Setup(m => m.GetContents<AppInfo>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(appList);
            mockSerializer.Setup(m => m.JsonDeserialize<AppManifest>(It.IsAny<string>())).Returns(appManifest);

            var service = new AppConfigService(mockContentSvc.Object, mockSerializer.Object);

            //Act
            var result = service.GetAppList(hubKey);

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(2, result.Count);
            mockContentSvc.Verify(m => m.GetContents<AppInfo>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockSerializer.Verify(m => m.JsonDeserialize<AppManifest>(It.IsAny<string>()), Times.Exactly(2));
        }

        [TestMethod]
        public void AppConfigServiceUnitTests_DeleteApp_ShouldThrowsArgumentNullExceptions()
        {
            //Arrange            
            var mockContentSvc = new Mock<IContentService>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new AppConfigService(mockContentSvc.Object, mockSerializer.Object);
            // Invalid appKey
            try
            {
                //Act
                service.DeleteApp(null, "hubKey");
                //Assert         
                Assert.Fail("DeleteApp should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("DeleteApp should have thrown ArgumentNullException: appKey");
            }
            // Invalid hubKey
            try
            {
                //Act
                service.GetApp("appKey", null);
                //Assert         
                Assert.Fail("DeleteApp should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("DeleteApp should have thrown ArgumentNullException: hubKey");
            }
        }

        [TestMethod]
        public void AppConfigServiceUnitTests_DeleteApp_ShouldDeletesApp()
        {
            //Arrange
            var appKey = "APP_KEY";
            var hubKey = "HUB_KEY";
            var app = new AppInfo { ContentId = 1, AppKey = appKey, HubKey = hubKey };
            var appManifest = new AppManifest
            {
                SchemaVersion = "1.0.0",
                AppType = "LandingPageApp",
                AppKey = "app1",
                AppVersion = "1.0.0",
                Title = "Test App",
                Description = "App description",
                GameBrowser = new GameBrowserManifest(),
                Gamification = new GamificationManifest()
            };

            var mockContentSvc = new Mock<IContentService>();
            var mockSerializer = new Mock<ISerializationService>();
            mockContentSvc.Setup(m => m.GetContent<AppInfo>(It.IsAny<string>(), It.IsAny<string>())).Returns(app);
            mockContentSvc.Setup(m => m.Delete(It.IsAny<long>()));

            var service = new AppConfigService(mockContentSvc.Object, mockSerializer.Object);

            //Act
            service.DeleteApp(appKey, hubKey);

            //Assert
            mockContentSvc.Verify(m => m.GetContent<AppInfo>(It.IsAny<string>(), It.IsAny<string>()));
            mockContentSvc.Verify(m => m.Delete(It.IsAny<long>()));

        }
    }
}
