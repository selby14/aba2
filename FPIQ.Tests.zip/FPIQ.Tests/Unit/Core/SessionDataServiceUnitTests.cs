﻿using FPIQ.Core.Repos;
using FPIQ.Core.Services;
using FPIQ.Entities;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class SessionDataServiceUnitTests
    {
        [TestInitialize]
        public void Initialize()
        {
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionDataServiceUnitTests_SetData_ShouldThrowsArgumentNullException_InvalidData()
        {
            //Arrange          
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);                

            //Act
            service.SetData("username", null);
            //Assert         
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SessionDataServiceUnitTests_SetData_ShouldThrowsArgumentNullException_InvalidCurrentUser()
        {
            //Arrange          
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act
            service.SetData(null, new SessionDataItem());
            //Assert         
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_SetData_ShouldAddsData()
        {
            //Arrange
            var sessionId = Guid.NewGuid();            
            var data1 = new SessionDataItem { Id = 1, SessionId = sessionId, Key = "dataKey",  Value = "value", Username = null };                        
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetDataId(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).Returns(0);
            mockRepo.Setup(m => m.Add(data1)).Returns(It.IsAny<int>());
            
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act
            service.SetData("username", data1);

            //Assert            
            mockRepo.Verify(m => m.GetDataId(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.Add(data1));
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_SetData_ShouldUpdatesData()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var dataKey = "dataKey";
            var data1 = new SessionDataItem { Id = 1, SessionId = sessionId, Key = dataKey, Value = "value", Username = null };
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetDataId(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).Returns(data1.Id);
            mockRepo.Setup(m => m.Update(data1));
                        
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act
            data1.Value = "updated";
            service.SetData("currentuser", data1);            
                        
            //Assert            
            mockRepo.Verify(m => m.GetDataId(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.Update(data1));
        }

        [TestMethod]        
        public void SessionDataServiceUnitTests_SetValue_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);
            // Invalid sessionId
            try
            {             
                //Act
                service.SetValue(Guid.Empty, "key", "value");
                //Assert         
                Assert.Fail("SetValue should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) {}
            catch (Exception)
            {
                Assert.Fail("SetValue should have been thrown ArgumentNullException.");
            }
            // Invalid key
            try
            {                
                //Act
                service.SetValue(Guid.NewGuid(), null, "value");

                //Assert         
                Assert.Fail("SetValue should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("SetValue should have been thrown ArgumentNullException.");
            }
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_SetValue_ShouldThrowsException_SessionDataNotFound()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var data1 = new SessionDataItem { Id = 1, SessionId = sessionId, Key = "dataKey", Value = "value", Username = null };
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetDataId(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).Returns(0);
            try
            {                
                var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);
                //Act
                service.SetValue(Guid.NewGuid(), "key", "value");

                //Assert
                Assert.Fail("SetValue should have been thrown ApplicationException.");
            }
            catch (ApplicationException) { }
            catch (Exception)
            {
                Assert.Fail("SetValue should have been thrown ApplicationException.");
            }

            //Assert            
            mockRepo.Verify(m => m.GetDataId(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));            
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_SetValue_ShouldUpdatesValue()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var dataKey = "dataKey";
            var updatedValue = "updated value";
            var data1 = new SessionDataItem { Id = 1, SessionId = sessionId, Key = dataKey, Value = "value", Username = null };
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetDataId(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).Returns(data1.Id);
            mockRepo.Setup(m => m.UpdateValue(It.IsAny<long>(), It.IsAny<string>()));
            
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act
            service.SetValue(sessionId, dataKey, updatedValue);            

            //Assert            
            mockRepo.Verify(m => m.GetDataId(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.UpdateValue(It.IsAny<long>(), It.IsAny<string>()));
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetData_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);
            // Invalid sessionId
            try
            {
                //Act
                service.GetData(Guid.Empty, "key");
                //Assert         
                Assert.Fail("GetData should have been thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetData should have been thrown ArgumentNullException: sessionId");
            }
            // Invalid key
            try
            {
                //Act
                service.GetData(Guid.NewGuid(), null);

                //Assert         
                Assert.Fail("GetData should have been thrown ArgumentNullException: key");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetData should have been thrown ArgumentNullException: key");
            }
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetData_ShouldReturnNull()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var dataKey = "dataKey";
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).Returns(default(SessionDataItem));
                        
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act
            var result = service.GetData(sessionId, dataKey);

            //Assert            
            Assert.IsTrue(result == null, "null should have been returned.");
            mockRepo.Verify(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetData_ShouldReturnsData()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var dataKey = "dataKey";
            var data1 = new SessionDataItem { Id = 1, SessionId = sessionId, Key = dataKey, Value = "value", Username = null };
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).Returns(data1);
            
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act            
            var return_data = service.GetData(sessionId, dataKey);

            //Assert   
            Assert.AreEqual(data1, return_data);         
            mockRepo.Verify(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));            
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetData_ShouldReturnsData_KnownSessionDataType()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var dataKey = "dataKey";
            var objective = new SessionObjective { ObjectiveKey = "objectiveKey1" };
            var data1 = new SessionDataItem { Id = 1, SessionId = sessionId, Key = dataKey, DataType = Constants.SessionDataTypes.Objective, Value = JsonConvert.SerializeObject(objective) };
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockSerializer.Setup(m => m.JsonDeserialize<SessionObjective>(It.IsAny<string>())).Returns(objective);
            mockRepo.Setup(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).Returns(data1);

            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act            
            var return_data = service.GetData<SessionObjective>(sessionId, dataKey);

            //Assert   
            Assert.AreEqual(objective, return_data);
            mockRepo.Verify(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetData_ShouldReturnsDataWithChildren()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var dataKey = "dataKey";
            var data = new SessionDataItem { Id = 1, SessionId = sessionId, Key = dataKey, Value = "value", Username = null };
            var child1 = new SessionDataItem { Id = 2, SessionId = sessionId, Key = dataKey, Value = "value", Username = null };
            var child2 = new SessionDataItem { Id = 3, SessionId = sessionId, Key = dataKey, Value = "value", Username = null };
            var child3 = new SessionDataItem { Id = 4, SessionId = sessionId, Key = dataKey, Value = "value", Username = null };
            var dlist = new List<SessionDataItem>();
            dlist.Add(child1);
            dlist.Add(child2);
            dlist.Add(child3);
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).Returns(data);
            mockRepo.Setup(m => m.GetChildren(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).Returns(dlist);

            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act            
            var result = service.GetData(sessionId, dataKey, null, true);

            //Assert     
            Assert.IsTrue(result != null, "Data should have been returned.");
            Assert.IsTrue(result.Children != null, "Data children should have been returned.");
            Assert.IsTrue(result.Children.Count == 3, "Data children count should have been 3.");
            mockRepo.Verify(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.GetChildren(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetDataItems_ShouldThrowsExceptions()
        {
            //Arrange            
            var keys = new List<string>();
            keys.Add("dataKey");            
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);
            // Invalid sessionId
            try
            {
                //Act
                service.GetDataItems(Guid.Empty, keys);
                //Assert         
                Assert.Fail("GetDataItems should have been thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetDataItems should have been thrown ArgumentNullException: sessionId");
            }           
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetDataItems_ShouldReturnsDataItems()
        {
            //Arrange
            var sessionId = Guid.NewGuid();            
            var data1 = new SessionDataItem { Id = 1, SessionId = sessionId, Key = "dataKey", Value = "value", Username = null };
            var data2 = new SessionDataItem { Id = 2, SessionId = sessionId, Key = "dataKey2", Value = "value", Username = null };
            var data3 = new SessionDataItem { Id = 3, SessionId = sessionId, Key = "dataKey3", Value = "value", Username = null };
            var items = new List<SessionDataItem>();
            items.Add(data1);
            items.Add(data2);
            items.Add(data3);
            var keys = new List<string>();
            keys.Add("dataKey");
            keys.Add("dataKey2");
            keys.Add("dataKey3");
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetDataItems(It.IsAny<Guid>(), It.IsAny<List<string>>(), It.IsAny<string>(), It.IsAny<bool>())).Returns(items);
                        
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act            
            var return_items = service.GetDataItems(sessionId, keys);

            //Assert            
            Assert.AreEqual(items, return_items);
            mockRepo.Verify(m => m.GetDataItems(It.IsAny<Guid>(), It.IsAny<List<string>>(), It.IsAny<string>(), It.IsAny<bool>()));            
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetValue_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);
            // Invalid sessionId
            try
            {
                //Act
                service.GetValue(Guid.Empty, "key", "value");
                //Assert         
                Assert.Fail("GetValue should have been thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetValue should have been thrown ArgumentNullException: sessionId");
            }
            // Invalid key
            try
            {
                //Act
                service.GetValue(Guid.NewGuid(), null, "value");

                //Assert         
                Assert.Fail("GetValue should have been thrown ArgumentNullException: key");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetValue should have been thrown ArgumentNullException: key");
            }
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetValue_ShouldReturnsNull()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).Returns(default(SessionDataItem));
                        
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);
            //Act
            var result = service.GetValue(Guid.NewGuid(), "key");
            
            //Assert
            Assert.IsTrue(result == null, "Null should have been returned.");
            mockRepo.Verify(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetValue_ShouldReturnsValue()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var dataKey = "dataKey";
            var dataValue = "value";      
            var data1 = new SessionDataItem { Id = 1, SessionId = sessionId, Key = dataKey, Value = dataValue, Username = null };
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>())).Returns(data1);            

            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act
            var result = service.GetValue(sessionId, dataKey);

            //Assert       
            Assert.AreEqual(dataValue, result);     
            mockRepo.Verify(m => m.GetData(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));            
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_Delete_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);
            // Invalid sessionId
            try
            {
                //Act
                service.Delete(Guid.Empty, "key");
                //Assert         
                Assert.Fail("Delete should have been thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Delete should have been thrown ArgumentNullException: sessionId");
            }
            // Invalid key
            try
            {
                //Act
                service.Delete(Guid.NewGuid(), null);

                //Assert         
                Assert.Fail("Delete should have been thrown ArgumentNullException: key");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Delete should have been thrown ArgumentNullException: key");
            }
        }      

        [TestMethod]
        public void SessionDataServiceUnitTests_Delete_ShouldDeletesData()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var dataKey = "dataKey";            
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.Delete(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()));
            
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act
            service.Delete(sessionId, dataKey);

            //Assert            
            mockRepo.Setup(m => m.Delete(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<bool>()));            
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_DeleteChildren_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);
            // Invalid sessionId
            try
            {
                //Act
                service.DeleteChildren(Guid.Empty, "key");
                //Assert         
                Assert.Fail("DeleteChildren should have been thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("DeleteChildren should have been thrown ArgumentNullException: sessionId");
            }
            // Invalid key
            try
            {
                //Act
                service.DeleteChildren(Guid.NewGuid(), null);

                //Assert         
                Assert.Fail("DeleteChildren should have been thrown ArgumentNullException: parentKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("DeleteChildren should have been thrown ArgumentNullException: parentKey");
            }
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_DeleteChildren_ShouldDeletesChildren()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var parentKey = "dataKey";
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.DeleteChildren(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));

            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act
            service.DeleteChildren(sessionId, parentKey);

            //Assert            
            mockRepo.Setup(m => m.DeleteChildren(It.IsAny<Guid>(), It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetChildren_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);
            // Invalid sessionId
            try
            {
                //Act
                service.GetChildren(Guid.Empty, "key");
                //Assert         
                Assert.Fail("GetChildren should have been thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetChildren should have been thrown ArgumentNullException: sessionId");
            }
            // Invalid key
            try
            {
                //Act
                service.GetChildren(Guid.NewGuid(), null);

                //Assert         
                Assert.Fail("GetChildren should have been thrown ArgumentNullException: parentKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetChildren should have been thrown ArgumentNullException: parentKey");
            }
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_GetChildren_ShouldReturnNull()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var parentKey = "dataKey";
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetChildren(sessionId, parentKey, It.IsAny<string>())).Returns(It.IsAny<List<SessionDataItem>>());

            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act
            var result = service.GetChildren(sessionId, parentKey);

            //Assert            
            Assert.IsTrue(result == null, "Null should have been returned.");
            mockRepo.Setup(m => m.GetChildren(sessionId, parentKey, It.IsAny<string>()));
        }
      
        [TestMethod]
        public void SessionDataServiceUnitTests_GetChildren_ShouldReturnsChildren()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var parentKey = "dataKey";
            var parent = new SessionDataItem { Id = 1, SessionId = sessionId, Key = parentKey, Value = "value", Username = null };
            var child1 = new SessionDataItem { Id = 2, SessionId = sessionId, Key = "child1key", Value = "value", ParentKey = parentKey };
            var child2 = new SessionDataItem { Id = 3, SessionId = sessionId, Key = "child2key", Value = "value", ParentKey = parentKey };
            var child3 = new SessionDataItem { Id = 4, SessionId = sessionId, Key = "child3key", Value = "value", ParentKey = parentKey };
            var child4 = new SessionDataItem { Id = 5, SessionId = sessionId, Key = "chil4key", Value = "value" };
            var dlist = new List<SessionDataItem>();
            dlist.Add(child1);
            dlist.Add(child2);
            dlist.Add(child3);
            dlist.Add(child4);
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.GetChildren(sessionId, parentKey, It.IsAny<string>())).Returns(dlist.FindAll(c => c.ParentKey == parentKey));

            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act            
            var result = service.GetChildren(sessionId, parentKey);

            //Assert                 
            Assert.IsTrue(result != null, "Data children should have been returned.");
            Assert.IsTrue(result.Count == 3, "Data children count should have been 3.");            
            mockRepo.Verify(m => m.GetChildren(sessionId, parentKey, It.IsAny<string>()));
        }
        
        [TestMethod]
        public void SessionDataServiceUnitTests_FindData_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);
            // Invalid sessionId
            try
            {
                //Act
                service.FindData(new FindSessionDataRequest());
                //Assert         
                Assert.Fail("FindData should have been thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("FindData should have been thrown ArgumentNullException: sessionId");
            }
            // Invalid request
            try
            {
                //Act
                service.FindData(null);

                //Assert         
                Assert.Fail("FindData should have been thrown ArgumentNullException: request");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("FindData should have been thrown ArgumentNullException: request");
            }
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_FindData_ShouldReturnsNull()
        {
            //Arrange
            var sessionId = Guid.NewGuid();            
            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.FindData(It.IsAny<FindSessionDataRequest>())).Returns(It.IsAny<List<SessionDataItem>>());

            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);

            //Act
            var result = service.FindData(new FindSessionDataRequest { SessionId = sessionId });

            //Assert            
            Assert.IsTrue(result == null, "Null should have been returned.");
            mockRepo.Setup(m => m.FindData(It.IsAny<FindSessionDataRequest>()));
        }

        [TestMethod]
        public void SessionDataServiceUnitTests_FindData_ShouldReturnsData()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var parentKey = "dataKey";
            var parent = new SessionDataItem { Id = 1, SessionId = sessionId, Key = parentKey, Value = "value", Username = null };
            var child1 = new SessionDataItem { Id = 2, SessionId = sessionId, Key = "child1key", Value = "value", ParentKey = parentKey };
            var child2 = new SessionDataItem { Id = 3, SessionId = sessionId, Key = "child2key", Value = "value", ParentKey = parentKey };
            var child3 = new SessionDataItem { Id = 4, SessionId = sessionId, Key = "child3key", Value = "value", ParentKey = parentKey };
            var child4 = new SessionDataItem { Id = 5, SessionId = sessionId, Key = "chil4key", Value = "value" };
            var dlist = new List<SessionDataItem>();
            dlist.Add(child1);
            dlist.Add(child2);
            dlist.Add(child3);
            dlist.Add(child4);

            var mockRepo = new Mock<ISessionDataRepo>();
            var mockSerializer = new Mock<ISerializationService>();
            mockRepo.Setup(m => m.FindData(It.IsAny<FindSessionDataRequest>())).Returns(dlist.FindAll(c => c.ParentKey == parentKey));
            
            var service = new SessionDataService(mockRepo.Object, mockSerializer.Object);
            var request = new FindSessionDataRequest { ParentKey = parentKey, SessionId = sessionId };            
            //Act            
            var result = service.FindData(request);

            //Assert                 
            Assert.IsTrue(result != null, "Data should have been returned.");
            Assert.IsTrue(result.Count == 3, "Data count should have been 3.");
            mockRepo.Verify(m => m.FindData(It.IsAny<FindSessionDataRequest>()));
        }
    }
}
