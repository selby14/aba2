﻿using FPIQ.Core.Repos;
using FPIQ.Core.Services;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class LeaderboardsServiceUnitTests
    {
        [TestInitialize]
        public void Initialize()
        {
        }

        [TestMethod]
        public void LeaderboardsServiceUnitTests_Add_ShouldThrowsArgumentNullException()
        {
            //Arrange          
            var mockRepo = new Mock<ILeaderboardsRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            var mockCacheSvc = new Mock<ICacheService>();
            var service = new LeaderboardsService(mockRepo.Object, mockAppSvc.Object, mockCacheSvc.Object);
            // Invalid hubKey
            try
            {
                //Act
                service.Add(null, "appKey", "lbKey", "username", 100);
                //Assert         
                Assert.Fail("Add should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Add should have thrown ArgumentNullException: hubKey");
            }
            // Invalid appKey
            try
            {
                //Act
                service.Add("hubKey", null, "lbKey", "username", 100);
                //Assert         
                Assert.Fail("Add should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Add should have thrown ArgumentNullException: appKey");
            }
            // Invalid lbKey
            try
            {
                //Act
                service.Add("hubKey", "appKey", null, "username", 100);
                //Assert         
                Assert.Fail("Add should have thrown ArgumentNullException: lbKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Add should have thrown ArgumentNullException: lbKey");
            }
            // Invalid username
            try
            {
                //Act
                service.Add("hubKey", "appKey", "lbKey", null, 100);
                //Assert         
                Assert.Fail("Add should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Add should have thrown ArgumentNullException: username");
            }           
        }

        [TestMethod]
        public void LeaderboardsServiceUnitTests_Add_ShouldAddsEntry()
        {
            //Arrange            
            var data = new LeaderboardEntry { HubKey = "hubKey", AppKey = "appKey", LBKey = "leaderboard1", Username = "username", Points = 100 };
            var app = new AppManifest
            {
                SchemaVersion = "1.0.0",
                AppType = "LandingPageApp",
                AppKey = "app1",
                AppVersion = "1.0.0",
                Title = "Test App",
                Description = "App description",
                GameBrowser = new GameBrowserManifest(),
                Gamification = new GamificationManifest {
                    Badges = new List<BadgeInfo>(),
	                Leaderboards = new List<Leaderboard>
                    {                        
                        new Leaderboard
                        {
                            LBKey= "leaderboard1",
                            Title =  "Leaderboard1 Title",
                            Description =  "Leaderboard1 Description",
                            IconUrl =  "http://s3.amazonaws.com/gameBrowserV3/lb-icon.png"
                        }                        
                    }
                }
            };
            var mockRepo = new Mock<ILeaderboardsRepo>();
            var mockCacheSvc = new Mock<ICacheService>();
            var mockAppSvc = new Mock<IAppConfigService>();
            mockAppSvc.Setup(m => m.GetApp(It.IsAny<string>(), It.IsAny<string>())).Returns(app);
            mockRepo.Setup(m => m.AddEntry(It.IsAny<LeaderboardEntry>()));
            mockCacheSvc.Setup(m => m.Remove(It.IsAny<string>()));

            var service = new LeaderboardsService(mockRepo.Object, mockAppSvc.Object, mockCacheSvc.Object);

            //Act
            service.Add(data.HubKey, data.AppKey, data.LBKey, data.Username, data.Points);

            //Assert            
            mockAppSvc.Verify(m => m.GetApp(It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.AddEntry(It.IsAny<LeaderboardEntry>()));
            mockCacheSvc.Verify(m => m.Remove(It.IsAny<string>()));
        }

        [TestMethod]
        public void LeaderboardsServiceUnitTests_Add_ShouldUpdatesEntry()
        {
            //Arrange            
            var entry = new LeaderboardEntry { HubKey = "hubKey", AppKey = "appKey", LBKey = "leaderboard1", Username = "username", Points = 100 };
            var app = new AppManifest
            {
                SchemaVersion = "1.0.0",
                AppType = "LandingPageApp",
                AppKey = "app1",
                AppVersion = "1.0.0",
                Title = "Test App",
                Description = "App description",
                GameBrowser = new GameBrowserManifest(),
                Gamification = new GamificationManifest
                {
                    Badges = new List<BadgeInfo>(),
                    Leaderboards = new List<Leaderboard>
                    {
                        new Leaderboard
                        {
                            LBKey= "leaderboard1",
                            Title =  "Leaderboard1 Title",
                            Description =  "Leaderboard1 Description",
                            IconUrl =  "http://s3.amazonaws.com/gameBrowserV3/lb-icon.png"
                        }
                    }
                }
            };
            var mockRepo = new Mock<ILeaderboardsRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            var mockCacheSvc = new Mock<ICacheService>();
            mockAppSvc.Setup(m => m.GetApp(It.IsAny<string>(), It.IsAny<string>())).Returns(app);
            mockRepo.Setup(m => m.GetEntry(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(entry);
            mockRepo.Setup(m => m.UpdateEntry(It.IsAny<LeaderboardEntry>()));
            mockCacheSvc.Setup(m => m.Remove(It.IsAny<string>()));

            var service = new LeaderboardsService(mockRepo.Object, mockAppSvc.Object, mockCacheSvc.Object);

            //Act
            service.Add(entry.HubKey, entry.AppKey, entry.LBKey, entry.Username, entry.Points);

            //Assert            
            mockAppSvc.Verify(m => m.GetApp(It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.GetEntry(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.UpdateEntry(It.IsAny<LeaderboardEntry>()));
            mockCacheSvc.Verify(m => m.Remove(It.IsAny<string>()));
        }

        [TestMethod]
        public void LeaderboardsServiceUnitTests_GetUsers_ShouldThrowsArgumentNullException()
        {
            //Arrange          
            var mockRepo = new Mock<ILeaderboardsRepo>();
            var mockCacheSvc = new Mock<ICacheService>();
            var mockAppSvc = new Mock<IAppConfigService>();
            var service = new LeaderboardsService(mockRepo.Object, mockAppSvc.Object, mockCacheSvc.Object);
            // Invalid hubKey
            try
            {
                //Act
                service.GetUsers(null, "appKey", "lbKey");
                //Assert         
                Assert.Fail("GetUsers should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetUsers should have thrown ArgumentNullException: hubKey");
            }
            // Invalid appKey
            try
            {
                //Act
                service.GetUsers("hubKey", null, "lbKey");
                //Assert         
                Assert.Fail("GetUsers should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetUsers should have thrown ArgumentNullException: appKey");
            }
            // Invalid lbKey
            try
            {
                //Act
                service.GetUsers("hubKey", "appKey", null);
                //Assert         
                Assert.Fail("GetUsers should have thrown ArgumentNullException: lbKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetUsers should have thrown ArgumentNullException: lbKey");
            }          
        }

        [TestMethod]
        public void LeaderboardsServiceUnitTests_GetUsers_ShouldReturnsRecordsFromRepo()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var hubKey = "HUB_KEY;";
            var appKey = "APP_KEY;";
            var lbKey = "LB_KEY";
            var entry1 = new LeaderboardEntry { Id = 1, HubKey = hubKey, AppKey = appKey, LBKey = lbKey, Username = "user1", Points = 100 };
            var entry2 = new LeaderboardEntry { Id = 2, HubKey = hubKey, AppKey = appKey, LBKey = lbKey, Username = "user2", Points = 200 };
            var entry3 = new LeaderboardEntry { Id = 3, HubKey = hubKey, AppKey = appKey, LBKey = lbKey, Username = "user3", Points = 300 };
            var entry4 = new LeaderboardEntry { Id = 4, HubKey = hubKey, AppKey = appKey, LBKey = lbKey, Username = "user4", Points = 400 };
            var entry5 = new LeaderboardEntry { Id = 5, HubKey = hubKey, AppKey = appKey, LBKey = lbKey, Username = "user5", Points = 500 };            
            var entries = new List<LeaderboardEntry>
            {
                entry1,
                entry2,
                entry3,
                entry4,
                entry5              
            };          
            var mockRepo = new Mock<ILeaderboardsRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            var mockCacheSvc = new Mock<ICacheService>();

            mockCacheSvc.Setup(m => m.Get<List<LeaderboardEntry>>(It.IsAny<string>())).Returns(default(List<LeaderboardEntry>));
            mockRepo.Setup(m => m.GetEntries(hubKey, appKey, lbKey, It.IsAny<string>())).Returns(entries);

            var service = new LeaderboardsService(mockRepo.Object, mockAppSvc.Object, mockCacheSvc.Object);
            //Act            
            var result = service.GetUsers(hubKey, appKey, lbKey);         

            //Assert                             
            Assert.IsTrue(result != null & result.Count == 5, "5 records should have been returned.");
            mockCacheSvc.Verify(m => m.Get<List<LeaderboardEntry>>(It.IsAny<string>()));
            mockRepo.Verify(m => m.GetEntries(hubKey, appKey, lbKey, It.IsAny<string>()));
        }

        [TestMethod]
        public void LeaderboardsServiceUnitTests_GetUsers_ShouldReturnsRecordsFromCache()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var hubKey = "HUB_KEY;";
            var appKey = "APP_KEY;";
            var lbKey = "LB_KEY";
            var entry1 = new LeaderboardEntry { Id = 1, HubKey = hubKey, AppKey = appKey, LBKey = lbKey, Username = "user1", Points = 100 };
            var entry2 = new LeaderboardEntry { Id = 2, HubKey = hubKey, AppKey = appKey, LBKey = lbKey, Username = "user2", Points = 200 };
            var entry3 = new LeaderboardEntry { Id = 3, HubKey = hubKey, AppKey = appKey, LBKey = lbKey, Username = "user3", Points = 300 };
            var entry4 = new LeaderboardEntry { Id = 4, HubKey = hubKey, AppKey = appKey, LBKey = lbKey, Username = "user4", Points = 400 };
            var entry5 = new LeaderboardEntry { Id = 5, HubKey = hubKey, AppKey = appKey, LBKey = lbKey, Username = "user5", Points = 500 };            
            var entries = new List<LeaderboardEntry>
            {
                entry1,
                entry2,
                entry3,
                entry4,
                entry5
            };

            var mockRepo = new Mock<ILeaderboardsRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            var mockCacheSvc = new Mock<ICacheService>();

            mockCacheSvc.Setup(m => m.Get<List<LeaderboardEntry>>(It.IsAny<string>())).Returns(entries);
            mockRepo.Setup(m => m.GetEntries(hubKey, appKey, lbKey, It.IsAny<string>())).Returns(entries);            

            var service = new LeaderboardsService(mockRepo.Object, mockAppSvc.Object, mockCacheSvc.Object);
            //Act            
            var result = service.GetUsers(hubKey, appKey, lbKey);

            //Assert                             
            Assert.IsTrue(result != null & result.Count == 5, "5 records should have been returned.");
            mockCacheSvc.Verify(m => m.Get<List<LeaderboardEntry>>(It.IsAny<string>()));
            mockRepo.Verify(m => m.GetEntries(hubKey, appKey, lbKey, It.IsAny<string>()), Times.Never);
        }

        [TestMethod]
        public void LeaderboardsServiceUnitTests_Remove_ShouldThrowsArgumentNullException()
        {
            //Arrange          
            var mockRepo = new Mock<ILeaderboardsRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            var mockCacheSvc = new Mock<ICacheService>();
            var service = new LeaderboardsService(mockRepo.Object, mockAppSvc.Object, mockCacheSvc.Object);
            // Invalid hubKey
            try
            {
                //Act
                service.Remove(null, "appKey", "lbKey", "username");
                //Assert         
                Assert.Fail("Remove should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Remove should have thrown ArgumentNullException: hubKey");
            }
            // Invalid appKey
            try
            {
                //Act
                service.Remove("hubKey", null, "lbKey", "username");
                //Assert         
                Assert.Fail("Remove should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Remove should have thrown ArgumentNullException: appKey");
            }
            // Invalid lbKey
            try
            {
                //Act
                service.Remove("hubKey", "appKey", null, "username");
                //Assert         
                Assert.Fail("Remove should have thrown ArgumentNullException: lbKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Remove should have thrown ArgumentNullException: lbKey");
            }
            // Invalid username
            try
            {
                //Act
                service.Remove("hubKey", "appKey", "lbKey", null);
                //Assert         
                Assert.Fail("Remove should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Remove should have thrown ArgumentNullException: username");
            }           
        }

        [TestMethod]
        public void LeaderboardsServiceUnitTests_Remove_ShouldRemovesEntry()
        {
            //Arrange
            var sessionId = Guid.NewGuid();
            var hubKey = "HUB_KEY";
            var appKey = "APP_KEY";
            var lbKey = "LB_KEY";
            var username = "USERNAME";
            var entry = new LeaderboardEntry { Id = 1, HubKey = hubKey, AppKey = appKey, LBKey = lbKey, Username = username, Points = 100 };                                    
            var mockRepo = new Mock<ILeaderboardsRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            var mockCacheSvc = new Mock<ICacheService>();
            mockRepo.Setup(m => m.GetEntry(hubKey, appKey, lbKey, username)).Returns(entry);
            mockRepo.Setup(m => m.DeleteEntry(hubKey, appKey, lbKey, username));

            var service = new LeaderboardsService(mockRepo.Object, mockAppSvc.Object, mockCacheSvc.Object);
            //Act            
            service.Remove(hubKey, appKey, lbKey, username);

            //Assert                                         
            mockRepo.Verify(m => m.GetEntry(hubKey, appKey, lbKey, username));
            mockRepo.Verify(m => m.DeleteEntry(hubKey, appKey, lbKey, username));
        }
    }
}
