﻿using FPIQ.Core.Repos;
using FPIQ.Core.Services;
using FPIQ.Entities;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class ContentServiceUnitTests
    {
        [TestInitialize]
        public void Initialize()
        {
        }

        [TestMethod]        
        public void ContentServiceUnitTests_GetContent_ShouldThrowsArgumentNullExceptions()
        {
            //Arrange          
            var mockRepo = new Mock<IContentRepo>();            
            var mockContentSvc = new Mock<IContentService>();
            var service = new ContentService(mockRepo.Object);
            // Invalid contentKey
            try
            {
                //Act
                service.GetContent(null, "groupKey");
                //Assert         
                Assert.Fail("GetContent should have thrown ArgumentNullException: contentKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetContent should have thrown ArgumentNullException: contentKey");
            }
            // Invalid groupKey
            try
            {
                //Act
                service.GetContent("contentKey", null);
                //Assert         
                Assert.Fail("GetContent should have thrown ArgumentNullException: groupKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetContent should have thrown ArgumentNullException: groupKey");
            }             
        }

        [TestMethod]
        public void ContentServiceUnitTests_GetContent_ShouldReturnsContent()
        {
            //Arrange          
            var content = new Content { ContentId = 8, ContentKey = "contentKey", GroupKey = "groupKey", CreditConfigId = 1 };            
            var mockRepo = new Mock<IContentRepo>();            
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetContent(It.IsAny<string>(), It.IsAny<string>())).Returns(content);
            var service = new ContentService(mockRepo.Object);

            //Act
            var result = service.GetContent("contentKey", "groupKey");

            //Assert         
            Assert.AreEqual(content, result);
            mockRepo.Verify(m => m.GetContent(It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ContentServiceUnitTests_GetContent_ById_ShouldThrowsArgumentOutOfRangeException()
        {
            //Arrange          
            var mockRepo = new Mock<IContentRepo>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new ContentService(mockRepo.Object);           
           //Act
           service.GetContent(0);
        }

        [TestMethod]
        public void ContentServiceUnitTests_GetContent_ById_ShouldReturnsContent()
        {
            //Arrange          
            var content = new Content { ContentId = 8, ContentKey = "contentKey", GroupKey = "groupKey", CreditConfigId = 1 };
            var mockRepo = new Mock<IContentRepo>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetContent(It.IsAny<long>())).Returns(content);
            var service = new ContentService(mockRepo.Object);

            //Act
            var result = service.GetContent(8);

            //Assert         
            Assert.AreEqual(content, result);
            mockRepo.Verify(m => m.GetContent(It.IsAny<long>()));
        }

        [TestMethod]        
        public void ContentServiceUnitTests_Upsert_ShouldThrowsArgumentNullExceptions()
        {
            //Arrange          
            var mockRepo = new Mock<IContentRepo>();            
            var mockContentSvc = new Mock<IContentService>();
            var service = new ContentService(mockRepo.Object);            
            // Invalid content
            try
            {
                //Act
                service.Upsert(null, "username");
                //Assert         
                Assert.Fail("Upsert should have thrown ArgumentNullException: content");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Upsert should have thrown ArgumentNullException: content");
            }
            // Invalid username
            try
            {
                //Act
                service.Upsert(new Content(), null);
                //Assert         
                Assert.Fail("Upsert should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Upsert should have thrown ArgumentNullException: username");
            }
        }

        [TestMethod]
        public void ContentServiceUnitTests_Upsert_ShouldAddsContent()
        {
            //Arrange          
            var content = new Content { ContentId = 0, ContentKey = "contentKey", GroupKey = "groupKey", CreditConfigId = 1 };
            var mockRepo = new Mock<IContentRepo>();            
            var mockContentSvc = new Mock<IContentService>();            
            mockRepo.Setup(m => m.Add(It.IsAny<Content>()));

            var service = new ContentService(mockRepo.Object);
                        
            //Act
            service.Upsert(content, "username");

            //Assert                     
            mockRepo.Verify(m => m.Add(It.IsAny<Content>()));
        }

        [TestMethod]
        public void ContentServiceUnitTests_Upsert_ShouldUpdatesContent()
        {
            //Arrange          
            var content = new Content { ContentId = 8, ContentKey = "contentKey", GroupKey = "groupKey", CreditConfigId = 1 };
            var mockRepo = new Mock<IContentRepo>();            
            var mockContentSvc = new Mock<IContentService>();            
            mockRepo.Setup(m => m.Update(content));

            var service = new ContentService(mockRepo.Object);

            //Act
            service.Upsert(content, "username");

            //Assert                     
            mockRepo.Verify(m => m.Update(content));
        }

        [TestMethod]
        public void ContentServiceUnitTests_Delete_ShouldDeletesContent()
        {
            //Arrange          
            var content = new Content { ContentId = 8, ContentKey = "contentKey", GroupKey = "groupKey", CreditConfigId = 1 };
            var mockRepo = new Mock<IContentRepo>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.Delete(It.IsAny<long>()));
            var service = new ContentService(mockRepo.Object);

            //Act
            service.Delete(content.ContentId);

            //Assert                     
            mockRepo.Verify(m => m.Delete(It.IsAny<long>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void ContentServiceUnitTests_GetContents_ShouldThrowsArgumentNullException()
        {
            //Arrange          
            var mockRepo = new Mock<IContentRepo>();            
            var mockContentSvc = new Mock<IContentService>();
            var service = new ContentService(mockRepo.Object);

            //Act
            service.GetContents(null, "contentType", "keywords");
        }

        [TestMethod]
        public void ContentServiceUnitTests_GetCredits_ShouldReturnsCredits()
        {
            //Arrange          
            var contents = new List<Content> {
                  new Content { ContentId = 8, ContentKey = "contentKey", GroupKey = "groupKey", CreditConfigId = 1 },
                  new Content { ContentId = 9, ContentKey = "contentKey", GroupKey = "groupKey", CreditConfigId = 1 }
            };
            var mockRepo = new Mock<IContentRepo>();            
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetContents<Content>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(contents);

            var service = new ContentService(mockRepo.Object);

            //Act
            var result = service.GetContents("groupKey");

            //Assert         
            Assert.AreEqual(contents, result);
            mockRepo.Verify(m => m.GetContents<Content>(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void ContentServiceUnitTests_IncrementViewCount_ShouldThrowsArgumentOutOfRangeException()
        {
            //Arrange          
            var mockRepo = new Mock<IContentRepo>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new ContentService(mockRepo.Object);
            //Act
            service.GetContent(0);
        }

        [TestMethod]
        public void ContentServiceUnitTests_IncrementViewCount_ShouldReturnsContent()
        {
            //Arrange                      
            var mockRepo = new Mock<IContentRepo>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.IncrementViewCount(It.IsAny<long>()));
            var service = new ContentService(mockRepo.Object);

            //Act
            service.IncrementViewCount(8);

            //Assert                     
            mockRepo.Verify(m => m.IncrementViewCount(It.IsAny<long>()));
        }
    }
}
