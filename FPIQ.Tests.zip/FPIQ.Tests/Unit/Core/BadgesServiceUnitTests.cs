﻿using FPIQ.Core.Repos;
using FPIQ.Core.Services;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class BadgesServiceUnitTests
    {
        [TestInitialize]
        public void Initialize()
        {
        }

        [TestMethod]
        public void BadgesServiceUnitTests_Award_ShouldThrowsArgumentNullException()
        {
            //Arrange          
            var mockRepo = new Mock<IBadgesRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            var service = new BadgesService(mockRepo.Object , mockAppSvc.Object);
            // Invalid hubKey
            try
            {
                //Act
                service.Award(null, "appKey", "badgeKey", "username", "level");
                //Assert         
                Assert.Fail("Award should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Award should have thrown ArgumentNullException: hubKey");
            }
            // Invalid appKey
            try
            {
                //Act
                service.Award("hubKey", null, "badgeKey", "username", "level");
                //Assert         
                Assert.Fail("Award should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Award should have thrown ArgumentNullException: appKey");
            }
            // Invalid badgeKey
            try
            {
                //Act
                service.Award("hubKey", "appKey", null, "username", "level");
                //Assert         
                Assert.Fail("Award should have thrown ArgumentNullException: badgeKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Award should have thrown ArgumentNullException: badgeKey");
            }
            // Invalid username
            try
            {
                //Act
                service.Award("hubKey", "appKey", "badgeKey", null, "level");
                //Assert         
                Assert.Fail("Award should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Award should have thrown ArgumentNullException: username");
            }
            // Invalid level
            try
            {
                //Act
                service.Award("hubKey", "appKey", "badgeKey", "username", null);
                //Assert         
                Assert.Fail("Award should have thrown ArgumentNullException: level");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Award should have thrown ArgumentNullException: level");
            }
        }

        [TestMethod]
        public void BadgesServiceUnitTests_Award_ShouldAddsEntry()
        {
            //Arrange            
            var data = new BadgeEntry { HubKey = "hubKey", AppKey = "appKey", BadgeKey = "badge1", Username = "username", Level = "level" };
            var app = new AppManifest
            {
                SchemaVersion = "1.0.0",
                AppType = "LandingPageApp",
                AppKey = "app1",
                AppVersion = "1.0.0",
                Title = "Test App",
                Description = "App description",
                GameBrowser = new GameBrowserManifest(),
                Gamification = new GamificationManifest {
                    Badges = new List<BadgeInfo> 
                    {
                        new BadgeInfo { BadgeKey = "badge1",
		                    Title =  "Badge1 Title",
		                    Description =  "Badge1 Description",
		                    IconUrl =  "http://s3.amazonaws.com/gameBrowserV3/badge.png"
                        }
                    },
	                Leaderboards = new List<Leaderboard>()
                }
            };
            var mockRepo = new Mock<IBadgesRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            mockAppSvc.Setup(m => m.GetApp(It.IsAny<string>(), It.IsAny<string>())).Returns(app);
            mockRepo.Setup(m => m.AddEntry(It.IsAny<BadgeEntry>()));
            
            var service = new BadgesService(mockRepo.Object, mockAppSvc.Object);

            //Act
            service.Award(data.HubKey, data.AppKey, data.BadgeKey, data.Username, data.Level);

            //Assert            
            mockAppSvc.Verify(m => m.GetApp(It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.AddEntry(It.IsAny<BadgeEntry>()));            
        }

        [TestMethod]
        public void BadgesServiceUnitTests_Award_ShouldUpdatesEntry()
        {
            //Arrange            
            var entry = new BadgeEntry { HubKey = "hubKey", AppKey = "appKey", BadgeKey = "badge1", Username = "username", Level = "level" };
            var app = new AppManifest
            {
                SchemaVersion = "1.0.0",
                AppType = "LandingPageApp",
                AppKey = "app1",
                AppVersion = "1.0.0",
                Title = "Test App",
                Description = "App description",
                GameBrowser = new GameBrowserManifest(),
                Gamification = new GamificationManifest
                {
                    Badges = new List<BadgeInfo>
                    {
                        new BadgeInfo { BadgeKey = "badge1",
                            Title =  "Badge1 Title",
                            Description =  "Badge1 Description",
                            IconUrl =  "http://s3.amazonaws.com/gameBrowserV3/badge.png"
                        }
                    },
                    Leaderboards = new List<Leaderboard>()
                }
            };
            var mockRepo = new Mock<IBadgesRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            mockAppSvc.Setup(m => m.GetApp(It.IsAny<string>(), It.IsAny<string>())).Returns(app);
            mockRepo.Setup(m => m.GetEntry(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>())).Returns(entry);
            mockRepo.Setup(m => m.UpdateEntry(It.IsAny<BadgeEntry>()));

            var service = new BadgesService(mockRepo.Object, mockAppSvc.Object);

            //Act
            service.Award(entry.HubKey, entry.AppKey, entry.BadgeKey, entry.Username, entry.Level);

            //Assert            
            mockAppSvc.Verify(m => m.GetApp(It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.UpdateEntry(It.IsAny<BadgeEntry>()));
        }

        [TestMethod]
        public void BadgesServiceUnitTests_GetBadges_ShouldThrowsArgumentNullException()
        {
            //Arrange          
            var mockRepo = new Mock<IBadgesRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            var service = new BadgesService(mockRepo.Object, mockAppSvc.Object);
            // Invalid hubKey
            try
            {
                //Act
                service.GetBadges(null, "appKey", "username");
                //Assert         
                Assert.Fail("GetBadges should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetBadges should have thrown ArgumentNullException: hubKey");
            }
            // Invalid appKey
            try
            {
                //Act
                service.GetBadges("hubKey", null, "username");
                //Assert         
                Assert.Fail("GetBadges should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetBadges should have thrown ArgumentNullException: appKey");
            }         
            // Invalid username
            try
            {
                //Act
                service.GetBadges("hubKey", "appKey", null);
                //Assert         
                Assert.Fail("GetBadges should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetBadges should have thrown ArgumentNullException: username");
            }          
        }

        [TestMethod]
        public void BadgesServiceUnitTests_GetBadges_ShouldReturnsRecords()
        {
            //Arrange            
            var hubKey = "HUB_KEY;";
            var appKey = "APP_KEY;";
            var username = "USERNAME";
            var entry1 = new BadgeEntry { Id = 1, HubKey = hubKey, AppKey = appKey, BadgeKey = "badgeKey", Username = username, Level = "level1" };
            var entry2 = new BadgeEntry { Id = 2, HubKey = hubKey, AppKey = appKey, BadgeKey = "badgeKey", Username = username, Level = "level2" };
            var entry3 = new BadgeEntry { Id = 3, HubKey = hubKey, AppKey = appKey, BadgeKey = "badgeKey", Username = username, Level = "level3" };
            var entry4 = new BadgeEntry { Id = 4, HubKey = hubKey, AppKey = appKey, BadgeKey = "badgeKey", Username = username, Level = "level4" };
            var entry5 = new BadgeEntry { Id = 5, HubKey = hubKey, AppKey = appKey, BadgeKey = "badgeKey", Username = username, Level = "level5" };
            var entry6 = new BadgeEntry { Id = 5, HubKey = hubKey, AppKey = appKey, BadgeKey = "badgeKey", Username = "userX", Level = "level1" };
            var badges = new List<BadgeEntry>
            {
                entry1,
                entry2,
                entry3,
                entry4,
                entry5,
                entry6
            };
            
            var mockRepo = new Mock<IBadgesRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            mockRepo.Setup(m => m.GetEntries(hubKey, appKey, It.IsAny<string>(), username, It.IsAny<Guid>())).Returns(badges);
            
            var service = new BadgesService(mockRepo.Object, mockAppSvc.Object);
            //Act            
            var result = service.GetBadges(hubKey, appKey, username);         

            //Assert                             
            Assert.IsTrue(result != null & result.Count == 6, "6 records should have been returned.");

            mockRepo.Verify(m => m.GetEntries(hubKey, appKey, It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()));
        }

        [TestMethod]
        public void BadgesServiceUnitTests_RemoveBadge_ShouldThrowsArgumentNullException()
        {
            //Arrange          
            var mockRepo = new Mock<IBadgesRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            var service = new BadgesService(mockRepo.Object, mockAppSvc.Object);
            // Invalid hubKey
            try
            {
                //Act
                service.RemoveBadge(null, "appKey", "badgeKey", "username");
                //Assert         
                Assert.Fail("RemoveBadge should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("RemoveBadge should have thrown ArgumentNullException: hubKey");
            }
            // Invalid appKey
            try
            {
                //Act
                service.RemoveBadge("hubKey", null, "badgeKey", "username");
                //Assert         
                Assert.Fail("RemoveBadge should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("RemoveBadge should have thrown ArgumentNullException: appKey");
            }
            // Invalid badgeKey
            try
            {
                //Act
                service.RemoveBadge("hubKey", "appKey", null, "username");
                //Assert         
                Assert.Fail("RemoveBadge should have thrown ArgumentNullException: badgeKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("RemoveBadge should have thrown ArgumentNullException: badgeKey");
            }
            // Invalid username
            try
            {
                //Act
                service.RemoveBadge("hubKey", "appKey", "badgeKey", null);
                //Assert         
                Assert.Fail("RemoveBadge should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("RemoveBadge should have thrown ArgumentNullException: username");
            }           
        }

        [TestMethod]
        public void BadgesServiceUnitTests_RemoveBadge_ShouldRemovesBadge()
        {
            //Arrange            
            var hubKey = "HUB_KEY";
            var appKey = "APP_KEY";
            var badgeKey = "BADGE_KEY";
            var username = "USERNAME";
            var entry = new BadgeEntry { Id = 1, HubKey = hubKey, AppKey = appKey, BadgeKey = badgeKey, Username = username, Level = "level1" };                                    
            var mockRepo = new Mock<IBadgesRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            mockRepo.Setup(m => m.GetEntry(hubKey, appKey, badgeKey, username, It.IsAny<Guid>())).Returns(entry);
            mockRepo.Setup(m => m.DeleteEntry(hubKey, appKey, badgeKey, username, It.IsAny<Guid>()));

            var service = new BadgesService(mockRepo.Object, mockAppSvc.Object);
            //Act            
            service.RemoveBadge(hubKey, appKey, badgeKey, username);

            //Assert                                         
            mockRepo.Verify(m => m.GetEntry(hubKey, appKey, badgeKey, username, It.IsAny<Guid>()));
            mockRepo.Verify(m => m.DeleteEntry(hubKey, appKey, badgeKey, username, It.IsAny<Guid>()));
        }

        [TestMethod]
        public void BadgesServiceUnitTests_HasBadge_ShouldThrowsArgumentNullException()
        {
            //Arrange          
            var mockRepo = new Mock<IBadgesRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            var service = new BadgesService(mockRepo.Object, mockAppSvc.Object);
            // Invalid hubKey
            try
            {
                //Act
                service.HasBadge(null, "appKey", "badgeKey", "username");
                //Assert         
                Assert.Fail("HasBadge should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("HasBadge should have thrown ArgumentNullException: hubKey");
            }
            // Invalid appKey
            try
            {
                //Act
                service.HasBadge("hubKey", null, "badgeKey", "username");
                //Assert         
                Assert.Fail("HasBadge should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("HasBadge should have thrown ArgumentNullException: appKey");
            }
            // Invalid badgeKey
            try
            {
                //Act
                service.HasBadge("hubKey", "appKey", null, "username");
                //Assert         
                Assert.Fail("HasBadge should have thrown ArgumentNullException: badgeKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("HasBadge should have thrown ArgumentNullException: badgeKey");
            }
            // Invalid username
            try
            {
                //Act
                service.HasBadge("hubKey", "appKey", "badgeKey", null);
                //Assert         
                Assert.Fail("HasBadge should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("HasBadge should have thrown ArgumentNullException: username");
            }
        }

        [TestMethod]
        public void BadgesServiceUnitTests_HasBadge_ShouldReturnsTrue()
        {
            //Arrange            
            var hubKey = "HUB_KEY";
            var appKey = "APP_KEY";
            var badgeKey = "BADGE_KEY";
            var username = "USERNAME";
            var entry = new BadgeEntry { Id = 1, HubKey = hubKey, AppKey = appKey, BadgeKey = badgeKey, Username = username, Level = "level1" };
            var mockRepo = new Mock<IBadgesRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            mockRepo.Setup(m => m.GetEntry(hubKey, appKey, badgeKey, username, It.IsAny<Guid>())).Returns(entry);
            
            var service = new BadgesService(mockRepo.Object, mockAppSvc.Object);
            //Act            
            var result = service.HasBadge(hubKey, appKey, badgeKey, username);

            //Assert     
            Assert.IsTrue(result, "HasBadge should have been true");
            mockRepo.Verify(m => m.GetEntry(hubKey, appKey, badgeKey, username, It.IsAny<Guid>()));            
        }

        [TestMethod]
        public void BadgesServiceUnitTests_HasBadge_ShouldReturnsFalse()
        {
            //Arrange            
            var hubKey = "HUB_KEY";
            var appKey = "APP_KEY";
            var badgeKey = "BADGE_KEY";
            var username = "USERNAME";            
            var mockRepo = new Mock<IBadgesRepo>();
            var mockAppSvc = new Mock<IAppConfigService>();
            mockRepo.Setup(m => m.GetEntry(hubKey, appKey, badgeKey, username, It.IsAny<Guid>())).Returns(default(BadgeEntry));

            var service = new BadgesService(mockRepo.Object, mockAppSvc.Object);
            //Act            
            var result = service.HasBadge(hubKey, appKey, badgeKey, username);

            //Assert     
            Assert.IsFalse(result, "HasBadge should have been false");
            mockRepo.Verify(m => m.GetEntry(hubKey, appKey, badgeKey, username, It.IsAny<Guid>()));
        }
    }
}
