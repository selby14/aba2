﻿using Moq;
using System;
using FPIQ.Core.Repos;
using FPIQ.Core.Services;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using FPIQ.Entities;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class SettingsServiceUnitTests
    {
        [TestInitialize]
        public void Initialize()
        {
        }        

        [TestMethod]
        public void SettingsServiceUnitTests_GetSetting_ShouldThrowsArgumentNullExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<ISettingsRepo>();                                    
            var service = new SettingsService(mockRepo.Object);
            // Invalid settingKey
            try
            {
                //Act
                service.GetSetting(null, "hubKey");
                //Assert         
                Assert.Fail("GetSetting(null, \"hubKey\") should have been thrown ArgumentNullException: settingKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetSetting(null, \"hubKey\") should have been thrown ArgumentNullException: settingKey");
            }           
        }

        [TestMethod]
        public void SettingsServiceUnitTests_GetSetting_ShouldReturnsSetting()
        {
            //Arrange
            var settingType = "SETTING_TEST";
            var settingKey = "SETTING_KEY";            
            var setting = new Setting() { SettingKey = settingKey, SettingType = settingType };            
            var mockRepo = new Mock<ISettingsRepo>();            

            mockRepo.Setup(m => m.GetSetting(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(setting);
            
            var service = new SettingsService(mockRepo.Object);

            //Act
            var result = service.GetSetting(settingKey);

            //Assert
            Assert.IsNotNull(result);            
            mockRepo.Verify(m => m.GetSetting(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
        }     

        [TestMethod]
        public void SettingsServiceUnitTests_GetSettings_ShouldReturnsSettings()
        {
            //Arrange
            var hubKey  = "HUB_KEY";
            var settingType = "SETTING_TEST";
            var settingKey = "SETTING_KEY";
            var parentKey = "PARENT_KEY";
            var keyword = "";
            var setting = new Setting() { HubKey = hubKey, SettingKey = settingKey, SettingType = settingType, ParentKey = parentKey };
            var setting2 = new Setting() { HubKey = hubKey, SettingKey = Guid.NewGuid().ToString(), SettingType = settingType, ParentKey = parentKey };
            var setting3 = new Setting() { HubKey = hubKey, SettingKey = Guid.NewGuid().ToString(), SettingType = settingType, ParentKey = parentKey };
            var settingList = new List<Setting>
            {
                setting,
                setting2,
                setting3
            };

            var mockRepo = new Mock<ISettingsRepo>();    
            mockRepo.Setup(m => m.GetSettings(hubKey, keyword, It.IsAny<string>())).Returns(settingList);

            var service = new SettingsService(mockRepo.Object);

            //Act
            var result = service.GetSettings(keyword, hubKey);

            //Assert
            Assert.IsNotNull(result);            
            mockRepo.Verify(m => m.GetSettings(hubKey, keyword, It.IsAny<string>()));            
        }      
              
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SettingsServiceUnitTests_Upsert_ShouldReturnsAnException()
        {
            //Arrange            
            var mockRepo = new Mock<ISettingsRepo>();            
            var service = new SettingsService(mockRepo.Object);

            //Act
            service.Upsert(null, null);

            //Assert
        }

        [TestMethod]
        public void SettingsServiceUnitTests_Upsert_ShouldUpdatesExistingSetting()
        {
            //Arrange            
            var settingKey = "SETTING_KEY";
            var setting = new Setting() { SettingKey = settingKey, SettingType = Constants.SettingTypes.System };                       
            var mockRepo = new Mock<ISettingsRepo>();            
            mockRepo.Setup(m => m.GetSetting(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(setting);
            mockRepo.Setup(m => m.Update(It.IsAny<Setting>()));            
            
            var service = new SettingsService(mockRepo.Object);

            //Act
            service.Upsert(setting, "username");

            //Assert            
            mockRepo.Verify(m => m.GetSetting(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.Update(It.IsAny<Setting>()));                       
        }
             
        [TestMethod]
        public void SettingsServiceUnitTests_Upsert_ShouldAddsNewSetting()
        {            
            //Arrange
            var settingKey = "CLIENT_KEY";
            var setting = new Setting() { SettingKey = settingKey, SettingType = Constants.SettingTypes.System };
            var sList = new List<Setting>();
            var mockRepo = new Mock<ISettingsRepo>();             
            var service = new SettingsService(mockRepo.Object);
            mockRepo.Setup(m => m.GetSetting(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(default(Setting));
            mockRepo.Setup(m => m.Add(It.IsAny<Setting>()));

            //Act
            service.Upsert(setting, "username");

            //Assert            
            mockRepo.Verify(m => m.Add(It.IsAny<Setting>()));            
        }

        [TestMethod]     
        public void SettingsServiceUnitTests_UpdateSettingValue_ShouldReturnsArgumentNullException()
        {           
            
            //Arrange            
            var mockRepo = new Mock<ISettingsRepo>();
            var service = new SettingsService(mockRepo.Object);
            // Invalid username
            try
            {
                //Act
                service.UpdateValue(null, "settingKey", "new-value");
                //Assert         
                Assert.Fail("UpdateValue should have been thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("UpdateValue should have been thrown ArgumentNullException: username");
            }
            // Invalid settingKey
            try
            {
                //Act
                service.UpdateValue("username", null, "new-value");
                //Assert         
                Assert.Fail("UpdateValue should have been thrown ArgumentNullException: settingKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("UpdateValue should have been thrown ArgumentNullException: settingKey");
            }
        }

        [TestMethod]        
        public void SettingsServiceUnitTests_UpdateSettingValue_ShouldUpdatesValue()
        {
            //Arrange            
            var mockRepo = new Mock<ISettingsRepo>();
            var service = new SettingsService(mockRepo.Object);
            var setting = new Setting() { SettingKey = "settingKey", SettingType = "settingType" };
            mockRepo.Setup(m => m.GetSetting(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(setting);
            mockRepo.Setup(m => m.Update(It.IsAny<Setting>()));

            //Act
            service.UpdateValue("username", setting.SettingKey, "new-value");

            //Assert   
            mockRepo.Verify(m => m.GetSetting(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.Update(It.IsAny<Setting>()));
        }       

        [TestMethod]
        public void SettingsServiceUnitTests_DeleteSetting_ShouldDeleteSetting()
        {
            //Arrange            
            var mockRepo = new Mock<ISettingsRepo>();
            var setting = new Setting() { SettingKey = "settingKey", SettingType = "settingType" };
            mockRepo.Setup(m => m.GetSetting(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>())).Returns(setting);
            mockRepo.Setup(m => m.Delete(It.IsAny<int>()));                      

            var service = new SettingsService(mockRepo.Object);

            //Act
            service.Delete("settingKey", "");

            //Assert
            mockRepo.Verify(m => m.Delete(It.IsAny<int>()));            
        }

        [TestMethod]        
        public void SettingsServiceUnitTests_DeleteSetting_ShouldNotDeleteSetting()
        {
            //Arrange            
            var mockRepo = new Mock<ISettingsRepo>();
            mockRepo.Setup(m => m.Delete(It.IsAny<int>()));
            var service = new SettingsService(mockRepo.Object);

            //Act
            service.Delete("settingKey");

            //Assert
            mockRepo.Verify(m => m.Delete(It.IsAny<int>()), Times.Never);
        }
    }
}
