﻿using FPIQ.Core.Repos;
using FPIQ.Core.Services;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class CreditServiceUnitTests
    {
        [TestInitialize]
        public void Initialize()
        {
        }

        [TestMethod]        
        public void CreditServiceUnitTests_GetCreditStatus_ShouldThrowsArgumentNullExceptions()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();            
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);
            // Invalid hubKey
            try
            {
                //Act
                service.GetCreditStatus(null, "appKey", "username", Guid.NewGuid());
                //Assert         
                Assert.Fail("GetCreditStatus should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetCreditStatus should have thrown ArgumentNullException: hubKey");
            }
            // Invalid appKey
            try
            {
                //Act
                service.GetCreditStatus("hubKey", null, "username", Guid.NewGuid());
                //Assert         
                Assert.Fail("GetCreditStatus should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetCreditStatus should have thrown ArgumentNullException: appKey");
            }          
            // Invalid username
            try
            {
                //Act
                service.GetCreditStatus("hubKey", "appKey", null, Guid.NewGuid());
                //Assert         
                Assert.Fail("GetCreditStatus should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetCreditStatus should have thrown ArgumentNullException: username");
            }           
        }

        [TestMethod]
        public void CreditServiceUnitTests_GetCreditStatus_ShouldReturnsCreditStatus()
        {
            //Arrange                      
            var credit = new Credit { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", Username = "username", SessionId = Guid.NewGuid(), CreditConfigId = 1, CertKey = "CertKey", CreditCount = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetCredit(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>())).Returns(credit);

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            var result = service.GetCreditStatus(credit.HubKey, credit.AppKey, credit.Username, credit.SessionId);

            //Assert         
            Assert.IsNotNull(result);
            mockRepo.Verify(m => m.GetCredit(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()));
        }

        [TestMethod]
        public void CreditServiceUnitTests_Upsert_ShouldThrowsArgumentNullExceptions()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);
            var credit = new Credit();
            // Invalid credit            
            try
            {
                //Act
                service.Upsert(null, "username");
                //Assert         
                Assert.Fail("Upsert should have thrown ArgumentNullException: credit");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Upsert should have thrown ArgumentNullException: credit");
            }
            // Invalid username
            try
            {
                credit = new Credit { ContentId = 8, Username = "username", CreditConfigId = 1, CertKey = "CertKey", CreditCount = 1 };
                //Act
                service.Upsert(credit, null);
                //Assert         
                Assert.Fail("Upsert should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Upsert should have thrown ArgumentNullException: username");
            }          
        }

        [TestMethod]
        public void CreditServiceUnitTests_Upsert_ShouldAddsCredit()
        {
            //Arrange          
            var credit = new Credit { ContentId = 8, Username = "username", CreditConfigId = 1, CertKey = "CertKey", CreditCount = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetCredit(It.IsAny<long>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>())).Returns(default(Credit));
            mockRepo.Setup(m => m.Add(It.IsAny<Credit>()));

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);
                        
            //Act
            service.Upsert(credit, "username");

            //Assert         
            mockRepo.Verify(m => m.GetCredit(It.IsAny<long>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()));
            mockRepo.Verify(m => m.Add(It.IsAny<Credit>()));
        }

        [TestMethod]
        public void CreditServiceUnitTests_Upsert_ShouldUpdatesCredit()
        {
            //Arrange          
            var credit = new Credit { ContentId = 8, Username = "username", SessionId = Guid.NewGuid(), CreditConfigId = 1, CAKey = "CAKey", CertKey= "CertKey", CreditCount = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetCredit(It.IsAny<long>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>())).Returns(credit);
            mockRepo.Setup(m => m.Update(credit));

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.Upsert(credit, "username");

            //Assert         
            mockRepo.Verify(m => m.GetCredit(It.IsAny<long>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()));
            mockRepo.Verify(m => m.Update(credit));
        }

        [TestMethod]
        public void CreditServiceUnitTests_Add_ShouldThrowsExceptions()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);
            // Invalid hubKey
            try
            {
                //Act
                service.Add(null, "appKey", Guid.NewGuid(), "username", 1);
                //Assert         
                Assert.Fail("Add should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Add should have thrown ArgumentNullException: hubKey");
            }
            // Invalid appKey
            try
            {
                //Act
                service.Add("hubKey", null, Guid.NewGuid(), "username", 1);
                //Assert         
                Assert.Fail("Add should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Add should have thrown ArgumentNullException: appKey");
            }
            // Invalid sessionId
            try
            {
                //Act
                service.Add("hubKey", "appKey", Guid.Empty, "username", 1);
                //Assert         
                Assert.Fail("Add should have thrown ArgumentNullException: sessionId");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Add should have thrown ArgumentNullException: sessionId");
            }
            // Invalid username
            try
            {
                //Act
                service.Add("hubKey", "appKey", Guid.NewGuid(), null, 1);
                //Assert         
                Assert.Fail("Add should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("Add should have thrown ArgumentNullException: username");
            }
            // Invalid creditConfigId
            try
            {
                //Act
                service.Add("hubKey", "appKey", Guid.NewGuid(), "username", 0);
                //Assert         
                Assert.Fail("Add should have thrown ArgumentOutOfRangeException: creditConfigId");
            }
            catch (ArgumentOutOfRangeException) { }
            catch (Exception)
            {
                Assert.Fail("Add should have thrown ArgumentOutOfRangeException: creditConfigId");
            }
        }

        [TestMethod]
        public void CreditServiceUnitTests_GetCredit_ShouldThrowsExceptions()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);
            // Invalid hubKey
            try
            {
                //Act
                service.GetCredit(null, "appKey", "username", Guid.NewGuid());
                //Assert         
                Assert.Fail("GetCredit should have thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetCredit should have thrown ArgumentNullException: hubKey");
            }
            // Invalid appKey
            try
            {
                //Act
                service.GetCredit("hubKey", null, "username", Guid.NewGuid());
                //Assert         
                Assert.Fail("GetCredit should have thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetCredit should have thrown ArgumentNullException: appKey");
            }         
            // Invalid username
            try
            {
                //Act
                service.GetCredit("hubKey", "appKey", null, Guid.NewGuid());
                //Assert         
                Assert.Fail("GetCredit should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetCredit should have thrown ArgumentNullException: username");
            }         
        }

        [TestMethod]
        public void CreditServiceUnitTests_GetCredit_ShouldReturnsCredit()
        {
            //Arrange                      
            var credit = new Credit { ContentId = 8, HubKey= "hubKey", AppKey = "appKey", Username = "username", SessionId = Guid.NewGuid(), CreditConfigId = 1, CertKey = "CertKey", CreditCount = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetCredit(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>())).Returns(credit);

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            var result = service.GetCredit(credit.HubKey, credit.AppKey, credit.Username, credit.SessionId);

            //Assert         
            Assert.AreEqual(credit, result);
            mockRepo.Verify(m => m.GetCredit(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreditServiceUnitTests_GetCredits_ShouldThrowsArgumentNullException()
        {                   
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.GetCredits(null);
        }

        [TestMethod]
        public void CreditServiceUnitTests_GetCredits_ShouldReturnsCredits()
        {
            //Arrange          
            var credits = new List<Credit> {
                 new Credit { ContentId = 8, Username = "username", CreditConfigId = 1, CertKey = "CertKey", CreditCount = 1 },
                 new Credit { ContentId = 8, Username = "username2", CreditConfigId = 1, CertKey = "CertKey", CreditCount = 1 }                 
            };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetCredits(It.IsAny<string>(), It.IsAny<string>())).Returns(credits);            

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            var result = service.GetCredits("hubKey");

            //Assert         
            Assert.AreEqual(credits, result);
            mockRepo.Verify(m => m.GetCredits(It.IsAny<string>(), It.IsAny<string>()));            
        }

        #region " Evals "

        [TestMethod]
        public void CreditServiceUnitTests_UpsertEval_ShouldThrowsArgumentNullExceptions()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);
            var eval = new UserEval();
            // Invalid eval            
            try
            {
                //Act
                service.UpsertEval(null, "username");
                //Assert         
                Assert.Fail("UpsertEval should have thrown ArgumentNullException: eval");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("UpsertEval should have thrown ArgumentNullException: eval");
            }
            // Invalid username
            try
            {
                eval = new UserEval { ContentId = 8, HubKey="hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 };
                //Act
                service.UpsertEval(eval, null);
                //Assert         
                Assert.Fail("UpsertEval should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("UpsertEval should have thrown ArgumentNullException: username");
            }
        }

        [TestMethod]
        public void CreditServiceUnitTests_UpsertEval_ShouldAddsEval()
        {
            //Arrange                      
            var eval = new UserEval { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetEval(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>())).Returns(default(UserEval));
            mockRepo.Setup(m => m.AddEval(It.IsAny<UserEval>()));

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.UpsertEval(eval, "username");

            //Assert         
            mockRepo.Verify(m => m.GetEval(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()));
            mockRepo.Verify(m => m.AddEval(It.IsAny<UserEval>()));
        }

        [TestMethod]
        public void CreditServiceUnitTests_UpsertEval_ShouldUpdatesEval()
        {
            //Arrange          
            var eval = new UserEval { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetEval(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>())).Returns(eval);
            mockRepo.Setup(m => m.UpdateEval(eval));

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.UpsertEval(eval, "username");

            //Assert         
            mockRepo.Verify(m => m.GetEval(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()));
            mockRepo.Verify(m => m.UpdateEval(eval));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void CreditServiceUnitTests_GetEval_ShouldThrowsArgumentOutOfRangeException()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.GetEval(0);
        }

        [TestMethod]
        public void CreditServiceUnitTests_GetEval_ShouldReturnsEval()
        {
            //Arrange          
            var eval = new UserEval { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetEval(It.IsAny<int>())).Returns(eval);
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            var result = service.GetEval(8);

            //Assert         
            Assert.AreEqual(eval, result);
            mockRepo.Verify(m => m.GetEval(It.IsAny<int>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreditServiceUnitTests_GetEvals_ShouldThrowsArgumentNullException()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.GetEvals(null, string.Empty);
        }

        [TestMethod]
        public void CreditServiceUnitTests_GetEvals_ShouldReturnsEvals()
        {
            //Arrange          
            var evals = new List<UserEval> {
                new UserEval { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 },
                new UserEval { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 }
            };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetEvals(It.IsAny<string>(), It.IsAny<string>())).Returns(evals);

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            var result = service.GetEvals("hubKey", string.Empty);

            //Assert         
            Assert.AreEqual(evals, result);
            mockRepo.Verify(m => m.GetEvals(It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        public void CreditServiceUnitTests_GetEvalsByContentIds_ShouldReturnsEvals()
        {
            //Arrange          
            var evals = new List<UserEval> {
                new UserEval { ContentId = 1, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 },
                new UserEval { ContentId = 2, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 }
            };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetEvals(1, 2)).Returns(evals);

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            var result = service.GetEvals(1, 2);

            //Assert         
            Assert.AreEqual(evals, result);
            mockRepo.Verify(m => m.GetEvals(1, 2));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void CreditServiceUnitTests_DeleteEval_ShouldThrowsArgumentOutOfRangeException()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.DeleteEval(0);
        }

        [TestMethod]
        public void CreditServiceUnitTests_DeleteEval_ShouldDeletesEval()
        {
            //Arrange          
            var eval = new UserEval { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetEval(It.IsAny<int>())).Returns(eval);
            mockRepo.Setup(m => m.DeleteEval(It.IsAny<int>()));
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.DeleteEval(8);

            //Assert                     
            mockRepo.Verify(m => m.GetEval(It.IsAny<int>()));
            mockRepo.Verify(m => m.DeleteEval(It.IsAny<int>()));
        }

        [TestMethod]
        public void CreditServiceUnitTests_DeleteEval_ShouldNotDeletesEval()
        {
            //Arrange                      
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetEval(It.IsAny<int>())).Returns(default(UserEval));
            mockRepo.Setup(m => m.DeleteEval(It.IsAny<int>()));
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.DeleteEval(8);

            //Assert         
            mockRepo.Verify(m => m.GetEval(It.IsAny<int>()));
            mockRepo.Verify(m => m.DeleteEval(It.IsAny<int>()), Times.Never);
        }

        #endregion

        #region " Tests "

        [TestMethod]
        public void CreditServiceUnitTests_UpsertTest_ShouldThrowsArgumentNullExceptions()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);
            var test = new UserTest();
            // Invalid eval            
            try
            {
                //Act
                service.UpsertTest(null, "username");
                //Assert         
                Assert.Fail("UpsertTest should have thrown ArgumentNullException: eval");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("UpsertTest should have thrown ArgumentNullException: eval");
            }
            // Invalid username
            try
            {
                test = new UserTest { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 };
                //Act
                service.UpsertTest(test, null);
                //Assert         
                Assert.Fail("UpsertTest should have thrown ArgumentNullException: username");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("UpsertTest should have thrown ArgumentNullException: username");
            }
        }

        [TestMethod]
        public void CreditServiceUnitTests_UpsertTest_ShouldAddsTest()
        {
            //Arrange                      
            var test = new UserTest { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetTest(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>())).Returns(default(UserTest));
            mockRepo.Setup(m => m.AddTest(It.IsAny<UserTest>()));

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.UpsertTest(test, "username");

            //Assert         
            mockRepo.Verify(m => m.GetTest(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()));
            mockRepo.Verify(m => m.AddTest(It.IsAny<UserTest>()));
        }

        [TestMethod]
        public void CreditServiceUnitTests_UpsertTest_ShouldUpdatesTest()
        {
            //Arrange          
            var test = new UserTest { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetTest(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>())).Returns(test);
            mockRepo.Setup(m => m.UpdateTest(test));

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.UpsertTest(test, "username");

            //Assert         
            mockRepo.Verify(m => m.GetTest(It.IsAny<string>(), It.IsAny<string>(), It.IsAny<string>(), It.IsAny<Guid>()));
            mockRepo.Verify(m => m.UpdateTest(test));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void CreditServiceUnitTests_GetTest_ShouldThrowsArgumentOutOfRangeException()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.GetTest(0);
        }

        [TestMethod]
        public void CreditServiceUnitTests_GetTest_ShouldReturnsTest()
        {
            //Arrange          
            var test = new UserTest { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetTest(It.IsAny<int>())).Returns(test);
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            var result = service.GetTest(8);

            //Assert         
            Assert.AreEqual(test, result);
            mockRepo.Verify(m => m.GetTest(It.IsAny<int>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void CreditServiceUnitTests_GetTests_ShouldThrowsArgumentNullException()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.GetTests(null, string.Empty);
        }

        [TestMethod]
        public void CreditServiceUnitTests_GetTests_ShouldReturnsTests()
        {
            //Arrange          
            var tests = new List<UserTest> {
                new UserTest { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 },
                new UserTest { ContentId = 8, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 }
            };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetTests(It.IsAny<string>(), It.IsAny<string>())).Returns(tests);

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            var result = service.GetTests("hubKey", string.Empty);

            //Assert         
            Assert.AreEqual(tests, result);
            mockRepo.Verify(m => m.GetTests(It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        public void CreditServiceUnitTests_GetTestsByContentIds_ShouldReturnsTests()
        {
            //Arrange          
            var tests = new List<UserTest> {
                new UserTest { ContentId = 1, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 },
                new UserTest { ContentId = 2, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 }
            };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetTests(1, 2)).Returns(tests);

            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            var result = service.GetTests(1, 2);

            //Assert         
            Assert.AreEqual(tests, result);
            mockRepo.Verify(m => m.GetTests(1, 2));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void CreditServiceUnitTests_DeleteTest_ShouldThrowsArgumentOutOfRangeException()
        {
            //Arrange          
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.DeleteTest(0);
        }

        [TestMethod]
        public void CreditServiceUnitTests_DeleteTest_ShouldDeletesTest()
        {
            //Arrange          
            var test = new UserTest { ContentId = 2, HubKey = "hubKey", AppKey = "appKey", SessionId = Guid.NewGuid(), Username = "username", CreditConfigId = 1 };
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetTest(It.IsAny<int>())).Returns(test);
            mockRepo.Setup(m => m.DeleteTest(It.IsAny<int>()));
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.DeleteTest(8);

            //Assert                     
            mockRepo.Verify(m => m.GetTest(It.IsAny<int>()));
            mockRepo.Verify(m => m.DeleteTest(It.IsAny<int>()));
        }

        [TestMethod]
        public void CreditServiceUnitTests_DeleteTest_ShouldNotDeletesTest()
        {
            //Arrange                      
            var mockRepo = new Mock<ICreditsRepo>();
            var mockCreditConfigSvc = new Mock<ICreditConfigService>();
            var mockContentSvc = new Mock<IContentService>();
            mockRepo.Setup(m => m.GetTest(It.IsAny<int>())).Returns(default(UserTest));
            mockRepo.Setup(m => m.DeleteTest(It.IsAny<int>()));
            var service = new CreditsService(mockRepo.Object, mockCreditConfigSvc.Object, mockContentSvc.Object);

            //Act
            service.DeleteTest(8);

            //Assert         
            mockRepo.Verify(m => m.GetTest(It.IsAny<int>()));
            mockRepo.Verify(m => m.DeleteTest(It.IsAny<int>()), Times.Never);
        }

        #endregion
    }
}
