﻿using Moq;
using System;
using FPIQ.Core.Repos;
using FPIQ.Core.Services;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class HubsServiceUnitTests
    {
        [TestInitialize]
        public void Initialize()
        {
        }        

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void HubsServiceUnitTests_GetHub_ShouldThrowsArgumentNullExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<IHubsRepo>();                                    
            var service = new HubsService(mockRepo.Object);
            
            //Act
            service.GetHub(null);            
        }

        [TestMethod]
        public void HubsServiceUnitTests_GetHub_ShouldReturnsHub()
        {
            //Arrange            
            var hubKey = "HUB_KEY";            
            var hub = new HubInfo { HubKey = hubKey, HubName = "Hub Name", ManifestUrl = "manifest url" };            
            var mockRepo = new Mock<IHubsRepo>();            
            mockRepo.Setup(m => m.GetHub( It.IsAny<string>())).Returns(hub);
            
            var service = new HubsService(mockRepo.Object);

            //Act
            var result = service.GetHub(hubKey);

            //Assert
            Assert.IsNotNull(result);            
            mockRepo.Verify(m => m.GetHub(It.IsAny<string>()));
        }     

        [TestMethod]
        public void HubsServiceUnitTests_GetHubs_ShouldReturnsHubs()
        {
            //Arrange            
            var keyword = "";                        
            var hubs = new List<HubInfo>
            {
                 new HubInfo { HubKey = "hubKey1", HubName = "Hub Name 1", ManifestUrl = "manifest url 1"},
                 new HubInfo { HubKey = "hubKey2", HubName = "Hub Name 2", ManifestUrl = "manifest url 2" },
                 new HubInfo { HubKey = "hubKey3", HubName = "Hub Name 3", ManifestUrl = "manifest url 3" }
            };

            var mockRepo = new Mock<IHubsRepo>();    
            mockRepo.Setup(m => m.GetHubs(keyword)).Returns(hubs);
            var service = new HubsService(mockRepo.Object);

            //Act
            var result = service.GetHubs(keyword);

            //Assert
            Assert.IsNotNull(result);            
            mockRepo.Verify(m => m.GetHubs(keyword));            
        }      
              
        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void HubsServiceUnitTests_Upsert_ShouldReturnsAnException_InvalidHubInfo()
        {
            //Arrange            
            var mockRepo = new Mock<IHubsRepo>();            
            var service = new HubsService(mockRepo.Object);

            //Act
            service.Upsert(null, null);            
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void HubsServiceUnitTests_Upsert_ShouldReturnsAnException_InvalidUsername()
        {
            //Arrange            
            var hub = new HubInfo { HubKey = "hubKey", HubName = "Hub Name", ManifestUrl = "manifest url" };
            var mockRepo = new Mock<IHubsRepo>();
            var service = new HubsService(mockRepo.Object);
            //Act
            service.Upsert(hub, null);

            //Assert
        }

        [TestMethod]
        public void HubsServiceUnitTests_Upsert_ShouldUpdatesExistingHub()
        {
            //Arrange            
            var hubKey = "HUB_KEY";
            var hub = new HubInfo { HubKey = hubKey, HubName = "Hub Name", ManifestUrl = "manifest url" };
            var mockRepo = new Mock<IHubsRepo>();            
            mockRepo.Setup(m => m.GetHub(It.IsAny<string>())).Returns(hub);
            mockRepo.Setup(m => m.Update(It.IsAny<HubInfo>()));            
            
            var service = new HubsService(mockRepo.Object);

            //Act
            service.Upsert(hub, "username");

            //Assert            
            mockRepo.Verify(m => m.GetHub(It.IsAny<string>()));
            mockRepo.Verify(m => m.Update(It.IsAny<HubInfo>()));                       
        }
             
        [TestMethod]
        public void HubsServiceUnitTests_Upsert_ShouldAddsNewHub()
        {
            //Arrange
            var hubKey = "HUB_KEY";
            var hub = new HubInfo { HubKey = hubKey, HubName = "Hub Name", ManifestUrl = "manifest url" };
            var sList = new List<HubInfo>();
            var mockRepo = new Mock<IHubsRepo>();             
            var service = new HubsService(mockRepo.Object);
            mockRepo.Setup(m => m.GetHub(It.IsAny<string>())).Returns(default(HubInfo));
            mockRepo.Setup(m => m.Add(It.IsAny<HubInfo>()));

            //Act
            service.Upsert(hub, "username");

            //Assert            
            mockRepo.Verify(m => m.Add(It.IsAny<HubInfo>()));            
        }      

        [TestMethod]
        public void HubsServiceUnitTests_DeleteHub_ShouldDeleteHub()
        {
            //Arrange            
            var hubKey = "HUB_KEY";
            var hub = new HubInfo { HubKey = hubKey, HubName = "Hub Name", ManifestUrl = "manifest url" };
            var mockRepo = new Mock<IHubsRepo>();
            mockRepo.Setup(m => m.GetHub(It.IsAny<string>())).Returns(hub);
            mockRepo.Setup(m => m.Delete(It.IsAny<int>()));                      
            var service = new HubsService(mockRepo.Object);

            //Act
            service.Delete(hubKey);

            //Assert
            mockRepo.Verify(m => m.Delete(It.IsAny<int>()));            
        }

        [TestMethod]        
        public void HubsServiceUnitTests_DeleteHub_ShouldNotDeleteHub()
        {
            //Arrange            
            var mockRepo = new Mock<IHubsRepo>();
            mockRepo.Setup(m => m.GetHub(It.IsAny<string>())).Returns(default(HubInfo));
            var service = new HubsService(mockRepo.Object);

            //Act
            service.Delete("hubKey");

            //Assert
            mockRepo.Verify(m => m.Delete(It.IsAny<string>()), Times.Never);
        }
    }
}
