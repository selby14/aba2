﻿using Bigfoot.Utils.Extensions;
using FPIQ.Core.Services;
using FPIQ.DNN.Repos;
using FPIQ.Entities;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class DnnUrlRepoUnitTests
    {
        private string url = "http://localhost.com/blah";
        private UrlParamCollection upc = new UrlParamCollection
        {
            Data = new List<UrlParam> {
                    new UrlParam {Key = "key1", Value = "value1" },
                    new UrlParam {Key = "key2", Value = "value2" },
                    new UrlParam {Key = "key3", Value = "value3" }
                }
        };

        [TestInitialize]
        public void Initialize()
        {
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DnnUrlRepoUnitTests_GetClientUrl_ShouldThrowsArgumentNullException()
        {
            //Arrange            
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);

            //Act
            repo.GetClientUrl(null);    
        }

        [TestMethod]
        public void DnnUrlRepoUnitTests_GetClientUrl_ShouldReturnsUrl()
        {
            //Arrange                      
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);

            //Act
            var result = repo.GetClientUrl("http://localhost.com/blah", upc);

            //Assert         
            Assert.IsFalse(result.IsNullOrEmpty(), "'result' should have been not null or empty");
        }

        [TestMethod]        
        public void DnnUrlRepoUnitTests_GetClientUrlWithHubKeyAndAppKey_ShouldThrowsArgumentNullException()
        {
            //Arrange      
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);
            // Invalid url
            try
            {
                //Act                
                repo.GetClientUrl(null, "hubKey", "appKey");

                //Assert         
                Assert.Fail("GetClientUrl should have been thrown ArgumentNullException: url");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetClientUrl should have been thrown ArgumentNullException: url");
            }
            // Invalid hubKey
            try
            {
                //Act                
                repo.GetClientUrl(url, null, "appKey");

                //Assert         
                Assert.Fail("GetClientUrl should have been thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetClientUrl should have been thrown ArgumentNullException: hubKey");
            }
            // Invalid appKey
            try
            {
                //Act                
                repo.GetClientUrl(url, "hubKey", null);

                //Assert         
                Assert.Fail("GetClientUrl should have been thrown ArgumentNullException: appKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetClientUrl should have been thrown ArgumentNullException: appKey");
            }
        }

        [TestMethod]
        public void DnnUrlRepoUnitTests_GetClientUrlWithHubKeyAndAppKey_ShouldReturnsUrl()
        {
            //Arrange                       
            var app = new AppManifest
            {
                SchemaVersion = "1.0.0",
                AppType = "LandingPageApp",
                AppKey = "app1",
                AppVersion = "1.0.0",
                Title = "Test App",
                Description = "App description",
                GameBrowser = new GameBrowserManifest {
                    BasePath = "http://localhost"                    
                },
                Gamification = new GamificationManifest
                {
                    Badges = new List<BadgeInfo>(),                   
                    Leaderboards = new List<Leaderboard>()
                }
            };
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);

            appConfigSvc.Setup(m => m.GetApp(It.IsAny<string>(), It.IsAny<string>())).Returns(app);            

            //Act
            var result = repo.GetClientUrl("@base_app_path/blah", "hubKey", "appKey", upc);

            //Assert         
            Assert.IsFalse(result.IsNullOrEmpty(), "'result' should have been not null or empty");
            Assert.IsTrue(result.StartsWith(app.GameBrowser.BasePath), $"'result' should have been starts with {app.GameBrowser.BasePath}");

            appConfigSvc.Verify(m => m.GetApp(It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DnnUrlRepoUnitTests_GetModuleUrl_ShouldThrowsArgumentNullException()
        {
            //Arrange            
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);            
            
            //Act                
            repo.GetModuleUrl(null);            
        }

        [TestMethod]
        public void DnnUrlRepoUnitTests_GetModuleUrl_ShouldReturnsUrl()
        {
            //Arrange            
            var hubKey = "HUB_KEY";
            var settingValue = url;
            var moduleName = "mduleName";
            var upc = new UrlParamCollection
            {
                Data = new List<UrlParam> {
                    new UrlParam { Key = "key1", Value = "value1" },
                    new UrlParam { Key = "key2", Value = "value2" },
                    new UrlParam { Key = "key3", Value = "value3" }
                }
            };
            var setting = new Setting { HubKey = hubKey, SettingKey = "settingKey", SettingType = Constants.SettingTypes.System };
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);

            settingsSvc.Setup(m => m.GetSettingValue(It.IsAny<string>(), It.IsAny<string>())).Returns(settingValue);

            //Act
            var result = repo.GetModuleUrl(moduleName, upc);

            //Assert         
            Assert.IsFalse(result.IsNullOrEmpty(), "'result' should have been not null or empty");
            settingsSvc.Verify(m => m.GetSettingValue(It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]        
        public void DnnUrlRepoUnitTests_GetModuleUrl_WithHubKey_ShouldThrowsArgumentNullException()
        {
            //Arrange            
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);
            // Invalid moduleName
            try
            {
                //Act                
                repo.GetModuleUrl(null, "hubKey");

                //Assert         
                Assert.Fail("GetModuleUrl should have been thrown ArgumentNullException: moduleName");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetModuleUrl should have been thrown ArgumentNullException: moduleName");
            }
            // Invalid hubKey
            try
            {
                //Act                
                repo.GetModuleUrl(url, null);

                //Assert         
                Assert.Fail("GetModuleUrl should have been thrown ArgumentNullException: hubKey");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetModuleUrl should have been thrown ArgumentNullException: hubKey");
            }
        }

        [TestMethod]
        public void DnnUrlRepoUnitTests_GetModuleUrl_WithHubKey_ShouldReturnsUrl()
        {
            //Arrange            
            var hubKey = "HUB_KEY";
            var settingValue = url;
            var moduleName = "mduleName";
            var upc = new UrlParamCollection
            {
                Data = new List<UrlParam> {
                    new UrlParam { Key = "key1", Value = "value1" },
                    new UrlParam { Key = "key2", Value = "value2" },
                    new UrlParam { Key = "key3", Value = "value3" }
                }
            };
            var setting = new Setting { HubKey = hubKey, SettingKey = "settingKey", SettingType = Constants.SettingTypes.System };
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);

            settingsSvc.Setup(m => m.GetSettingValue(It.IsAny<string>(), It.IsAny<string>())).Returns(settingValue);

            //Act
            var result = repo.GetModuleUrl(moduleName, hubKey, upc);

            //Assert         
            Assert.IsFalse(result.IsNullOrEmpty(), "'result' should have been not null or empty");
            settingsSvc.Verify(m => m.GetSettingValue(It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void DnnUrlRepoUnitTests_ParamsToQueryString_ShouldThrowsArgumentNullException()
        {
            //Arrange            
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);

            //Act
            repo.ParamsToQueryString(null);
        }

        [TestMethod]
        public void DnnUrlRepoUnitTests_ParamsToQueryString_ShouldReturnsQueryString()
        {
            //Arrange                       
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);
                        
            //Act
            var result = repo.ParamsToQueryString(upc);

            //Assert         
            Assert.IsFalse(result.IsNullOrEmpty(), "'result' should have been not null or empty");
            Assert.IsTrue(result.Contains("key1=value1"), "'result' should contains 'key1=value1'");
        }

        [TestMethod]
        public void DnnUrlRepoUnitTests_ParamsToQueryString_ShouldReturnsSingleQueryString()
        {
            //Arrange
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);
            upc.SingleParam = true;

            //Act
            var result = repo.ParamsToQueryString(upc);

            //Assert         
            Assert.IsFalse(result.IsNullOrEmpty(), "'result' should have been not null or empty");
            Assert.IsTrue(result.StartsWith("fdiqparams"), "'result' should have been started with 'fdiqparams'");
        }

        [TestMethod]
        public void DnnUrlRepoUnitTests_ParamsToQueryString_ShouldReturnsSingleEncryptedQueryString()
        {
            //Arrange
            var appConfigSvc = new Mock<IAppConfigService>();
            var serializer = new Mock<ISerializationService>();
            var settingsSvc = new Mock<ISettingsService>();
            var repo = new DNNUrlRepo(appConfigSvc.Object, serializer.Object, settingsSvc.Object);
            serializer.Setup(m => m.JsonSerialize(It.IsAny<object>())).Returns(JsonConvert.SerializeObject(upc.Data));
            upc.SingleParam = true;
            upc.Encrypt = true;

            //Act
            var result = repo.ParamsToQueryString(upc);

            //Assert         
            Assert.IsFalse(result.IsNullOrEmpty(), "'result' should have been not null or empty");
            Assert.IsTrue(result.StartsWith("fdiqsecparams"), "'result' should have been started with 'fdiqparams'");
            serializer.Verify(m => m.JsonSerialize(It.IsAny<object>()));
        }
    }
}
