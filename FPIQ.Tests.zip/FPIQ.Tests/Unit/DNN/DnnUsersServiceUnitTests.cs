﻿using FPIQ.Core.Repos;
using FPIQ.DNN.Services;
using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using System.Collections.Generic;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class DnnUsersServiceUnitTests
    {
        [TestInitialize]
        public void Initialize()
        {
        }

        [TestMethod]
        public void DnnUsersServiceUnitTests_GetProfileData_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<IUsersRepo>();
            var service = new DNNUsersService(mockRepo.Object);          
            // Invalid username
            try
            {
                //Act                
                service.GetProfileData(null, "key");

                //Assert         
                Assert.Fail("GetProfileData(null, \"key\") should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetProfileData(null, \"key\") should have been thrown ArgumentNullException.");
            }
            // Invalid key
            try
            {
                //Act                
                service.GetProfileData("username", null);

                //Assert         
                Assert.Fail("GetProfileData(\"username\", null) should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetProfileData(\"username\", null) should have been thrown ArgumentNullException.");
            }
        }

        [TestMethod]
        public void DnnUsersServiceUnitTests_GetProfileData_ShouldReturnsProfileData()
        {
            //Arrange            
            var mockRepo = new Mock<IUsersRepo>();
            var profileData = new UserProfileItem { Value = "value", Key = "key", Username = "username" };
            mockRepo.Setup(m => m.GetUserProfile(It.IsAny<string>(), It.IsAny<string>())).Returns(profileData);

            var service = new DNNUsersService(mockRepo.Object);

            //Act
            var result = service.GetProfileData("username", "key");

            //Assert         
            Assert.AreEqual(profileData, result);
            mockRepo.Verify(m => m.GetUserProfile(It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        public void DnnUsersServiceUnitTests_GetProfileValue_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<IUsersRepo>();
            var service = new DNNUsersService(mockRepo.Object);            
            // Invalid username
            try
            {
                //Act                
                service.GetProfileData( null, "key");

                //Assert         
                Assert.Fail("GetProfileValue(null, \"key\") should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetProfileValue(null, \"key\") should have been thrown ArgumentNullException.");
            }
            // Invalid key
            try
            {
                //Act                
                service.GetProfileValue( "username", null);

                //Assert         
                Assert.Fail("GetProfileValue(\"username\", null) should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("GetProfileValue(\"username\", null) should have been thrown ArgumentNullException.");
            }
        }

        [TestMethod]
        public void DnnUsersServiceUnitTests_GetProfileValue_ShouldReturnsProfileDataValue()
        {
            //Arrange            
            var mockRepo = new Mock<IUsersRepo>();            
            var profileData = new UserProfileItem { Value = "value", Key = "key", Username = "username" };
            
            mockRepo.Setup(m => m.GetUserProfile(It.IsAny<string>(), It.IsAny<string>())).Returns(profileData);

            var service = new DNNUsersService(mockRepo.Object);

            //Act
            var result = service.GetProfileValue( "username", "key");

            //Assert            
            Assert.AreEqual(profileData.Value, result);
            mockRepo.Verify(m => m.GetUserProfile(It.IsAny<string>(), It.IsAny<string>()));
        }

        [TestMethod]
        public void DnnUsersServiceUnitTests_SetProfileData_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<IUsersRepo>();
            var service = new DNNUsersService(mockRepo.Object);           
            // Invalid username
            try
            {
                //Act                
                service.SetProfileData(null, "key", "value");

                //Assert         
                Assert.Fail("SetProfileData(null, \"key\", \"value\") should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("SetProfileData(null, \"key\", \"value\") should have been thrown ArgumentNullException.");
            }
            // Invalid key
            try
            {
                //Act                
                service.SetProfileData("username", null, "value");

                //Assert         
                Assert.Fail("SetProfileData(\"username\", null, \"value\") should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("SetProfileData(\"username\", null, \"value\") should have been thrown ArgumentNullException.");
            }
        }

        [TestMethod]
        public void DnnUsersServiceUnitTests_SetProfileData_ShouldAddsProfileData()
        {
            //Arrange            
            var mockRepo = new Mock<IUsersRepo>();
            
            mockRepo.Setup(m => m.GetUserProfile(It.IsAny<string>(), It.IsAny<string>())).Returns(It.IsAny<UserProfileItem>());
            mockRepo.Setup(m => m.AddUserProfile(It.IsAny<UserProfileItem>()));

            var service = new DNNUsersService(mockRepo.Object);

            //Act
            service.SetProfileData( "username", "key", "value");

            //Assert                        
            mockRepo.Verify(m => m.GetUserProfile(It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.AddUserProfile(It.IsAny<UserProfileItem>()));
        }

        [TestMethod]
        public void DnnUsersServiceUnitTests_SetProfileData_ShouldUpdatesProfileData()
        {
            //Arrange            
            var mockRepo = new Mock<IUsersRepo>();
            var profileData = new UserProfileItem { Value = "value", Key = "key", Username = "username" };

            mockRepo.Setup(m => m.GetUserProfile(It.IsAny<string>(), It.IsAny<string>())).Returns(profileData);
            mockRepo.Setup(m => m.UpdateUserProfile(It.IsAny<UserProfileItem>()));

            var service = new DNNUsersService(mockRepo.Object);

            //Act
            service.SetProfileData("username", "key", "value");

            //Assert                        
            mockRepo.Verify(m => m.GetUserProfile(It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.UpdateUserProfile(It.IsAny<UserProfileItem>()));
        }

        [TestMethod]
        public void DnnUsersServiceUnitTests_DeleteProfileData_ShouldThrowsExceptions()
        {
            //Arrange            
            var mockRepo = new Mock<IUsersRepo>();
            var service = new DNNUsersService(mockRepo.Object);
            // Invalid username
            try
            {
                //Act                
                service.DeleteProfileData(null, "key");

                //Assert         
                Assert.Fail("DeleteProfileData(null, \"key\") should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("DeleteProfileData(null, \"key\") should have been thrown ArgumentNullException.");
            }
            // Invalid key
            try
            {
                //Act                
                service.DeleteProfileData("username", null);

                //Assert         
                Assert.Fail("DeleteProfileData(\"username\", null) should have been thrown ArgumentNullException.");
            }
            catch (ArgumentNullException) { }
            catch (Exception)
            {
                Assert.Fail("DeleteUserProfile(\"username\", null) should have been thrown ArgumentNullException.");
            }
        }

        [TestMethod]
        public void DnnUsersServiceUnitTests_DeleteProfileData_ShouldDeletesProfileData()
        {
            //Arrange            
            var mockRepo = new Mock<IUsersRepo>();
            var profileData = new UserProfileItem { Value = "value", Key = "key", Username = "username" };

            mockRepo.Setup(m => m.GetUserProfile(It.IsAny<string>(), It.IsAny<string>())).Returns(profileData);
            mockRepo.Setup(m => m.DeleteUserProfile(It.IsAny<int>()));

            var service = new DNNUsersService(mockRepo.Object);

            //Act
            service.DeleteProfileData("username", "key");

            //Assert                        
            mockRepo.Verify(m => m.GetUserProfile(It.IsAny<string>(), It.IsAny<string>()));
            mockRepo.Verify(m => m.DeleteUserProfile(It.IsAny<int>()));
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentOutOfRangeException))]
        public void DnnUsersServiceUnitTests_GetUsers_ShouldThrowsArgumentOutOfRangeException()
        {
            //Arrange          
            var mockRepo = new Mock<IUsersRepo>();                        
            var service = new DNNUsersService(mockRepo.Object);

            //Act
            service.GetUsers(-1);
        }

        [TestMethod]
        public void DnnUsersServiceUnitTests_GetUsers_ShouldReturnsUsers()
        {
            //Arrange            
            var mockRepo = new Mock<IUsersRepo>();
            var users = new List<UserInfo> {
                new UserInfo { Id = 1, Username = "uname1", Email = "user1@email.com" },
                new UserInfo { Id = 2, Username = "uname2", Email = "user2@email.com" }
            };
            mockRepo.Setup(m => m.GetUsers(It.IsAny<int>(), It.IsAny<string>())).Returns(users);

            var service = new DNNUsersService(mockRepo.Object);

            //Act
            var result = service.GetUsers(0, string.Empty);

            //Assert         
            Assert.AreEqual(users, result);
            mockRepo.Verify(m => m.GetUsers(It.IsAny<int>(), It.IsAny<string>()));
        }
    }
}
