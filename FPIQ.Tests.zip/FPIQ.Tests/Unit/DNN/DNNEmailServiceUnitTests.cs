﻿using FPIQ.Entities.Models;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using System;
using FPIQ.Core.Repos;
using FPIQ.DNN.Services;

namespace FPIQ.Tests.Unit.Core
{
    [TestClass]
    public class GMSEmailServiceUnitTests
    {
        private string currentPath = Environment.CurrentDirectory;

        [TestInitialize]
        public void Initialize()
        {
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void GMSEmailServiceUnitTests_SendEmail_ShouldThrowsArgumentNullException()
        {
            //Arrange            
            var mockRepo = new Mock<IEmailLogsRepo>();            
            var service = new DNNEmailService(mockRepo.Object, currentPath);                        
           
            //Act
            service.SendEmail(null);
        }

        [TestMethod]
        public void GMSEmailServiceUnitTests_SendEmail_ShouldSendsEmail()
        {
            //Arrange
            var hubKey = "HUB_KEY";            
            var email = new EmailMesssage { HubKey = hubKey, EmailFrom ="from@email.com",  EmailTo = "to@email.com", SessionId = Guid.NewGuid(), AppKey = "appKey" };
            email.Subject = "email test";
            email.Message = "email test body";

            var mockRepo = new Mock<IEmailLogsRepo>();                        
            mockRepo.Setup(m => m.AddToLog(It.IsAny<EmailMesssage>()));

            var service = new DNNEmailService(mockRepo.Object, currentPath);

            //Act
            service.SendEmail(email);

            //Assert                 
            mockRepo.Verify(m => m.AddToLog(It.IsAny<EmailMesssage>()));
        }      
    }
}
