﻿
using FPIQ.Core;
using FPIQ.Core.Services;
using System;
using System.Collections.Generic;
using System.Reflection;

namespace FPIQ.Tests
{
    public class MoqContainer_Integration : IContainer
    {
        public Dictionary<Type, Type> store = new Dictionary<Type, Type>();
        public Dictionary<string, object> instances = new Dictionary<string, object>();
        private IWebConfigService _webConfigSvc;

        private IWebConfigService WebConfigSvc
        {
            get
            {
                if (_webConfigSvc == null)
                    _webConfigSvc = GetInstance<IWebConfigService>();

                return _webConfigSvc;
            }
        }

        private T CreateInstance<T>(string fullyQualifiedTypeName)
        {
            return (T)CreateInstance(fullyQualifiedTypeName);
        }

        private object CreateInstance(string fullyQualifiedTypeName)
        {
            var type = Type.GetType(fullyQualifiedTypeName);
            return CreateInstance(type);
        }

        private object CreateInstance(Type type)
        {
            var instanceKey = type.FullName;

            if (instances.ContainsKey(instanceKey))
                return instances[instanceKey];

            ConstructorInfo constructor = type.GetConstructors()[0];
            ParameterInfo[] constructorParameters = constructor.GetParameters();
            if (constructorParameters.Length == 1)
            {
                return Activator.CreateInstance(type);
            }

            List<object> parameters = new List<object>(constructorParameters.Length);
            foreach (ParameterInfo parameterInfo in constructorParameters)
            {
                parameters.Add(GetInstance(parameterInfo.ParameterType));
            }

            var instance = constructor.Invoke(parameters.ToArray());

            return instance;
        }

        public T GetInstance<T>()
        {
            try
            {
                return (T)GetInstance(typeof(T));
            }
            catch (InvalidOperationException ex)
            {
                throw new Exception("Dependency resolution failed", ex);
            }
            catch (Exception)
            {
                return default(T);
            }
        }

        public bool HasInstance(Type type)
        {
            try
            {
                Type implementation = store[type];
                var instanceKey = type.FullName;
                return instances.ContainsKey(instanceKey);
            }
            catch (Exception)
            {
                return false;
            }
        }

        public object GetInstance(Type type)
        {
            try
            {
                Type implementation = store[type];

                return CreateInstance(implementation);
            }
            catch (InvalidOperationException ex)
            {
                throw new Exception("Dependency resolution failed", ex);
            }
            catch (Exception)
            {
                return null;
            }
        }

        public void Register<TContract, TImplementation>()
        {
            if (store.ContainsKey(typeof(TContract)))
            {
                store[typeof(TContract)] = typeof(TImplementation);
            }
            else
            {
                store.Add(typeof(TContract), typeof(TImplementation));
            }
        }

        public void RegisterInstance<T>(object instance)
        {
            Type type = typeof(T);
            if (store.ContainsKey(type))
            {
                store[type] = instance.GetType();
            }
            else
            {
                store.Add(type, instance.GetType());
            }

            var instanceKey = type.FullName;
            if (instances.ContainsKey(instanceKey))
            {
                instances[instanceKey] = instance;
            }
            else
            {
                instances.Add(instanceKey, instance);
            }
        }

        public void RemoveInstance(Type type)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
